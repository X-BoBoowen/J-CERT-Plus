# V3 Evidence 导航与解释规则

本包对应 V2 基线 `4c2c7b7e84c7c03ee56d45453fea6950c94817bd` 和 V3 实际 H/G 提交 `c6b752630bd8dbe1f9fd296a7ed02f249f834575`。完整决策见根目录 `V3_Decision_ZH.md`，机器可读最终结论为 `v3/resumed/reports/FINAL_RESEARCH_DECISION.json`。

## 优先阅读

1. `v3/resumed/reports/FINAL_RESEARCH_DECISION.json`：一个主要后续方向及范围。
2. `v3/resumed/reports/a1_verified/`：四个原件收到后的最终 V2 账本与来源核对。
3. `v3/resumed/reports/numeric_findings.json`、`numeric_certificate_checks.json` 和 `numeric_units_and_contract_audit.md`：174 项限定生产路径检查及单位说明。
4. `v3/resumed/diagnostics/alpha_structure/` 与 `reports/alpha_classification_report.json`：真实 Alpha 精确关系，`full_decision_verified=false`。
5. `v3/resumed/reports/hg_verified/` 与 `v3/resumed/raw_hg/`：12 个正式 worker、全部完整和未完成结果。旧的 `reports/hg/` 是保留的分析失败尝试。
6. `v3/resumed/reports/memory_accounting_profile.json` 和 `numeric_memory_instrumentation_attribution.md`：唯一一次固定流成本归因。
7. `v3/resumed/reports/a1_d_backend_static_admission.json`：可选后端未通过依赖／接口准入，没有数值探针。
8. `v3/budget_ledger.jsonl` 和 `v3/runs/`：所有数值子进程的限制、绑定、退出和预算，包括失败尝试。

## 不能混用的证据层次

- 独立有理物理 oracle、实际生产局部区间、实际小图全目录服务检查分别标明。weight64 仅走通用局部入口；A2 自身拒绝该权重。
- Alpha 的组合置换直接比较完整父、意见和两个子算子；它证明指定候选相等，没有独立证明整个决定。
- 12 个真实 worker 的 696 条接受记录完成合法性／版本链检查，12 份实际见证（6 个唯一关系）完成结构检查；它们没有全部独立数值重放。
- 当前大图 checker 的非点区间相交不是发布端点包含证明。
- 五个完整 H/G 配对的 2.407142 比值包括既有深层报告成本；正式批次没有额外 profile 包装。只有单独 Alpha/slow 诊断加了非重叠计时包装。
- 单流报告成本差约占该诊断完整时间差的 83.5%，不外推到五单元，也不将扣减余量当作关闭报告后的实测性能。
- 候选数不等于耗时；payload 快照不等于进程峰 RSS；部分 Q4 不填完整耗时；未知用 null，不用 0。

## 保留失败和历史阶段身份

`a1_attempt1/`、旧 `hg/`、`control_attempts/` 及对应运行日志完整保留。附件未齐时已有的微型代码／预算记录也保留，其“来源尚缺”状态是历史状态。它们不能覆盖当前四包已核验的事实。最终意见以 `FINAL_RESEARCH_DECISION.json` 和最终中文报告为准。

预先选择父状态、正式次序、Alpha 有限结构集合和唯一代表流协议都在 `v3/resumed/protocols/`。科学计算已停止，未追加重复或新 seed。28 项最终测试在真正 Code ZIP 解压内容和准确 V2 组合树上执行，初次测试发现方式错误及修正另记，没有重跑正式性能。

## 原件和代码

原 V2 Code／Evidence／Inputs／PVLDB Source 的归档和成员摘要见 `v3/resumed/inspection/archive_verification.json`。本包不嵌套那些原始 ZIP 或大型 NPZ。必须使用用户原件；缺失时不能生成替代数据声称复现。

新增／修改源码、独立 oracle、诊断入口、最小补丁和差异 bundle 在 `V3_Code.zip`，按其中 `v3/README_V3_REPRODUCE.md` 与准确 V2 组合。未上传任何未经授权的其他历史资料。

## 文件完整性

`MANIFEST_V3_EVIDENCE.json` 列出所有 payload 成员的字节数和 SHA256，排除其自身。`V3_Delivery_Manifest.json` 列出包级摘要、包含内部 manifest 的全部归档成员、实际运行绑定和交付验收。两个 ZIP 均做 CRC、安全路径及真实解压后成员校验。
