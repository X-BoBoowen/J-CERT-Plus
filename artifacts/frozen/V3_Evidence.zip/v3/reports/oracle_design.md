# Independent exact micro oracle

## Scope and boundary

This is a mathematical reference for the five constructed A2 fixtures in the
supplied V3 plan, with alpha fixed to one. It does not import, emulate, or patch a
V2 production interface. V2 Code, Evidence, and Inputs were absent when this
reference was prepared. Therefore no result from this component establishes a
production gain interval, production certificate, historical decision, or complete
service execution. The JSON report marks `production_path` as
`unavailable_missing_v2_code` and production `full_decision_verified` as false.

## Exact physical calculation

Each input is an unordered signed edge list with integer or `Fraction` weights.
The oracle constructs a symmetric physical adjacency matrix W and the absolute
weighted degree D, then materializes A = I + D - W. For each legal child it
reconstructs the edge list and materializes a fresh physical child operator.
Gaussian elimination with nonzero row pivots and exact rational back substitution
computes z from Az = s. The objective is the dot product s-transpose-z. The gain is
the parent objective minus the child objective. There is no inverse-update,
local-gain, interval, residual, or production numerical kernel in this code.

The allowed physical operators are nonsingular: each edge contributes
|w| times (e_i - sign(w)e_j)(e_i - sign(w)e_j)-transpose, which is positive
semidefinite, and the identity makes their sum positive definite. The generic
rational solver also rejects singular square inputs. It never converts physical
values to binary floating point. Floating point is used only to measure elapsed
checker time.

## Domain and canonical choice

Vertices are zero based. For i < j, the canonical ID is i*n+j. A positive insertion
is allowed only on an absent edge. A flip is allowed only on a negative edge and
sets its weight to its positive absolute value. Existing positive edges are not
candidates. The full catalog is enumerated in canonical ID order. Self loops,
duplicate unordered edges, zero-weight edge entries, invalid indices, booleans,
and floating point physical values are rejected. The insertion weight must be
strictly positive.

`canonical_reference_decision` consumes the complete output of
`evaluate_catalog`; its complete-catalog precondition is documented, not an
authenticated production coverage assertion. A maximum gain must be strictly
positive to be accepted. Exact ties use the smallest canonical ID. A catalog with
no positive gain returns the reference status `certified_stop` and accepts no edit.
The same status label does not assert that a V2 service certificate was checked.

## Callable interface

| Function | Result and work |
| --- | --- |
| `physical_operator(n, edges)` | Tuple of rows containing exact Fractions |
| `solve_rational(A, s)` | Exact state tuple; one RHS solve |
| `objective(n, edges, s)` | Exact physical objective; one RHS solve |
| `legal_edits(n, edges, insertion_weight)` | Complete tuple of `Edit` values |
| `edited_edges(n, edges, edit)` | Validated child edge tuple |
| `gain(n, edges, s, edit)` | Parent-minus-child objective; two RHS solves |
| `evaluate_catalog(n, edges, s, insertion_weight)` | One `GainRecord` per legal edit; one parent solve plus one solve per edit |
| `canonical_reference_decision(complete_catalog)` | Exact reference acceptance or stop, scoped to the supplied complete catalog |

`Edit(kind, i, j, weight, canonical_id)` uses the positive resulting physical edge
weight. `GainRecord` contains the edit, parent objective, child objective, and gain.
An input edge can be given in either endpoint orientation; an edit itself must
use i < j. Sequences and iterables are consumed into exact immutable tuples.

## Fixtures and independently specified expectations

| Fixture | Exact expected result |
| --- | --- |
| Four-point path with signs (-,+,-), unit weights, s=(1,-1,-1,1), insertion 1/16 | Flips IDs 1 and 11 both 32/21; insertion IDs 2 and 7 both 28/121; ID 3 zero; canonical winner ID 1 |
| Same path, s[1] = -1 + 1/65536 | All five edits evaluated; right flip minus left flip is 1/114688; unique global reference winner ID 11 |
| Same path and nonempty catalog, s=0 | All five gains exactly zero; reference certified stop; no accepted edit |
| Two vertices with edge weight -64, s=(1,-1) | Flip physical gain 256/129 |
| Two isolated vertices, insertion 1/16, s=(1,-1) | Insertion physical gain 2/9 |

The named unit tests catch incorrect signs or degree normalization, loss of a
competitor, numerical conflation of the near tie, incorrect canonical ordering,
acceptance at zero gain, a wrong physical weight scale, solver pivot failures,
and malformed input acceptance. Their literal expectations come from the task
plan; they are not calculated by the implementation being tested. The reporting
check verifies that these exact values and the production boundary survive into
the evidence data structure.

## Execution and provenance

The test file was written first. The root scheduler ran the initial test under
the frozen resource protocol and observed the expected missing-oracle import
failure before implementation. This worker performed no numerical process,
tests, solver runs, or performance probes. Subsequent green checks and evidence
generation belong to the root scheduler and its budget ledger.

Run the following only through that scheduler, with one thread, a 120-second
process ceiling, and a 2-GiB memory ceiling:

```bash
python -m unittest discover -s v3/code -p test_exact_oracle.py -v
python v3/code/run_micro_checks.py --output v3/reports/micro_checks.json
```

The report requires 22 exact RHS solves: six each for the three path cases and
two each for the two-vertex cases. The unit-test run performs its own explicitly
scoped checks, including an in-process reporting check; it is a separate budgeted
checker process. Reported RHS counts describe the report evaluation itself.
The internal elapsed time is checker time, never complete-service timing. The
scheduler's actual process wall time and exit status remain authoritative.

The JSON records all five exact catalogs, parent and child operators, parent and
child objectives, gains, named expected-value checks, canonical reference
decisions, input digests, source hashes, and protocol hash where available.
Fractions serialize as exact numerator/denominator strings. The source file
digests are runtime digests, so the final package freeze must occur after edits
and before the root runs the final evidence generation.
