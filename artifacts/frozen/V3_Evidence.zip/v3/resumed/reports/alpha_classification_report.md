# Task B: the repeated Alpha comparison is exactly equal

The independent diagnostic classified the relationship between candidates **7073654** and **12373891** as **`exact_equal`**, with the guaranteed physical gain-difference interval **[0, 0]**. It used an exact finite permutation proof and executed **zero floating-point solves**. The nine V2 records are repeated observations of one physical event. V2 remains `unresolved`, and **`full_decision_verified=false`**.

## Physical binding

The diagnostic read the original Alpha weighted CSR input and exact q1 opinion codes, checked their registered hashes, and rebuilt `A=I+D−W` from the original graph. It then applied exactly the three recorded legal flips. Saved root/parent operator digests were compared only after this independent reconstruction. The current parent has 3,783 vertices, 31,945 operator nonzeros, and **7,140,881 legal candidate edits** represented by an independently checked root/current legality predicate and count.

| Accepted step | Candidate ID | Zero-based endpoints | Physical absolute weight |
|---|---:|---|---:|
| 1 | 6725985 | (1777, 3594) | 9/2 |
| 2 | 3926607 | (1037, 3636) | 10 |
| 3 | 13138219 | (3472, 3643) | 10 |

All nine raw records bind the same exact q1 opinion, this prefix, and the fourth parent. The full paths and checksums are in `alpha_parent_binding.json` and `alpha_classification_report.json`.

## Exact equality evidence

Both target edits are legal insertions of weight 1/16:

| Candidate | Zero-based endpoints | Evidence |
|---:|---|---|
| 7073654 | (1869, 3227) | Saved provisional candidate |
| 7073908 | (1869, 3481) | Saved swap (3227, 3481), independently rechecked |
| 12211011 | (3227, 3270) | Saved swap (1869, 3270), independently rechecked |
| 12373891 | (3270, 3481) | New finite composed-swap proof |

The frozen search permitted only permutations of the four target endpoints, with every other vertex fixed. The **17th of the 24 permitted permutations** succeeded:

\[
P=(1869\;3270)(3227\;3481).
\]

The program directly checked every exact sparse entry needed for

\[
P A_{parent}P^T=A_{parent},\qquad Ps=s,\qquad P A_aP^T=A_b.
\]

Orthogonality of the permutation gives identical child quadratic objectives. The common parent objective cancels, so

\[
g_a-g_b=s^T A_b^{-1}s-s^T A_a^{-1}s=0.
\]

The program also checked both saved transposition declarations against the independently rebuilt physical parent, exact opinion, and full child operators. These proofs establish an equal **observed subset of four insertions**. They do not establish that this subset contains every maximizing edit.

## What the result explains

The frozen `exact_ties._BoundExchange.certify` admits only a single transposition: it returns no witness when the two edit endpoint sets have a symmetric difference of size other than two. The remaining target pair has four distinct endpoints. The frozen large-graph resolver consequently kept this event unresolved after its single-transposition star failed to cover the remaining candidate. The valid composition found here lies outside that witness family.

For this event, the evidence therefore identifies a **finite witness-family completion limitation**. The remaining pair has an exact zero difference; increasing numerical precision cannot establish a sound nonzero separation for it. This diagnostic does not establish a general low-cost method for arbitrary exact ties.

## Scope and cost

The independent relation proof does not certify a complete fourth decision. **Strict positive gain, numerical coverage of all 7,140,881 current legal edits, and the global canonical winner remain unchecked.** The first three accepted edits were reconstructed and checked for legality; their numerical optimality was not replayed in this diagnostic. Candidate 7073654 is the smallest ID in the proved four-candidate subset, which alone does not establish global canonical choice.

The root scheduler recorded **0.366310952 seconds** for the complete diagnostic child process, including imports and serialization; internal diagnostic wall time was 0.293731743 seconds. Sampled peak RSS was 40,951,808 bytes under a 4 GiB address-space limit and 600-second wall limit. One process was used. The optional direct-child residual/energy fallback was not started, and no common resolver code was changed.

## Evidence files

- `v3/resumed/diagnostics/alpha_structure/alpha_classification.json`
- `v3/resumed/diagnostics/alpha_structure/alpha_parent_binding.json`
- `v3/resumed/diagnostics/alpha_structure/alpha_exact_relation_witness.json`
- `v3/resumed/diagnostics/alpha_structure/alpha_saved_witness_checks.json`
- `v3/resumed/diagnostics/alpha_structure/alpha_candidate_context.json`
- `v3/resumed/diagnostics/alpha_structure/alpha_attempts.jsonl`
- `v3/resumed/protocols/ALPHA_DIAGNOSTIC.json`
- `v3/runs/resumed_alpha_relation_structure/record.json`

The companion JSON report binds all evidence files, the independent script, frozen protocol, scheduler record, and the two relevant V2 source files by SHA256.
