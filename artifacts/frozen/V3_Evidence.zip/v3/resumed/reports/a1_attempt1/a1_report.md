# V3 A1: retained V2 evidence audit

Status: **issues_found**.

This pass reads original records and exact retained inputs. It performs no service solve, scoring replay or historical benchmark. Saved gain intervals retain their original numerical evidence scope.

## Independent denominators

| Item | Recomputed |
|---|---:|
| independent_streams | 6 |
| distinct_opinion_rows | 24 |
| planned_workers | 54 |
| raw_workers | 54 |
| complete_Q4_workers | 45 |
| planned_request_executions | 216 |
| recorded_request_executions | 216 |
| completed_request_executions | 207 |
| accepted_decisions | 3132 |
| decisions_including_terminal | 3141 |
| unresolved_observations | 9 |
| distinct_unresolved_parent_states | 1 |
| complete_paired_repeats | 15 |
| complete_paired_cells | 5 |

## Winners and whole-insert exclusion

On the six canonical H/repeat0 trajectories: 230 flip winners and 118 insertion winners among 348 accepts. Of 230 eligible flip winners, 35 have a logged certified physical lower bound strictly above 1/4. These are distinct denominators.

The source-bound contract gives omega=1/16 and |z_i|<=1, hence U_insert<=4*omega=1/4 even without saved parent q/r. Decision low/high are already physical gain numerators: divide only by gain_denominator=UNIT^2. Provisional resolution source_lower/source_upper are internal score units and require SCALE before that division.

If a flip lower bound is not above 1/4, this audit does not conclude that insertion exclusion is impossible or that both families compete. The finer range bound is unknown because parent centers/radii were not retained. Successful exclusions rely on saved current-version full-catalog certificates; they are not new independent numerical reproofs of every endpoint.

## Existing H mechanism and measured cost

H already orders insertion row heads by certified endpoint range caps and merges them with sparse flip caps. It can stop before emitting further insertions, but it first pays for sorting node centers and constructing the insertion heap. Equality is retained at the strict delta=0 cutoff. A global 4*omega clamp is not present. The shared candidate screen already uses the current-nonedge diagonal denominator inequality after candidates have been generated.

Across the complete historical paired H workers, total service cost is 55.62411935000091 s. The separately measured node_sort+heap_build cost at globally excludable flip epochs is 0.4381180380278238 s (p=0.007876404033852208); ideal speedup if only that measured component vanished is 1.007938934287902.

This ideal deletion calculation applies only to the named measured component. It excludes all new baseline overhead. initial_head_filter, seed_access, candidate_access, endpoint_screen and response buckets mix edit families, so their insertion-only removable time remains null. Candidate/RHS/Gram counts have not been converted into time. Root H seed/frontier timer aliases are counted once. Partial Alpha workers are reported separately, and no old/new environment speed ratio is formed.

## Frozen parent selection

The six H/repeat0 q1 initial parents plus the genuine Alpha/signed-neighbor/q1 fourth parent were frozen before new solves. Raw audit=False records do not supply separate certified family maxima or parent centers/radii; therefore the prescribed q1 initial fallback is used with competitiveness marked cannot_classify. The selection is not changed using this audit's outcomes.

## Scope limits

Nine unresolved observations are grouped by exact opinion, accepted prefix and parent version. Partial structural witnesses or overlapping intervals do not classify the remaining relation. Full decision verification remains a separate task. Complete-service status is recomputed from individual requests, never from the scheduler's completed_requests field. Existing factor/solve metering overlaps service phases and is not added to them.

Machine-readable details: a1_summary.json, a1_decision_ledger.jsonl/.csv, a1_request_ledger.jsonl, a1_worker_ledger.jsonl, a1_stage_costs.csv, a1_binding.json and a1_state_selection_check.json.

## Issues

- roster: /workspace/scratch/faa1a8a62f06/v2_received/evidence/v2/raw_a: raw worker count differs from planned roster
- roster: /workspace/scratch/faa1a8a62f06/v2_received/evidence/v2/raw_a: raw worker filenames differ from registered jobs