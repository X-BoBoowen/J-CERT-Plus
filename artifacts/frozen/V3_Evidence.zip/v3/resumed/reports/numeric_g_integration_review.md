# G access integration review

## Review status

This is a static review of the actual new `v3_runtime/src/g_access.py`, the narrow integration changes in `src/a2_session.py` and `src/a2_checker.py`, and `tests/test_v3_g.py`. No numerical process was executed by this reviewer. The root scheduler owns all tests, timing, and numerical replay.

The reviewed post-feedback snapshots had these SHA256 values:

| File | SHA256 |
|---|---|
| `src/g_access.py` | `04d3c8eb41279fcbb0c9e7ad876111b9dd0f666bb951ee73ab9d9248cdb0b7cb` |
| `src/a2_session.py` | `ff9542b4ecb489adcc09d83c1666073a1867de77c1f5feef4da8657575d2630d` |
| `src/a2_checker.py` | `a403f1da68237ac7e2735dc7378488f58443b1541121d50e86a537de11222fc1` |
| `tests/test_v3_g.py` | `c61d3391b98a994a602a3fc9f4325ee58718d6608beba5425b6750b17e5311a5` |

No false gain bound, omitted-competitor cutoff, or numerical-core integration defect was found in these snapshots. Two initial implementation issues were reported to the root and repaired before timing: warm insertions could be scored before the flip-first test on later versions, and a repeated zero-budget request could encounter stale `None` state during memory reporting. Separate proof/rejection gates and the numerical tests still govern whether timing may start; this review is not an unconditional completion claim.

## 1. Common-unit cutoffs are consistent

The current center represents `z_i=A_int^-1 s=z_physical/16` on the `SCREEN=2^20` grid. A G coarse upper integer `c` therefore represents physical gain at most `16c/SCREEN^2`. The shared score lower integer `best` is in units `16/UNIT^2`, and `RATIO=(UNIT/SCREEN)^2`.

The cutoff `c < ceil(best/RATIO)` is exactly sufficient for `c*RATIO < best`. Integer equality is retained. When `best=0`, excluding only caps `<=0` is compatible with the strictly positive acceptance contract. `PairBlocks.pop(max(1,target),...)` applies that same nonpositive exclusion without suppressing a possible positive gain.

The whole insertion cap

`min((2*SCREEN/16)^2, (max(xc)-min(xc)+2rc)^2)`

converts to `min(4omega, omega*(physical state range bound)^2)` for the fixed admitted insertion weight `omega=1/16`. The current exact min/max, cached once per parent, avoid repeated linear scans while preserving the bound. The cap requires the admitted physical opinion bound and legal signed operator, which the common session supplies.

The block formula uses `di=max A_int[ii]` within the left node and similarly `dj`. Thus `1/di` and `1/dj` are lower bounds on each endpoint reciprocal diagonal. For legal current nonedges, the denominator bound gives

`coarse gain <= width^2*di*dj/(di*dj+di+dj)`.

The code performs the final ceiling with Python integers and takes the minimum with the independent valid global cap. This is an aggregation of a diagonal denominator inequality already present per candidate in A2 `CachedStrict.screen`; it is not a new numerical inequality or a new signed-flip formula.

**Source:** `src/g_access.py`, functions `global_insertion_upper`, `PairBlocks._push`, `GAccess.next_batch`; common scale derivation in `numeric_units_and_contract_audit.md`; existing per-candidate denominator in `src/a2_numeric.py:89–95`.

## 2. Parent reconstruction and numerical-core reuse

`GAccess.open_version` rebuilds the current diagonal from the immutable root graph plus exactly the chosen insertions. A negative-edge sign flip preserves the absolute degree and therefore does not change the diagonal. Each admitted insertion has integer coefficient one, and the code obtains it from the bound catalog. Current root half-integer weights are small enough that summing them in binary64 before multiplying by 16 is exact in the admitted vertex range; the resulting integer diagonal matches the common operator convention.

Each version discards the old pair-block heap and recomputes flip caps from the current state enclosure. The blocks and state arrays are used within the synchronous version interval and are discarded before the next one. This is sound under the actual session call order. It is not a standalone authentication scheme for arbitrary caller-supplied centers, diagonals, or parent strings.

The session still uses the same `EndpointKernel`, integer residual certificates, directional score and transport core, positivity rule, equality resolver, child certification, root reset, and version-chain functions for H and G. The checker change admits the authentic method label `G` and leaves its numerical, version, opinion, weight, and full-catalog checks intact. Relabelling a G output as H would have been inappropriate and is unnecessary after this narrow whitelist change.

## 3. Warm insertion issue and closure

Initially the new access object emitted flips first, but the common session first rescored every prior `hot` candidate. After an earlier version materialized insertion Grams, those warm insertions could be scored before the new version's flip/global-exclusion pass. The output remained subject to the same certificates, but the mechanism did not implement the intended flip-first policy on every version.

The root added `GAccess.warm_candidates` and calls it before deriving `seeds` and the hot exclusion set. This retains only flip identifiers in `hot`. Previously materialized insertion Grams remain in `views.entries`, so their numerical work can be reused if subsequently needed; the independent pair partition must reconsider their candidate coverage before they can be skipped. Removing the identifiers from both seeds and the exclusion set is essential: filtering only the seeds would omit unscored warm insertions from the cold search.

The cache filtering is inside `ledger.phase('cache_management')`, so its cost is paid. All still-resident Grams continue to incur the common transport cost. This does not create a free cache-maintenance advantage for G.

## 4. Cost and reset boundaries

G's root diagonal preparation belongs to setup `catalog_build`. Flip sorting, block root preparation, and node sorting are inside the existing ledger. State copying and chosen-diagonal updates occur inside the session's `candidate_access` phase. Failed whole-insertion tests, pair splitting, illegal-pair rejects, one-at-a-time insertion emission, shared strict screening, scores, comparison, transport, and memory bookkeeping are within the complete request wall. The use of a one-insertion batch is a fixed implementation choice whose Python overhead must be included, not discounted as an abstract operation count.

For a current-environment H/G comparison, total service cost must include setup and the same requested Q4 work; partial or unresolved requests remain outside the completed-Q4 time denominator. Checker work stays separately timed, with an explicitly additional definition if a combined total is also shown. These requirements are not established merely by using the common ledger; the paired worker and report must preserve them.

The initial zero-budget reset defect came from `close()` setting diagonal/current center fields to `None` while memory observation used only `hasattr`. The root's repaired `begin()` installs fresh root diagonal and state fields before any request, including budget zero, closing the observed request path. Ordinary requests reset the structural root factor, request Grams, access structures, and chosen set. The new reset and four-commit exact-replay tests are relevant focused verification; their actual pass status belongs to the root's execution evidence.

## 5. Memory and source-binding limits

The code creates no full candidate array or full insertion complement table. Node summaries are cached per split interval, and the pending heap holds the currently live pair blocks. However, there is no proof here that this heap has a uniform linear-size worst-case bound. It can reflect a large unresolved search frontier.

`_observe_memory()` samples at version completion and final memory reporting. Consequently, `peak_frontier_owned_bytes` is a maximum of observed snapshots, not necessarily the true maximum live heap allocation. The shared center may be counted as owned in that diagnostic, and Python payload estimates do not replace RSS. The root confirmed that supervisor process peak RSS is authoritative and that the payload diagnostic will not be presented as a global memory bound. The zero-budget path can also retain `root_flips` outside the current `flip_order` snapshot; this does not change the planned positive-budget experiment's total RSS measurement.

The original `a2_bench.RUNTIME_SOURCES` and `v2_runner.sources()` did not include the new G file. The new V3 worker/protocol must explicitly bind `src/g_access.py`, all changed session/checker code, the actual numerical overlay/native dependencies, its protocol, and input hashes before timing. The root plans an all-`src` source snapshot plus the bound legacy set. The old V2 source list alone is insufficient.

## 6. Remaining gate scope

The existing exact physical oracle and targeted G tests check actual generated candidates, block bounds, current diagonals, and selected decisions. They do not themselves create a standalone verifier for arbitrary externally supplied block coverage evidence. In particular, missing-block, stale-parent, and wrong-weight rejection requirements must be demonstrated on the actual new G mechanism or explicitly left unfulfilled. The earlier `v3/code/block_probe.py` is a separate mathematical probe and cannot be substituted as evidence that G rejects those attacks.

The parallel partition reviewer is checking those obligations. This review reports no remaining unit/cutoff or common-core integration defect after the root's patches; it does not close an unimplemented independent coverage-evidence gate. No runtime source was changed by this reviewer.
