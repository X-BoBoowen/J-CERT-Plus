# J-CERT+ V3：有限主张—组件—证据映射（A1/A2/B 已闭合，当前环境计时待补）

**当前可写入 V3 决策报告的新增结论只有三条：实际单位链在规定微型路径上自洽；真实 Alpha 剩余候选关系有精确等值证据；翻转获胜频率远高于仅凭全局界即可整类排除插入的频率。** H 与强简单基线 G 的当前环境端到端价值在本表中保持 `pending`。本表不据历史 D/S/H 耗时替代当前 H/G 配对，也不对整篇稿件重写。

权威 A1 结果是 `v3/resumed/reports/a1_verified/`。第一次分析将 `SCHEDULE_RESULTS.json` 误计入 worker 文件集合，已保留为 `a1_attempt1/` 并在独立新输出目录修正；这不是 V2 输入或来源缺陷。旧 `v3/reports/literature_audit.md` 与 `literature_sources.json` 的 S1–S5 原文核查仍可用，其中“V2 包缺失”的运行阶段描述已被本轮实际接收和核查替代。其旧 J-CERT+ 全未知行不再代表当前证据状态。

## 一、最多三条新增主张

| ID | 可采用的有限表述 | 证据与分母 | 仍不可扩张到 |
|---|---|---|---|
| V3-C1 | 在规定独立有理父子 oracle 和实际生产核路径上，物理量、整数算子和局部修正单位一致；没有发现漏乘权重导致的无效区间或错误决定。 | `numeric_certificate_checks.json`、`numeric_findings.json`、`numeric_units_and_contract_audit.md`：174 项检查通过；17 个规定物理 gain，其中 16 个经过实际 A2 核、1 个 weight-64 经过实际通用 correction；4 个传输后 gain；15 次预算一步的小图请求。 | 全部历史真实决定的数值重证；weight-64 获得自然权重 A2 准入；任意权重接口；所有浮点区间端点均被独立包含性验证。 |
| V3-C2 | Alpha/signed-neighbor/q1 第四父状态中，剩余观察候选 7073654 与 12373891 的 gain 差精确为 0；两次合法换位的组合解释了该事件超出原单换位见证族的完成性限制。 | `alpha_classification_report.json` 与 `alpha_structure/alpha_exact_relation_witness.json`：一个物理事件的九份记录；独立重建父算子及精确意见；有限 24 个端点置换中第 17 个成功；直接检查父不变、意见不变及完整子算子共轭；差区间 `[0,0]`，零次浮点求解。 | 第四步完整认证、严格正增益、7,140,881 个当前合法候选全域覆盖、全局规范赢家、恢复 Q1/Q4、通用低成本精确平局解决器。V2 的 unresolved 不变，`full_decision_verified=false`。 |
| V3-C3 | 现有记录支持的“翻转胜出”与“翻转下界足以排除所有插入”是不同事实。H 已含范围型插入前沿，共享筛选已含对角分母界；新增简单对照检验的是准备和块级覆盖的组织价值。 | `a1_verified/a1_summary.json` 与逐决定账本：H/repeat0 六条旧轨迹共有 348 次接受，230 次翻转；其中 35 次翻转的已有认证物理下界严格大于 `4ω=1/4`。所有 230 次翻转满足本次来源/模型/单位资格检查。 | 把 230 次翻转都当成整类排除；由全局界失效推得两类竞争；从缺失 q/r 推得更细范围界也失效；由计数换算时间；在 H/G 配对完成前宣布 H 的独立收益或被简单基线完全解释。 |

V3-C1 是有限路径上的否证性检查：它排除了“仅凭 129 与 8256 不同即可断定漏乘权重”的具体质疑，没有证明所有可能输入正确。实际映射为 `A_int=16 A_phys`、原始分数 `g_phys=16 score/2^96`；已发布 `decision.low/high` 已乘 16，仅除以 `gain_denominator=2^96`。129 属于未归一物理 pivot，8256 属于除以 ω 的物理 pivot；适配器传给旧局部核的有效 pivot 的逆范数界为 1。

## 二、组件、合同与证据位置

| 组件 | 实际作用与边界 | 实现 / 稿件位置 | 本轮证据状态 |
|---|---|---|---|
| 算子与单位 | 自然半整数根权、插入 1/16；整数算子按 16 缩放；有界精确意见分母 65536。合法翻转保持绝对权重。 | `src/common.py`；`weighted_adapter.py:Kernel.operator/child`；`a2_catalog.py:AllCatalog`；稿件 `03_responses`、`10_appendix`。 | A1 直接读取保留 NPZ 并检查图与意见；A2 对真实核逐层和最终物理区间核查。 |
| 响应与区间 | 浮点求解提供试解；整数残差与向外有理/定点运算形成证据；保留 Gram 的版本传输独立于候选覆盖。 | `WeightedViews.response/score/advance`，legacy `promotion.py` 与 `promotion_directional.py`；稿件 `03_responses`、`05_numerics`。 | 规定 17 个 gain、4 个传输后 gain 支持有限路径；无普遍准确性声明。 |
| H 混合覆盖 | 当前插入排序行的最大头与稀疏翻转顺序合并；严格阈值保留等号；每次提交重建。免完整目录数组，不免全部准备成本。 | `a2_catalog.py:MixedFrontier`；`a2_access.py:Access`；稿件 `04_coverage` 的覆盖定理与每版本成本式。 | 静态代码与原始计数/阶段时间相符；没有新增任意过滤或任意插入权重覆盖证明。 |
| 全局与对角界 | `4ω` 可在合格状态下直接排除全部插入；更细 `ω(range(q)+2r)^2` 需有效状态包围。`1/Aii+1/Ajj` 的当前非边分母界已用于共同逐候选筛选。 | `a2_numeric.py:CachedStrict.screen`；`MixedFrontier._entry/upper`；稿件 `04_coverage` 已明确对角界为共有。 | A1 的全局充分性统计已给出；保存状态缺少 q/r，范围界为 unknown。G 块覆盖及当前端到端价值待当前对照结果。 |
| 等值与规范选择 | 当前单换位是充分但不完备的证据族；小图等值可以实际依赖精确回退。等值关系不能免除其余竞争者、正收益和规范顺序。 | `exact_ties._BoundExchange.certify`；`weighted_adapter.py:Kernel.resolve`；稿件 `05_numerics` 的 equality proposition。 | A2 实际区分 3 次小图精确回退与 3 次单换位路径；B 新增的是有限独立组合关系证据，未改公共 resolver。 |
| 独立全域核验 | 独立重建父子和合法点对，不能把执行前沿当覆盖 oracle。非点独立区间与发布区间相交只说明一致性。 | `a2_checker.py`；稿件 `07_evaluation.tex` 的 verification 部分，现有文本已明确 intersection/containment 区别。 | A1 重算 12,528 次配对中 36 次区间不同、72 个端点不同；A2 不把一致赢家升级成全部端点有效。历史两项预选真实请求的 30 个决定范围保持原口径。 |
| 有限完成定理 | 条件是 `δ>0`、有限完整访问及可达到的全误差预算；响应块数上界不是总服务成本上界。主实验实际 `δ=0`。 | 稿件 `05_numerics`、`10_appendix`；legacy `bounds.py` 是条件常数参考计算，不是 A2 区间核。 | 保留现有稿件限定。规定例的充分 ε 约 `5.11e-20` 不等于运行已达到该条件，也不否定后验认证。 |
| 成本与人群 | 54 worker、24 个不同意见属于六条旧流；重复和方法臂不增加输入独立性。未决/部分工作与完整 Q4 分列。 | `v2/PROTOCOL.json`、`INPUTS.json`、`A_JOBS.json`、`raw_a/`；稿件 `evaluation_unseen`。 | A1 独立确认 45/54 完整 Q4、207/216 完成请求、3,132 接受和一个状态的九次未决；当前 H/G 时间字段仍 pending。 |

## 三、成本证据能支持到哪里

原环境五个完整单元、15 组重复的 H 总服务成本为 **55.624119350 秒**。其中，在 96 个满足全局排除条件的 H 决定观察中，确实分开的插入 `node_sort + heap_build` 共 **0.438118038 秒**，占 **p=0.007876404**；若只把这个已测部分完全删除，其他成本保持原样，则理想倍数为 **1.007938934**。这只约束这个特定删除方案，不能作为整个 G 或其他覆盖优化的速度上限。

`initial_head_filter`、`seed_access`、`candidate_access`、`endpoint_screen`、响应和其他混合桶不能从已有记录拆成插入专属时间。因此额外可省时间为 `null`。根 H 的 `seed_build_phases` 与第一版本 `frontier_build_phases` 是同一次构建，已去重。新的翻转先行、块构建、试探失败、缓存及核验开销必须进入当前对照；本表不填推测值。

| 当前对照待填字段 | 本表状态 |
|---|---|
| 同环境、同后端、同输入 H/G 成对完整 Q4 数 | `null / pending` |
| H/G 完整服务成本及部分工作成本 | `null / pending` |
| 全域或新完成决定独立核验结果 | `null / pending` |
| 强简单对照后 H 剩余端到端价值 | `null / pending` |
| 是否有必要增加计时重复 | `null / pending`；只有结果可改变唯一研究建议时再决定 |

## 四、只建议局部稿件更新

1. **必要事实更新：** `sections/evaluation_unseen.tex` 的 U2 以及 `CLAIM_EVIDENCE_MAP.json:E-new-unseen` 仍写“terminal overlap has not been independently classified”。可以追加本轮独立诊断，而不改写 V2 运行状态。建议英文句子如下：

   > A separate bounded V3 diagnostic independently reconstructed this parent and proved the remaining observed candidate pair exactly equal by a composition of two transpositions. Together with two rechecked witnesses, this establishes equality of a four-insertion observed subset. It does not certify strict positive gain, full-domain coverage, or the global canonical fourth decision; the original Q1 and Q4 outcomes remain unresolved.

2. **单位说明：** 在 `03_responses` 或 `10_appendix` 增加紧凑单位映射，指明 `weight` 参数在运行核中是 `d=16ω`，以及发布 low/high 已完成物理缩放。无需为不存在的漏乘 bug 修改数学核。

3. **机制说明：** 在 `04_coverage` 或实验机制段加入 V3-C3 的分母区别；若最终 H/G 结果削弱独立覆盖收益，只调整该部分贡献强度和比较范围。暂不把本表的理想组件删除比写进摘要当算法提速。

应保留的已有正确限定：`07_evaluation` 已区分非点区间相交与 exact containment；`06_execution` 已说明主 A2 不运行历史 planner；`05_numerics` 已限制有限完成定理；`08_related` 已把排序行/堆列为基础。本轮没有证据把这些现存限定误报成稿件遗漏。

## 五、文献定位与仍缺的运行比较

| 原文 | 对当前主张的约束 | 现有证据定位 |
|---|---|---|
| Zhu、Bao、Zhang，NeurIPS 2021 | SPGREEDY 每步在数学模型内算精确分数并取 argmax；其最终 k 边集合有近似保证。FASTGREEDY 才进一步近似分数。没有理由声称前人每步只能近似。 | S1.E1–E3；Algorithm 1、Algorithms 2–3；[原文](https://proceedings.neurips.cc/paper_files/paper/2021/file/101951fe7ebe7bd8c77d14f75746b4bc-Paper.pdf)。 |
| Kaplan 等，SOSA 2019 | 堆、排序行和 X+Y 选择已有基础；差异必须落在 signed gain、合法域、当前版本、并列及证书成本。 | S2.E1–E2；Theorems 3/8/14；[原文记录](https://drops.dagstuhl.de/entities/document/10.4230/OASIcs.SOSA.2019.5)。 |
| Zhou 等，signed FJ | 能量范数状态近似可支持试解后端；不能把固定图状态/量估计的规模结果转写成混合编辑完整决定认证。 | S3.E1–E2；Lemma IV.9、Problem 1；[已核查版本](https://arxiv.org/pdf/2407.10680v2)。 |
| Spielman–Srivastava；Durfee 等 | 共享近似全点对电阻表示和动态电阻维护已有先例；不能以“共享响应帮助很多候选”本身主张创新，也不能把这些结果升级成精确 signed gain 证书。 | S4.E1、S5.E1；[静态原文记录](https://arxiv.org/abs/0803.0929)、[动态原文记录](https://arxiv.org/abs/1804.04038)。 |

这些引用只使用已保存的定向原文核查，没有新增检索，也不是全领域“首个”结论。SPGREEDY 的 unsigned、单位权、固定非边集合共同子域运行比较仍未执行；同一精确意见、物理目标、候选、规范顺序、严格正增益停止和认证成本必须先匹配。文献能力表不能替代该实测。

## 六、当前研究决策边界

B 已确定一个具体见证族缺口，对该真等值继续加数值精度不能给出正确的非零分离。小范围组合见证加全决定核验是可定义的后续工作，但尚未实施。A1 已排除“翻转多数获胜就说明全局界足以解释多数服务收益”的推断；它没有证明更细块覆盖无价值。

因此，本表保留下一轮唯一主建议为 `pending_current_environment_G_H_evidence`。最终决策应在强简单对照的完整成本和核验义务出现后填写；不由本静态映射提前选择覆盖、数值完成、核验或规模后端。没有新增 scale 证据被纳入本表：旧 Slashdot 根超时和 D 显式表示预检继续作为原阶段事实，而非当前新环境速度比较。

机器可读同名 JSON 记录精确来源摘要、范围、状态和所有待填 `null`。本表没有修改原 V2 源码、原始证据或 manuscript 文件。
