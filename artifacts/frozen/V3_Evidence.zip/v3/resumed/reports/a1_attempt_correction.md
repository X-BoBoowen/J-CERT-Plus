# A1 attempt 1: analysis loader correction

The root-scheduled `resumed_a1_original_log_audit` process exited with status 2 after 1.4754151219995038 seconds of ledger time. It produced all outputs and exactly two roster issues. Those issues arose from the new analysis script, not from V2 provenance.

The raw directory includes 54 worker result JSON files, their 54 job JSON files, and `SCHEDULE_RESULTS.json`. The first discovery glob excluded job files but treated the supervisor document as a worker. The subsequent explicit frozen-roster loop still processed the correct 54 workers. This explains why the first report had correct independent 54-worker denominators while its discovery count and filename-set checks failed.

Evidence for the cause is the actual directory inventory and `validation/v2_validate.py:load_batch`, which independently treats `SCHEDULE_RESULTS.json` as supervisor metadata and excludes it from worker filenames. The supervisor's `registered_jobs` value is 54. Its `completed_requests` field counts saved request objects, so it is not used as the completion denominator. Its mutable `started_utc` is not used as a true batch start.

All first-attempt output bytes remain at their original paths and are also preserved under `a1_attempt1/`. That directory contains an exact copy of the executed script with SHA256 `6b20913428c37230572114fabb18d1845113c86ee8e88bb098379ef8000e1373`, matching both the root ledger start record and the first output manifest. This source copy was reconstructed by reversing the known subsequent metadata-only patch and accepted only after its hash matched the recorded execution digest. No V2 file was changed.

The fix classifies `SCHEDULE_RESULTS.json` as pinned supervisor metadata, checks its roster paths, and excludes it from the worker glob. No unit, exclusion, winner, timing, or parent-selection calculation was changed. A separate metadata-only update records the audit environment, differentiates merely hashed files from expected-hash matches, and explicitly limits the command to at most 120 seconds/2 GiB.

The root scheduler should rerun into the fresh directory `v3/resumed/reports/a1_verified`. The authoring agent has not run that pass. The original failed attempt remains in the computation budget and evidence. Success must be determined from the fresh run's exit status and report.
