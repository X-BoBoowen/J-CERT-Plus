# H/G memory-instrumentation cost attribution

## Scope and initial finding

This report concerns performance attribution, not gain-certificate correctness. The frozen H/G measurements include recursive memory-report construction inside the service request. Static inspection establishes that H and G incur different quantities of this instrumentation. Consequently, the measured 2.407142 ratio of summed complete-service times describes the **actual instrumented implementations**; it must not be presented as an isolated speedup from the new access inequalities or search policy.

No source, freeze or raw measurement is modified for this review. Root owns the one prescribed Alpha/slow diagnostic process, using H followed by G in fresh sessions and preserving each original memory-report call. This is a flow attribution diagnostic, not an additional formal timing repeat or a measurement of an implementation with reporting disabled.

## Static call graph and phase membership

| Report work | Source call sites | Expected calls per Alpha/slow Q4 arm | Existing exclusive phase |
|---|---|---:|---|
| H initial frontier observations | `a2_access.py:85,94` → `Access.observe_frontier` → `MixedFrontier.memory` | 8 | Request `other`, before online start |
| H version-open observation | `a2_access.py:130` → same chain | 60 | `candidate_access` |
| H version-finish observation | `a2_access.py:190` → same chain | 60 | Online `other` |
| G version-finish observation | `g_access.py:282` → `GAccess._observe_memory` | 60 | Online `other` |
| G final request observation | `g_access.py:305` → `GAccess._observe_memory` | 4 | Request-end `other` |
| Common sparse-catalog report | `a2_session.py:259` → `AllCatalog.memory` | 4 per arm | Request-end `other` |
| Common cache/log reports | `a2_session.py:261–263` → `lp.store_bytes` | 12 per arm | Request-end `other` |

The expected counts assume the observed Alpha/slow contract of four requests and fifteen accepted edits per request. They are predictions from source, not substitutes for the diagnostic's recorded call counts.

`a2_session.py:137–138` encloses H's version opening in `candidate_access`. Within it, `a2_access.py:127–128` encloses the frontier constructor in `frontier_prepare`; the subsequent observation is outside that nested phase. `common.py:63–92` uses exclusive nested ledger timings, so the constructor is subtracted from the outer `candidate_access` charge. The observation is not subtracted and remains in `candidate_access`.

The finish call at `a2_session.py:159` has no named phase. Its wall time is included in the residual `other` amount and in the online window. Final access/catalog/cache/log report generation at `a2_session.py:255–263` occurs after the online window and before request completion. It is paid by request `other`, and therefore by the reported reset/opinion remainder even though it is not numerical opinion work.

## What is being measured

`MixedFrontier.memory` (`a2_catalog.py:421–444`) visits the entire insertion heap and sparse flip order on every observation, recursively counting Python containers and scalar keys. The insertion heap has a head for each triangular row at construction (`a2_catalog.py:318–320`), so repeated observations traverse an O(n) container even when very few candidates are emitted. The shared catalog is deliberately excluded from that frontier walk.

`GAccess._observe_memory` (`g_access.py:285–302`) walks its flip-order list and, when present, the actually created block heap and node summaries. G also performs fewer observations: none in `begin` or `open_version`, one per finish, and one at final request reporting. Both traversal size and observation frequency therefore differ between methods.

`_python_size` (`a2_catalog.py:253–267`) recursively visits containers using a local `seen` set and `sys.getsizeof`. `lp.store_bytes` (`baseline_r15/experimental_records/evidence_supplement_20261124/source/legacy_v6/tools/long_promotion.py:130–145`) similarly traverses actual cache and decision-log objects through a locally recursive function.

The resulting memory values update only `frontier_memory`, `max_frontier_bytes` and returned report dictionaries. Searches for those fields in `a2_access.py`, `g_access.py` and `a2_session.py` show no use in candidate validity, bound formation, cutoff selection, positivity, canonical resolution or transport. These walks are reporting work, not required mathematical certificate work. Their time is nevertheless genuinely paid in the measured implementation.

## Disjoint timer scopes

The recommended additive timer set is:

1. `MixedFrontier.memory` for H's frontier-size walks.
2. `GAccess._observe_memory` for G's frontier-size walks.
3. `AllCatalog.memory` for common sparse-catalog reporting.
4. `lp.store_bytes` for common cache and log reporting.

Those four targets do not call one another on the inspected service path. Do not additionally add `Access.observe_frontier`, `GAccess.memory`, enclosing begin/open/finish calls, recursive `_python_size` calls, or nested frontier-build phase times: each would duplicate work already included in the selected scopes or main phase ledger. Cheap caller-context labels can distinguish begin/open/finish without timing the enclosing methods.

The diagnostic can report the observed instrumented service time and the sum of the disjoint report timers. Their arithmetic difference is a **diagnostic residual** from the same execution. It is not an observed runtime of reporting-disabled software: the traversal and allocations still happened, wrappers add overhead, cache and allocator effects remain, and method order is fixed H then G. No corrected five-cell timing ratio should be synthesized by subtracting this one-cell diagnostic from the frozen batch.

One process's `ru_maxrss` is cumulative. Fresh sessions do not reset that process high-water mark, so this diagnostic cannot produce independently comparable per-arm peak RSS. The original isolated worker RSS measurements retain their original scope.

## Numerical and scientific limits

The new G bound and independent partition may reduce actual search work, while also making memory reporting cheaper. The inclusive timing result combines these effects. Counters and the disjoint profile can explain their observed contributions; they do not establish how an optimized H implementation with inexpensive or less frequent reporting would compare. That counterfactual remains unmeasured. The accepted trajectories and all certificate limitations remain exactly those of the frozen batch.

## Observed diagnostic outcome

Root executed the prespecified profile and retained it in `v3/resumed/reports/memory_accounting_profile.json`. The script is `v3/resumed/analysis/profile_memory_accounting.py`, SHA-256 `3ed7d6f674be7493a2aa1b137d2af2fa20e5a2e8c988eb307c382360e24282ea`. The independent supervisor record is `v3/runs/resumed_single_flow_accounting_profile/record.json`: completed, exit 0, 4.723060338 seconds of whole-process wall, one numerical thread, CPU 0 and a 2 GiB address-space limit. Its runtime commit and 138-member runtime-source digest match the original batch.

The actual profile wraps `Access.observe_frontier` for H rather than its inner `MixedFrontier.memory`. That scope includes the same expensive walk plus assigning the report and updating its observed maximum; the inner method is not separately timed. The other three scopes are exactly those recommended above. The wrapper's depth guard rejects unexpected overlap (`profile_memory_accounting.py:42–62`). This makes the reported accounting sum disjoint on the observed path. Original call outputs are returned unchanged, no work is disabled, and wrappers are restored in a `finally` block. Each arm uses a new session and factor, with H preceding G in the same process.

| Diagnostic quantity | H seconds | G seconds |
|---|---:|---:|
| Inclusive service in this diagnostic | 2.575980943 | 1.053011183 |
| Frontier deep-report calls | 1.401416256 | 0.128913514 |
| Common catalog reports | 0.025406414 | 0.026382470 |
| Common cache/output reports | 0.004803747 | 0.004655664 |
| Sum of disjoint deep-report timers | 1.431626417 | 0.159951648 |
| Arithmetic service residual after subtraction | 1.144354526 | 0.893059535 |

Observed call counts are **128 H frontier reports and 64 G frontier reports**, exactly matching the static prediction. Both arms perform four catalog reports and twelve cache/output reports. Each arm's accepted edit/parent/child sequence and terminal status match its frozen formal worker, as checked by `profile_memory_accounting.py:85–98`.

The diagnostic's inclusive H–G gap is approximately **1.522970 seconds**. Its difference in deep-report time is approximately **1.271675 seconds**, or **83.5% of that gap**. Almost all of that accounting difference is frontier reporting; the common catalog and cache/output report costs are close. This directly supports a materially narrower interpretation of the original aggregate: the current implementation is cheaper in inclusive service, but a large part of one representative cell's observed advantage comes from diagnostic reporting work. It does not establish that 83.5% of the five-cell aggregate has the same cause.

The residuals in the table are only arithmetic residuals of the same instrumented executions. They are not independently observed reporting-disabled runtimes, and their ratio must not be offered as a new uninstrumented speedup. Allocation/cache effects, wrapper overhead, and fixed method order remain. Structural setup itself also differs in this diagnostic, so the remaining service difference cannot be assigned wholly to search or to a particular inequality. No second profile, extra formal repeat, source optimization or corrected aggregate is justified by this one diagnostic alone.

## Recommended next single focus

**Correct the performance evidence before changing numerical completion behavior.** The present batch establishes consistent accepted decisions and preserves an explicit safe unresolved result. It does not establish a production numerical defect needing immediate repair. In contrast, attribution of the main new performance result is now demonstrably confounded by removable reporting work, which directly affects the decision about G's incremental algorithmic value.

For the current delivery, the correction is documentary: label the 2.407142 complete-service aggregate as inclusive of the existing instrumentation, disclose this single-flow attribution, and leave uninstrumented H/G value undecided. Retain the unresolved Alpha parent and the interval-validation caveats without asserting improved completion.

If a subsequent experiment is authorized, the single implementation objective should be a common, explicitly specified low-overhead memory-accounting policy for H and G. Expensive recursive snapshots can be reserved for a separately charged diagnostic, while constant-time counters and isolated-worker RSS retain their stated measurement scopes. Any reduced or differently sampled payload reporting must be named honestly; it must not preserve an inaccurate claim of the old observed maximum. The new policy should be frozen symmetrically and subjected to the same acceptance/version regression gate before a new current-environment paired comparison. The old batch remains an unchanged measurement of the old instrumented contract; it is not retrospectively corrected by subtraction.

Numerical completion of the actual Alpha overlap remains a separate valuable question, but pursuing it simultaneously would alter decision behavior, potentially create newly accepted decisions, and require new independent full-catalog checks. Combining that change with an instrumentation correction would make the next performance comparison harder to interpret. No further execution or runtime modification is proposed within the completed V3 batch. No numerical process was run by this reviewer.
