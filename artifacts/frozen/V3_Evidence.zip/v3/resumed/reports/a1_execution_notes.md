# A1 audit execution and output contract

The analysis program is ready for the root scheduler. The authoring agent has not run its full data pass, any numerical solve, a replay checker, a statistical summary, or a performance task. A Python AST parse was used only to check source syntax. The parent-state selection was extracted from seven fixed pieces of existing metadata before new solves and saved separately.

## Scheduled command

```sh
python /workspace/scratch/faa1a8a62f06/v3/resumed/analysis/a1_log_audit.py \
  --code-root /workspace/scratch/faa1a8a62f06/v2_received/code \
  --evidence-root /workspace/scratch/faa1a8a62f06/v2_received/evidence \
  --inputs-root /workspace/scratch/faa1a8a62f06/v2_received/inputs \
  --selection /workspace/scratch/faa1a8a62f06/v3/resumed/reports/state_selection_proposal.json \
  --out-dir /workspace/scratch/faa1a8a62f06/v3/resumed/reports \
  --max-seconds 120 \
  --memory-mib 2048
```

This is one read-only diagnosis process under the shared V3 ledger. The script uses a single thread and a 2 GiB address-space cap. It imports NumPy only for retained NPZ arrays, without importing the production service or solving any system. Output files are created exclusively. If an output already exists, use a fresh output directory; do not replace a prior observation.

Exit code 0 means that the source/input, structural record and accounting checks passed. Exit code 2 means that the report contains issues. These statuses do not mean all original numerical intervals were independently proved. A runtime exception or resource interruption is a separate failed diagnostic and must remain in the ledger.

## Files

| Output | Scope |
|---|---|
| `a1_summary.json` | Independently recomputed denominators, method/cell winners, strict global-bound exclusions, one-state unresolved grouping, original-environment cost components, source unit mapping, limitations and issues |
| `a1_decision_ledger.jsonl` / `.csv` | One row per saved accepted/terminal decision, including request, parent/child, edit type, integer and physical intervals, witnesses, work counters, available stage times, binding and exclusion status |
| `a1_request_ledger.jsonl` | Individual request completion, counters and full exclusive phase times; online phases are retained as an overlapping subset |
| `a1_worker_ledger.jsonl` | Frozen job identity, independently recomputed Q4 completion and complete-service or partial-work cost |
| `a1_stage_costs.csv` | Actual historical stage measurements with timing scope and a warning against adding nested timers to parent buckets |
| `a1_binding.json` | File SHA256/size pins for code, protocol, raw jobs/results and inputs; exact retained graph and opinion checks |
| `a1_state_selection_check.json` | Raw-record match of the previously frozen seven parents, with selection unchanged |
| `a1_report.md` | Concise findings derived from the above outputs |
| `a1_output_manifest.json` | Hashes and byte sizes for outputs; manifest excludes itself |

All principal records include `source`, `code_digest`, `protocol_digest`, `input_digest`, `scope`, `status`, `reason` and `cost`. CSV nulls are the literal `null`; structured CSV fields contain JSON. Integer certificate endpoints remain exact integers; physical values are rational strings. JSON `null` is used for absent parent q/r, unknown per-decision total time, unknown insertion-only enumeration/response time and numerical replay not performed.

## Interpretation guardrails

- Internal score endpoints map to physical gain by `SCALE / UNIT²`; the stored decision endpoints already include `SCALE`, so divide them only by `gain_denominator=UNIT²`. Provisional `comparison_resolution.source_lower/source_upper` have not yet been multiplied by `SCALE`.
- The universal insertion upper bound is `4ω=1/4`, using insertion weight `ω=1/16`, not the winner's flip weight. Eligibility checks exact opinion bounds, the signed Laplacian model, legal-prefix/version binding, source hashes, units and the retained full-domain completion certificate.
- A flip winner is counted independently from a flip whose certified lower bound strictly exceeds `1/4`. Failure of this global test is not evidence of family competitiveness and does not disprove a tighter range bound.
- Existing `audit=False` raw records lack parent centers/radii. The parent-state selection uses the six q1 initial fallbacks plus the real Alpha unresolved parent and marks unknown competitiveness explicitly.
- `node_sort` and `heap_build` are separate insertion-only subphases in `MixedFrontier`. The ideal deletion calculation uses them only at valid exclusion epochs. H's epoch-1 `seed_build_phases` and `frontier_build_phases` are the same construction and are counted once.
- `initial_head_filter`, `seed_access`, `candidate_access`, `endpoint_screen`, and response timers mix both edit families. They are not relabeled insertion-only and no candidate/RHS/Gram count is converted into time.
- H already carries the range-based insertion upper envelope in its row frontier. The common `CachedStrict` screen already uses the diagonal nonedge resistance lower bound after candidates are generated. A new independent baseline would change preparation and block-level coverage, rather than introduce that inequality into the implementation for the first time.
- Original-environment complete workers and partial Alpha workers remain separate. No old/new environment speed comparison is made.
