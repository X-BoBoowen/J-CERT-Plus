# Optional D: static backend admission

## Decision

**D is not started. The retained CHOLMOD route is a plausible source-level trial-solution alternative, but no runnable configuration satisfying the current A2 factor interface is available as supplied.** Record this as a dependency/interface admission result, with all numerical stage outcomes and costs unknown. It is neither a CHOLMOD failure nor evidence that CHOLMOD cannot meet 600 seconds and 4 GiB.

For this round, the static evidence does not justify switching the main research recommendation to a scale backend. A prepared D run could answer a limited feasibility question, but preparing it would first require the missing native bridge/header dependency and a small factor adapter. The root scheduler should make any further investment decision using the H/G results; this audit does not provide a performance prediction. No numerical backend was imported, no numerical probe or checker was executed, no compilation or download was attempted, and no runtime source was changed.

## Current route and one retained alternative

| Item | Current A2 route | One source-level alternative |
|---|---|---|
| Root factor | `scipy.sparse.linalg.splu(A.astype(float).tocsc())` | Existing `CholmodFactor(A)` using the retained C bridge's `CHOLMOD_AUTO` analysis/factorization, with final simplicial LDL storage |
| Operator | Actual A2 integer-scaled current operator, `A_int = 16 A_physical` | The same integer-scaled root operator; no rescaling of the certificate contract |
| Subsequent trial solves | Immutable root base solve followed by retained low-rank corrections in `UpdatedFactor.steps` | Retain those same A2 corrections and replace only the immutable root base solve |
| State/response certificate | Quantize the trial solution and evaluate the integer residual against the actual operator | Keep this certificate path unchanged; CHOLMOD convergence or status alone would not certify a decision |
| Availability | Hardcoded by `A2Session.__init__` | Solver wrapper and C source retained, but native bridge and A2 interface adapter absent |

The alternative is one configuration, not a solver or preconditioner search. The retained Linux builder uses `-DJCERT_UPDATE_READY`; it does not enable `JCERT_FORCE_SIMPLICIAL`, so the root factorization is `CHOLMOD_AUTO` followed by the bridge's final simplicial LDL conversion. Native CHOLMOD `change`/`undo` is not part of the proposed integration: the current A2 weighted updater already appends its own low-rank steps. Substituting the whole legacy policy engine would change more than the trial backend and is outside this admission recommendation.

The default route is explicit in `long_promotion.py` lines 117–127 and `a2_session.py` lines 65–66. The latter's request reset uses `copy.copy(self.factor)` and a fresh `steps` list (lines 77–78), and its resource report reads `self.factor.base.nnz` (line 259). `WeightedViews.advance` appends `(Y, inverse)` to `fac.steps` in `weighted_adapter.py` lines 93–111. These are current runtime source observations, not a new numerical measurement.

## Certificate and interface admission

`CholmodFactor.solve(rhs)` accepts a one- or two-dimensional floating RHS with the correct leading dimension and returns a corresponding trial solution. This is compatible with the narrow solve call used by `certified_state` and by response acquisition. `long_promotion.py` lines 167–185 reboxes the state and evaluates `A @ x - s_int * (proof_unit // OPINION_DEN)` using the actual integer operator. `weighted_adapter.py` lines 63–70 checks the response, reboxes it, and evaluates `A @ X - UNIT * U`; the response radius is rounded outward using `SCALE`. Thus a different root solver can, in principle, remain outside the trust boundary if these checks, the operator binding, and all downstream decision checks remain intact. Static inspection is not a validation of that integration.

A direct replacement of `lp.UpdatedFactor` by `CholmodFactor` is not valid under the current API:

- `CholmodFactor` has no `steps` attribute, while request reset, update, and memory accounting require it.
- It has no `base.nnz` property. Its `stored_entries()` method reports occupied native simplicial factor entries, which would require an explicit reporting adapter.
- Its native handle owns a mutable factor and has explicit `clone()`/`close()` semantics. A shallow copy of the wrapper must not silently become an independent owner or a separately mutable factor. Preserving an immutable shared root base and separate Python low-rank step lists is the narrow candidate design.
- Its native `change`/`undo` API uses the supplied edit weight. It is not the current integer-scaled A2 update path and has not been admitted for that role here.

The root/state-only solve interface is therefore plausible before any edit, but a first accepted A2 decision and its child certification still require the factor adapter and validation. No such adapter was written by this audit.

## Native dependency observations

Read-only linker-cache and ELF metadata show an installed runtime at `/usr/lib/x86_64-linux-gnu/libcholmod.so.5.3.1` (also reachable through `/lib/x86_64-linux-gnu/libcholmod.so.5`). Its SONAME is `libcholmod.so.5`. The linker cache includes AMD, COLAMD, CAMD, CCOLAMD, SuiteSparseConfig, BLAS, LAPACK, and GNU OpenMP dependencies. This establishes the presence of native runtime files; it does not establish successful loading or operation of the custom bridge.

| Required item | Observed status |
|---|---|
| Custom `libjcert_cholmod.so` beside `cholmod_backend.py` | Absent |
| Custom bridge elsewhere in the approved workspace | No matching supplied file found by the workspace filename inventory |
| `JCERT_CHOLMOD_LIB` environment override | Unset |
| `/usr/include/suitesparse/cholmod.h` and `/usr/include/cholmod.h` | Absent at both checked paths |
| Header/package files in the approved workspace | No `cholmod.h`, `cholmod.pc`, SuiteSparse development package, or CHOLMOD bridge binary found |
| `/usr/lib/x86_64-linux-gnu/libcholmod.so` development symlink and `pkgconfig/cholmod.pc` | Absent at the checked paths |
| Versioned `libcholmod.so.5.3.1` runtime | Present |

These observations are limited to the approved workspace inventory and the specific standard system metadata paths checked; they do not claim an exhaustive search of the system filesystem.

`cholmod_backend.py` lines 12–36 loads the **custom** library and requires `jc_new`, `jc_clone`, `jc_free`, `jc_modify`, `jc_solve`, and `jc_memory`; `stored_entries()` additionally uses `jc_factor_entries`. Pointing `JCERT_CHOLMOD_LIB` at the system `libcholmod.so.5` is not a substitute for this wrapper ABI.

The retained `src/kernel_probe.py` builder is not a ready admission path. Lines 20–22 pin a SuiteSparse development package and its SHA256; lines 53–65 download it if absent, extract headers, and compile the bridge. That package and those extracted headers are not supplied locally. Moreover, its `TOOLS` variable points to `baseline_r15/experimental_records/legacy_v6/tools`, where the checked `paired_pcg.c` and `cholmod_bridge.c` paths do not exist. The retained sources actually reside under `baseline_r15/experimental_records/evidence_supplement_20261124/source/legacy_v6/tools`. The builder unconditionally compiles the old-path `paired_pcg.c` before attempting CHOLMOD. It was not invoked.

## What a later bounded probe could establish

If a single prepared configuration is later admitted, D can establish whether that configuration reaches root preparation, state solve, residual enclosure, frontier construction, one accepted decision, and independent verification within the prescribed cap. These stages need separate outcomes and costs. Root preparation alone is not Q1 completion; one verified decision is not Q1 or Q4 completion.

The present evidence does not predict factor fill, peak resident memory, solve accuracy, frontier work, or elapsed time on Slashdot. All are `null` in the companion JSON. A current-environment feasibility success cannot be converted into a speedup against the historical 600.106-second root-preparation timeout. A causal backend comparison would need a current-environment matching control, within the one-configuration and total process limits.

The unresolved Alpha pair already has a separate exact structural equality diagnosis, and the current H/G work addresses candidate coverage. A CHOLMOD feasibility result would not close either the service's finite witness-family completion gap or the scope limits of independent interval verification. On the evidence available to this static audit, the incremental value of preparing D is therefore a separate scale feasibility question, not a demonstrated reason to replace the main recommendation.

## Source bindings and scope

The companion `a1_d_backend_static_admission.json` records SHA256 values for the inspected runtime files and the identical immutable original copies of the three legacy factor/bridge files. The inspected files are:

- `/workspace/scratch/faa1a8a62f06/v3_runtime/src/a2_session.py`
- `/workspace/scratch/faa1a8a62f06/v3_runtime/src/weighted_adapter.py`
- `/workspace/scratch/faa1a8a62f06/v3_runtime/src/a2_numeric.py`
- `/workspace/scratch/faa1a8a62f06/v3_runtime/src/kernel_probe.py`
- `/workspace/scratch/faa1a8a62f06/v3_runtime/requirements-research.txt`
- `/workspace/scratch/faa1a8a62f06/v3_runtime/baseline_r15/experimental_records/evidence_supplement_20261124/source/legacy_v6/tools/long_promotion.py`
- `/workspace/scratch/faa1a8a62f06/v3_runtime/baseline_r15/experimental_records/evidence_supplement_20261124/source/legacy_v6/tools/cholmod_backend.py`
- `/workspace/scratch/faa1a8a62f06/v3_runtime/baseline_r15/experimental_records/evidence_supplement_20261124/source/legacy_v6/tools/cholmod_bridge.c`

This report is a static admission record. Numerical process count: **0**. Compilation count: **0**. Backend import count: **0**. Runtime modifications: **0**. Numerical budget consumed by this subtask: **0 seconds**; no numerical stage has a measured time.
