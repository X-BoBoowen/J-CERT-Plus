# V3：必要的文献能力对照与主张边界

本表复用本轮先前已核对的五篇原始论文，未新增论文复现或计时。原 `v3/reports/literature_audit.md` 中“V2 包尚未收到”的描述是当时的历史状态；四个原件现已核验，本表更新 J-CERT+ 一行。未知表示此次核查未建立该能力，不表示能力不存在或不可组合。

| 工作 | 数学单步精确选择 | 有限精度决定证书 | 隐式目录／访问 | 插入与负边翻转 | 跨版本维护 | 独立核验 |
| --- | --- | --- | --- | --- | --- | --- |
| SPGREEDY [S1] | Algorithm 1 是逐步数学 argmax；最终 k 边集合近似保证另列 | 本次未建立 | 显式逐项计算剩余候选 | 原任务范围外 | 更新图与逆矩阵 | 本次未建立 |
| FASTGREEDY [S1] | 选择近似分数最大项 | 本次未建立 | 返回剩余候选的近似分数 | 原任务范围外 | 图变化后重新估分 | 本次未建立 |
| Kaplan 等 [S2] | 针对抽象选择问题 | 本次未建立 | 已有堆、排序行、X+Y 和隐式选择基础 | 图编辑合法域范围外 | 静态任务范围外 | 本次未建立 |
| Zhou 等 signed FJ [S3] | 图编辑选择范围外 | 状态近似保证不等于完整决定证书 | 图编辑目录范围外 | 原任务范围外 | 固定图求解／意见修改 | 本次未建立 |
| Spielman–Srivastava [S4] | 精确编辑选择范围外 | 近似保证不等于此处决定证书 | 共享表示支持全点对近似电阻查询 | 原任务范围外 | 静态任务 | 本次未建立 |
| Durfee 等 [S5] | 精确编辑选择范围外 | 近似保证不等于此处决定证书 | 动态近似电阻查询结构 | unsigned 插入／删除不等于 signed 翻转 | 有动态维护 | 本次未建立 |
| J-CERT+ 当前 H/G | 目标是合法全目录的严格正收益规范赢家；允许 unresolved | 后验整数／有理包围与经过检查的等值见证；本轮微型路径核验 | H 行前沿；G 独立对角块覆盖。均有具体域与有限精度前提 | 本次域为统一 1/16 正插入与根负边翻转 | 共同局部 Gram 传递、请求根复用、当前覆盖重建 | 微型全目录核验；历史预选请求；本轮实际结构见证。未独立数值重放全部决定 |

## 会影响本稿主张的结论

1. SPGREEDY 的单步数学精确性不能与集合级近似保证混淆；不能把“每步精确选择”本身写成本文独有。[S1, Algorithm 1 与 §5–6]
2. 排序行、堆、未见项上界及共享电阻表示已有基础。本文需要举证的是当前 signed 混合合法域、数值可靠性、版本绑定与完整服务成本；单独使用这些基础工具不能承担原创性。[S2, S4, S5]
3. signed FJ 的状态近似／规模结果不能直接转移为本文的全目录编辑决定完成性。既有后端可以是后续试解来源，但必须保留实际残差及决定检查，且需先完成接口与依赖准入。[S3]

H/G 的本轮 2.407 倍结果是含当前观测与报告工作的服务时间比。唯一一次固定流剖析发现深层内存报告解释该诊断内大部分差额，因此不能用此比值直接量化两种覆盖算法本身的速度差。能力表也不能代替 SPGREEDY 等匹配子域的运行比较；本轮没有执行该比较。

## 原文与定位

- **[S1]** Zhu, Bao, Zhang, *Minimizing Polarization and Disagreement in Social Networks via Link Recommendation*, NeurIPS 2021。Algorithm 1；Algorithms 2–3；Lemma 5.1；Theorem 6.1。[官方 PDF](https://proceedings.neurips.cc/paper_files/paper/2021/file/101951fe7ebe7bd8c77d14f75746b4bc-Paper.pdf)
- **[S2]** Kaplan, Kozma, Zamir, Zwick, *Selection from Heaps, Row-Sorted Matrices, and X+Y Using Soft Heaps*, SOSA 2019。Theorems 3、8、14。[官方记录](https://drops.dagstuhl.de/entities/document/10.4230/OASIcs.SOSA.2019.5)
- **[S3]** Zhou et al., *Friedkin-Johnsen Model for Opinion Dynamics on Signed Graphs*, arXiv:2407.10680v2。§II-B 的 ±1 边函数，Lemma IV.9，Problem 1，Theorem V.2。[指定版本 PDF](https://arxiv.org/pdf/2407.10680v2)
- **[S4]** Spielman–Srivastava, *Graph Sparsification by Effective Resistances*, arXiv:0803.0929。Theorem 2 的高概率同时近似，不是全点对精确电阻。[原始记录](https://arxiv.org/abs/0803.0929)
- **[S5]** Durfee et al., *Fully Dynamic Effective Resistances*, arXiv:1804.04038。Theorem 1.1；无权、无向多重图和 oblivious adversary 的前提。[原始记录](https://arxiv.org/abs/1804.04038)

原检索定位与版本限制保存在 `v3/reports/literature_sources.json`。本表不是全领域首创性的穷尽检索。
