# Frozen H/G result audit

Metadata gate: **gate_closed**; 63,502 checks, 2 failures.

The frozen roster contains 12 workers: 10 complete Q4 results and 2 partial or missing results. There are 48 returned requests, 696 accepted decisions and 0 eligible complete Q4 pairs.

No genuinely new accepted decisions relative to retained V2.

All returned accepted edit/parent/child and input/contract identities compared with every retained matching V2 D/S/H repeat. This is regression evidence, not a fresh independent proof of every historical decision.

The production checker's nonpoint gain path checks interval intersection, not containment of every published endpoint; matching trajectories do not close that limitation.

## Complete Q4 comparisons

| Graph | Stream | H status | G status | H service s | G service s | H/G |
|---|---|---|---|---:|---:|---:|
| Alpha | independent | completed_budget | completed_budget | 2.494096 | 0.950036 | — |
| Alpha | signed-neighbor | unresolved | unresolved | — | — | — |
| Alpha | slow | completed_budget | completed_budget | 2.564267 | 0.997753 | — |
| OTC | independent | completed_budget | completed_budget | 4.101283 | 1.714629 | — |
| OTC | signed-neighbor | completed_budget | completed_budget | 4.346463 | 1.843707 | — |
| OTC | slow | completed_budget | completed_budget | 3.960800 | 1.750159 | — |

## Costs and limits

Only both-complete Q4 pairs have service ratios. All setup/request costs, partial work and supervisor wall remain visible. Metered solves and nested access timings overlap exclusive phases and must not be added twice.

Worker ru_maxrss is the reported process peak; supervisor RSS is a sampled lower observation. Access payload snapshots are not total peak memory or a worst-case memory bound.

All scheduled jobs, including unresolved and missing/failed jobs, are retained in `hg_workers.csv`; the supervisor wall is separate from a possibly incomplete service prefix. The request, phase, counter, access-event and memory tables retain their measurement scopes. Current versus historical timing ratios are not computed.

## Prespecified parent observations

Seven preselected parents; recorded G caps converted by 16/SCREEN^2. Failure of the global bound does not prove both families competitive. No numerical parent reconstruction in this analysis.

Observed caps are available for 7 of the 7 prespecified rows; full events and exact physical fractions are in `hg_selected_parents.json`.

## Interval and trajectory evidence

Differing endpoint counts by comparison: `{"H_vs_G": 76, "current_vs_V2": 708}`. Each difference is retained in `hg_interval_differences.csv`; a difference is not itself an invalid interval. The decision ledger lists every accepted edit and its matching historical sources, while the request ledger compares complete accepted sequences and terminal outcomes.

No numerical solver, gain computation, fresh independent decision checker or numerical import is run by this metadata analysis.

## Failed metadata checks

See `hg_summary.json` for every failed scope, code and detail. All paired ratios remain withheld.
