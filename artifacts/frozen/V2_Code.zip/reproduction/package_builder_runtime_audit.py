#!/usr/bin/env python3
"""Create and verify the three J-CERT+ V2 research packages.

This builder must not be executed while measurements are running.  It has two
explicit release gates so that preparing this source file does not accidentally
start filesystem inventory, copying, hashing, compilation, or imports.

Inventory, only after timing release:
    python package_builder_runtime_audit.py --timing-released --mode inventory
Build, only after root also declares that validation outputs are final:
    python package_builder_runtime_audit.py --timing-released --final-ready

No numerical workload, benchmark, historical replay, or test suite is run here.
All writes are confined to new paths in --delivery.  Sources are never modified.
"""

import argparse
import csv
import datetime as dt
import hashlib
import importlib.metadata
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile


DEFAULT_WORKSPACE = Path("/workspace/scratch/faa1a8a62f06")
ARCHIVE_BASENAME = "J_CERT_Plus_A2_Exact_Tie_Revision_20261125"
RUNTIME_COMMIT = "4c2c7b7"
TIE_COMMIT = "531522d09b962286afdcde9038ad1a1b0b5d90fa"
INPUT_BINDING_COMMIT = "9de16a76f5cddcdd4aba0c82d555f2ed42e46fe2"
A2_COMMIT = "365bc8e"
STAMP = "20261126"
ZIP_NAMES = {
    "CODE": f"J_CERT_Plus_V2_Code_{STAMP}.zip",
    "EVIDENCE": f"J_CERT_Plus_V2_Evidence_{STAMP}.zip",
    "INPUTS": f"J_CERT_Plus_V2_Inputs_{STAMP}.zip",
}
FREEZE_FILES = (
    "CODE_FREEZE.json", "PROTOCOL.json", "PRE_REGISTRATION.json",
    "SEED_DRAW.json", "INPUTS.json", "A_JOBS.json",
)
TEXT_SUFFIXES = {
    ".py", ".c", ".h", ".md", ".txt", ".rst", ".tex", ".bib",
    ".json", ".jsonl", ".csv", ".tsv", ".yaml", ".yml", ".toml",
    ".ini", ".cfg", ".sh", ".cmake", ".in", ".log", ".svg",
    ".stdout", ".stderr", ".out", ".err", ".patch",
}
IGNORED_COMPONENTS = {".git", "__pycache__", ".pytest_cache", ".mypy_cache"}
REQUIRED_IMPORTS = (
    "src.common", "src.a2_catalog", "src.a2_access", "src.a2_numeric",
    "src.exact_ties", "src.a2_session", "src.a2_checker", "src.v2_runner",
)


def fail(message):
    raise RuntimeError(message)


def utc_now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def safe_relative(value):
    text = str(value).replace("\\", "/")
    path = PurePosixPath(text)
    if (not text or path.is_absolute() or ".." in path.parts
            or any(part in {"", "."} for part in text.split("/"))
            or ":" in path.parts[0]):
        fail(f"Unsafe package path: {value!r}")
    return path.as_posix()


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def json_read(path):
    with Path(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def json_write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True, ensure_ascii=False)
        handle.write("\n")


def text_write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(value)
        if value and not value.endswith("\n"):
            handle.write("\n")


def run_command(command, *, cwd=None, env=None, timeout=180):
    result = subprocess.run(
        [str(part) for part in command], cwd=cwd, env=env, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout,
        check=False,
    )
    report = {
        "command": [str(part) for part in command],
        "returncode": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
    }
    if result.returncode:
        fail("Command failed: " + json.dumps(report, ensure_ascii=False))
    return report


def regular_files(root):
    root = Path(root)
    if not root.exists():
        return []
    if root.is_symlink():
        fail(f"Refusing a symlink source: {root}")
    if root.is_file():
        return [root]
    files = []
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if any(part in IGNORED_COMPONENTS for part in rel.parts):
            continue
        if path.is_symlink():
            fail(f"Refusing a symlink source: {path}")
        if path.is_file() and path.suffix not in {".pyc", ".pyo"}:
            files.append(path)
    return files


def find_source_map(value):
    matches = []
    def visit(node):
        if isinstance(node, dict):
            if "source_files_sha256" in node:
                matches.append(node["source_files_sha256"])
            for key, child in node.items():
                if key != "source_files_sha256":
                    visit(child)
        elif isinstance(node, list):
            for child in node:
                visit(child)
    visit(value)
    if len(matches) != 1 or not isinstance(matches[0], dict):
        fail("CODE_FREEZE must contain exactly one source_files_sha256 mapping")
    output = {}
    for name, digest in matches[0].items():
        rel = safe_relative(name)
        if not re.fullmatch(r"[0-9a-f]{64}", str(digest)):
            fail(f"Invalid frozen SHA-256 for {name}")
        output[rel] = digest
    if not output:
        fail("Frozen source mapping is empty")
    return output


def fixture_entries(manifest):
    fixtures = manifest.get("fixtures")
    if isinstance(fixtures, dict):
        entries = list(fixtures.values())
    elif isinstance(fixtures, list):
        entries = fixtures
    else:
        fail("Input manifest has no fixtures object/list")
    if not all(isinstance(entry, dict) and "file" in entry for entry in entries):
        fail("Every fixture entry must name its file")
    return entries


class Plan:
    def __init__(self, kind):
        self.kind = kind
        self.entries = {}
        self.notes = []

    def add(self, source, relative, source_role, *, expected_sha256=None):
        source = Path(source)
        relative = safe_relative(relative)
        if not source.is_file() or source.is_symlink():
            fail(f"Required regular source file is unavailable: {source}")
        if self.kind == "EVIDENCE" and source.suffix.lower() == ".npz":
            fail(f"An NPZ was selected for Evidence: {source}")
        entry = {
            "source": source,
            "path": relative,
            "source_role": source_role,
            "expected_sha256": expected_sha256,
        }
        previous = self.entries.get(relative)
        if previous is not None:
            if previous["source"].resolve() != source.resolve():
                fail(f"Ambiguous package destination {relative}: "
                     f"{previous['source']} versus {source}")
            if expected_sha256:
                previous["expected_sha256"] = expected_sha256
            return
        self.entries[relative] = entry

    def tree(self, source_root, root, source_role, *, suffixes=None, predicate=None):
        for source in regular_files(source_root):
            if self.kind == "EVIDENCE" and source.suffix.lower() == ".npz":
                continue
            if suffixes is not None and source.suffix.lower() not in suffixes:
                continue
            relative = source.relative_to(root).as_posix()
            if predicate is not None and not predicate(source, relative):
                continue
            self.add(source, relative, source_role)

    def description(self):
        return {
            "kind": self.kind,
            "payload_member_count": len(self.entries),
            "payload_bytes": sum(item["source"].stat().st_size
                                 for item in self.entries.values()),
            "paths": sorted(self.entries),
            "notes": self.notes,
        }


def resolve_manifest_fixture(base, root, entry):
    value = Path(str(entry["file"]))
    if value.is_absolute():
        fail(f"Absolute input fixture path is not portable: {value}")
    source = (base / value).resolve()
    try:
        relative = source.relative_to(root.resolve()).as_posix()
    except ValueError:
        fail(f"Input fixture escapes its source root: {value}")
    if source.suffix.lower() != ".npz":
        fail(f"Input fixture is not an NPZ: {value}")
    expected = entry.get("npz_sha256")
    if expected is None:
        possible = entry.get("sha256")
        if isinstance(possible, str) and re.fullmatch(r"[0-9a-f]{64}", possible):
            expected = possible
    return source, relative, expected


def select_plans(args):
    workspace, original, runtime = args.workspace, args.original, args.runtime
    plans = {kind: Plan(kind) for kind in ZIP_NAMES}
    code, evidence, inputs = (plans[key] for key in ("CODE", "EVIDENCE", "INPUTS"))
    freeze = json_read(runtime / "v2/CODE_FREEZE.json")
    source_map = find_source_map(freeze)

    # Full current source and every file named by the actual source freeze.
    code.tree(runtime / "src", runtime, "frozen_runtime")
    for relative, digest in source_map.items():
        code.add(runtime / relative, relative, "frozen_runtime", expected_sha256=digest)
    for dirname in ("tests", "proofs", "docs"):
        code.tree(runtime / dirname, runtime, "frozen_runtime", suffixes=TEXT_SUFFIXES)
    for relative in ("reports/A2_COVERAGE_PROOF.txt", "reports/TIE_EQUALITY_PROOF.txt",
                     "reports/ACCESS_BUDGET_PROOF.txt"):
        code.add(runtime / relative, relative, "frozen_runtime")
    for source in sorted(runtime.iterdir()):
        if (source.is_file() and not source.is_symlink()
                and (source.name.lower().startswith(("readme", "license", "copying", "requirements"))
                     or source.name in {"Makefile", "pyproject.toml", "setup.py", "setup.cfg",
                                        "pytest.ini", "tox.ini", ".gitignore", "CMakeLists.txt"})):
            code.add(source, source.name, "frozen_runtime")
    for name in FREEZE_FILES:
        path = runtime / "v2" / name
        code.add(path, f"v2/{name}", "frozen_runtime")
        evidence.add(path, f"v2/{name}", "frozen_runtime")

    # Retain complete requested old trace directories, excluding input arrays.
    required_old_dirs = ("raw/a2_tie_retest", "raw/a2_confirmation")
    for relative in required_old_dirs:
        if not (original / relative).is_dir():
            fail(f"Required historical trace directory missing: {relative}")
        evidence.tree(original / relative, original, "original_immutable")
        record_names = [path.name for path in regular_files(original / relative)
                        if re.fullmatch(r"[0-9].*\.json", path.name)]
        if len(record_names) != 108:
            fail(f"Expected 108 numbered historical records in {relative}, found {len(record_names)}")
    for relative in ("raw/a2_tie_fixed_replay", "raw/a2_development"):
        evidence.tree(original / relative, original, "original_immutable")
    for source in regular_files(original / "protocol"):
        if source.suffix.lower() in TEXT_SUFFIXES and re.search(r"a2|tie", source.name, re.I):
            evidence.add(source, source.relative_to(original).as_posix(), "original_immutable")
    for dirname in ("reports", "review", "results", "summary", "summaries", "figures", "figure_data"):
        evidence.tree(
            original / dirname, original, "original_immutable", suffixes=TEXT_SUFFIXES,
            predicate=lambda path, rel: bool(re.search(r"a2|tie|frozen.input|source.check", rel, re.I)),
        )
    for relative in ("reports/FROZEN_FAILURE_ANALYSIS.txt", "reports/A1_CLOSURE.txt",
                     "reports/ACCESS_BUDGET_PROOF.txt", "review/ORIGINAL_OTC_OVERLAP_REPRODUCTION.json",
                     "review/INPUT_ARCHIVE.json", "review/OFFLINE_VALIDATOR_MUTATIONS.json"):
        evidence.add(original / relative, relative, "original_immutable")
    for name in ("a2_tie_complete_cost.svg", "a2_tie_cost_memory.svg", "a2_tie_coverage.svg",
                 "a2_tie_plot_data.json"):
        relative = f"figures/tie_revision/{name}"
        evidence.add(original / relative, relative, "original_immutable")
    supplement = "baseline_r15/experimental_records/evidence_supplement_20261124"
    event_data = original / supplement / "source/legacy_v6/data"
    event_pattern = re.compile(
        r"(?:directional_stress_(?:alpha|bio)_(?:1|4|16|64)_(?:events|steps|grid)"
        r"|flip_stress(?:_alpha)?_(?:events|steps))\.csv"
    )
    for source in regular_files(event_data):
        if event_pattern.fullmatch(source.name):
            evidence.add(source, source.relative_to(original).as_posix(), "original_immutable")
    directional_summary = original / supplement / "evidence/directional"
    if not directional_summary.is_dir():
        fail("Archived directional summary directory is missing")
    evidence.tree(directional_summary, original, "original_immutable", suffixes=TEXT_SUFFIXES)

    # Include the final V2 outputs and relevant local audit products, never data NPZs.
    for relative in ("v2/raw_a", "v2/raw_b", "v2/logs", "v2/validation"):
        evidence.tree(
            runtime / relative, runtime, "frozen_runtime_results",
            predicate=lambda path, rel: not path.name.startswith("."),
        )
    for dirname in ("validation", "audit", "evidence_audit", "runtime_audit"):
        evidence.tree(workspace / dirname, workspace, "workspace_audit", suffixes=TEXT_SUFFIXES)
    for name in ("runtime_tests.log", "v2_targeted_tests.log", "v2_a_run.log", "v2_b_run.log"):
        evidence.add(workspace / name, name, "workspace_validation_log")
    if (workspace / "archive_validation.json").is_file():
        evidence.add(workspace / "archive_validation.json", "archive_validation.json", "workspace_audit")
    else:
        evidence.notes.append("archive_validation.json is not yet present at workspace root")
        if args.mode == "build":
            fail("Final archive_validation.json is required before building packages")

    # Paths supplied by other reviewers are explicit; no wholesale baseline tree.
    for value in args.extra_evidence:
        if value.startswith("original:"):
            base, relative, role = original, value[len("original:"):], "original_immutable"
        elif value.startswith("runtime:"):
            base, relative, role = runtime, value[len("runtime:"):], "frozen_runtime_results"
        elif value.startswith("workspace:"):
            base, relative, role = workspace, value[len("workspace:"):], "workspace_audit"
        else:
            fail("--extra-evidence must start with original:, runtime:, or workspace:")
        relative = safe_relative(relative)
        path = base / relative
        if not path.exists():
            fail(f"Explicit evidence source does not exist: {value}")
        evidence.tree(path, base, role)

    # Exactly the graph artifacts needed by this paper and its retained inputs.
    projected = []
    for source in regular_files(original / "data/projected"):
        relative = source.relative_to(original).as_posix()
        if re.search(r"alpha|otc", relative, re.I):
            inputs.add(source, relative, "original_immutable")
            projected.append(relative)
    projected_npz = [name for name in projected if name.lower().endswith(".npz")]
    if len(projected_npz) != 4:
        fail(f"Expected four Alpha/OTC projected graph NPZs, found {projected_npz}")
    slashdot = "baseline_r15/experimental_records/legacy_v6/datasets/Slashdot.npz"
    inputs.add(
        original / slashdot, slashdot, "original_immutable",
        expected_sha256="78d004ff0f3cab226ef2190244a3f59675337adcbd7c445fa98a343964ba86b0",
    )
    old_binding_path = original / "protocol/A2_TIE_RETEST_INPUTS.json"
    old_entries = fixture_entries(json_read(old_binding_path))
    old_paths = set()
    for entry in old_entries:
        source, relative, expected = resolve_manifest_fixture(old_binding_path.parent, original, entry)
        inputs.add(source, relative, "original_immutable", expected_sha256=expected)
        old_paths.add(relative)
    if len(old_paths) != 12:
        fail(f"Expected twelve distinct retained old opinion NPZs, found {len(old_paths)}")
    new_binding_path = runtime / "v2/INPUTS.json"
    new_entries = fixture_entries(json_read(new_binding_path))
    new_paths = set()
    for entry in new_entries:
        source, relative, expected = resolve_manifest_fixture(new_binding_path.parent, runtime, entry)
        inputs.add(source, relative, "frozen_runtime_inputs", expected_sha256=expected)
        new_paths.add(relative)
    if len(new_paths) != 7:
        fail(f"Expected seven distinct new V2 opinion NPZs, found {len(new_paths)}")
    for source in regular_files(runtime / "v2/inputs"):
        relative = source.relative_to(runtime).as_posix()
        if source.suffix.lower() == ".npz" and relative not in new_paths:
            fail(f"Unbound V2 opinion NPZ exists: {relative}")
        inputs.add(source, relative, "frozen_runtime_inputs")

    return plans, source_map, {
        "projected_graph_artifacts": sorted(projected),
        "old_opinion_paths": sorted(old_paths),
        "new_opinion_paths": sorted(new_paths),
        "slashdot_path": slashdot,
        "frozen_source_file_count": len(source_map),
    }


REPRODUCTION_README = r"""# J-CERT+ V2 research package

## What is frozen, and what reproduction establishes

The executable V2 code is the frozen commit `4c2c7b7` (its full object identity is
recorded in PACKAGE_MANIFEST.json).  The historical exact-tie runtime was
`531522d09b962286afdcde9038ad1a1b0b5d90fa`; the subsequent retained-input binding
was `9de16a76f5cddcdd4aba0c82d555f2ed42e46fe2`.  The latter added an input manifest,
not a new numerical runtime.  Original A2 code is identified by commit `365bc8e`.
Exact binary-capable Git patches from both code baselines and a full history
bundle are included in `reproduction/`.

Re-executing the supplied opinions reproduces the same inputs.  It is not a new
unseen confirmation.  The retained twelve-cell retest is historical evidence.
The seven V2 opinion files contain six small-graph streams and one Slashdot
stream; each small stream has four requests, with three method arms and three
timing repetitions.  Repetitions do not create independent opinion streams.
Consult the frozen protocol and final evidence for status, resource limits,
unresolved outcomes, and the actual population of completed jobs.

The V2 input-boundary change admits `n <= 82140`.  The A2 numerical backend remains
the existing sparse SuperLU factor with low-rank updates and the existing fixed
directional scoring path.  This is not a new preconditioner or solver.  Neither
the code package nor these instructions assert universal request completion.

## Three separate, root-relative packages

Extract Code, Evidence, and Inputs into three fresh directories if they are to be
inspected independently.  Each ZIP is independently extractable and has its own
uniquely named manifest.  For execution or source-bound record checking, combine
them in a new directory using `reproduction/overlay_packages.py`.  Every payload
path is relative to the research root: `src/`, `baseline_r15/`, `data/`, `raw/`,
`protocol/`, `v2/`, and audit directories retain their meanings.  Identical
cross-package files may be shared; a different file at an existing path is an
error.  Do not overwrite the immutable originals or modify the frozen inputs.

Code contains the full current `src/`, every asset actually named by
`v2/CODE_FREEZE.json:source_files_sha256` (including legacy Python, C, and exact
native libraries), available tests and proof/documentation sources, pinned
requirements, exact patches, and the Git bundle.  Evidence contains the retained
trace directories and V2 outputs plus relevant audits.  Input arrays are in the
Inputs ZIP; Evidence deliberately contains no NPZ members.  Internal manifests
bind all payload members by byte length and SHA-256.  A manifest cannot hash
itself; PACKAGE_MANIFEST.json additionally binds each internal manifest and each
finished ZIP, and reports actual-archive verification results.

## Dependencies and native builds

Use Python 3.12 and the top-level `requirements-research.txt` pins, which are the
research environment specification.  Legacy copied requirements describe older
environments and do not supersede these pins.  The recorded environment used
NumPy 2.3.5, SciPy 1.17.0, psutil 7.2.2, threadpoolctl 3.6.0, SymPy 1.14.0, and
Matplotlib 3.10.8.  Install into a separate environment:

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements-research.txt
```

These pins support source inspection and imports in a separate environment.
Strict experiment replay additionally checks the recorded Python build, resolved
interpreter path, operating-system platform, and package versions.  The frozen
runner also uses CPU affinity 0 for workers and 8 for its supervisor.  A machine
that does not match those bindings may import the code successfully while the
strict worker correctly refuses replay.  Package verification is performed in
the recorded environment; it is not a claim of unchanged performance portability.

The frozen `.so` files are Linux x86-64 ELF assets.  The A2 H/Stream paths do not
call the old native directory interface, but those binaries remain in the
source binding and are retained byte-for-byte.  The source and exact commands
used for fresh verification appear in PACKAGE_MANIFEST.json.  Equivalent build
commands, with paths supplied by the source manifest, are:

```sh
mkdir new-build
legacy=baseline_r15/experimental_records/evidence_supplement_20261124/source/legacy_v6/tools
cc -O3 -fPIC -shared "$legacy/promotion_screen.c" -o new-build/screen.so
cc -O3 -fPIC -shared "$legacy/promotion_index_profile.c" -o new-build/index.so
```

Build into a new directory.  Do not replace a frozen binary and then claim its
original source hash.  Rebuilt native binaries need not be byte-identical across
toolchains.  SciPy's SuperLU and its numerical-library dependencies are provided
by the pinned Python environment; the old C interfaces are separate components.
Other C files named by the freeze are retained because the source binding covers
the historical tool directory.  The verification builds the two C sources for
the two frozen libraries; it does not activate or build dormant alternative
factorization/preconditioning backends.

## Reproduction entry points and resource discipline

`python -m src.v2_runner --help` describes the frozen runner commands.  Read
`v2/PRE_REGISTRATION.json` and `v2/PROTOCOL.json` before running anything.  The
runner verifies frozen source, environment, protocol, roster, seed, and input
bindings.  A reproduction must preserve these checks and its hard resource
limits.  Do not invoke preparation to overwrite a frozen study or draw replacement
inputs after seeing an outcome.  Use a separate destination for reproduced
results.  Inspect the parser and available destination flags before invoking a
worker; the supplied raw evidence is an immutable observation, not a workspace.

For a same-input rerun in a matching environment, create another fresh directory
and overlay Code plus Inputs there, without the Evidence ZIP.  It then has the
frozen V2 manifests and inputs but no prior `v2/raw_a` or `v2/raw_b` directories.
From that new research root, `python -m src.v2_runner run-a` and
`python -m src.v2_runner run-b` are the frozen batch entry points.  They enforce
the original registration and refuse to overwrite an already-started batch.
Running either command is a new execution of the supplied inputs, not part of
the package builder's verification.  An individual recorded job can instead be
run with `worker --job path/to/recorded.job.json --output path/to/new-result.json`;
the worker requires a new output path.  Keep such results separate from the
delivered observations and report their actual environment and resource status.

Historical retest records bind the historical source hashes, not the V2 source
hashes.  Use the supplied history bundle to materialize the recorded historical
commit in another directory when checking those old source bindings.  The
unchanged `baseline_r15/` source/native assets from Code and the corresponding
Inputs/Evidence trees supply the non-Git assets.  Do not substitute the V2
`src/a2_session.py` for its historical version in an old-source check.  The exact
patches make the version difference reviewable.

### Rechecking the delivered V2 observations

The post-measurement wrapper `validation/v2_validate.py` requires a real Git
checkout at the exact frozen V2 commit.  Its default runtime is a sibling
`runtime/` directory beside its `validation/` directory.  A plain ZIP extraction
is not such a checkout.  The following layout makes both requirements explicit;
run it from the directory containing the three ZIPs, using new directory names
and the matching recorded Python environment:

```sh
mkdir package-code
python -m zipfile -e J_CERT_Plus_V2_Code_20261126.zip package-code
git clone package-code/reproduction/RESEARCH_HISTORY_V2.bundle verify-runtime
git -C verify-runtime checkout --detach 4c2c7b7e84c7c03ee56d45453fea6950c94817bd
python package-code/reproduction/overlay_packages.py verify-runtime J_CERT_Plus_V2_Code_20261126.zip J_CERT_Plus_V2_Inputs_20261126.zip J_CERT_Plus_V2_Evidence_20261126.zip
mkdir -p verify-runtime/logs
python -c "from pathlib import Path; Path('verify-runtime/logs/.measurement.lock').open('xb').close()"
recheck_root="$PWD/verify-runtime"
```

The empty lock is created exclusively in this new, inactive checkout.  The
validator opens the existing lock read-only and acquires it nonblocking before
reading evidence.  Do not create or replace it in an active measurement tree.
The overlay preserves the original relative source, graph, opinion, and record
paths and refuses a nonidentical existing file.  The checkout preserves the Git
HEAD identity required by the validator.

Always pass `--runtime` explicitly for this layout.  Also pass a new `--output`
JSON path **inside this copy's `validation/` directory**; arbitrary external
output directories are deliberately rejected.  Aggregation reserves matching
`_cells.csv` and `_requests.csv` names, so those must also be absent:

```sh
python "$recheck_root/validation/v2_validate.py" aggregate --runtime "$recheck_root" --output "$recheck_root/validation/recheck_aggregate.json"
python "$recheck_root/validation/v2_validate.py" chains --runtime "$recheck_root" --output "$recheck_root/validation/recheck_parent_witness.json"
```

An optional independent numerical recheck is a separate operation.  Run the two
prespecified samples serially, with new output names, and report its cost apart
from algorithm service:

```sh
python "$recheck_root/validation/v2_validate.py" full-catalog --runtime "$recheck_root" --sample Alpha --max-seconds 1800 --output "$recheck_root/validation/recheck_full_catalog_Alpha.json"
python "$recheck_root/validation/v2_validate.py" full-catalog --runtime "$recheck_root" --sample OTC --max-seconds 1800 --output "$recheck_root/validation/recheck_full_catalog_OTC.json"
```

The delivered `a_aggregate.json`, `a_parent_witness.json`, and selected numerical
reports remain unchanged.  The wrapper refuses existing output files; use a new
basename or another fresh checkout for a later recheck.  These instructions do
not redraw opinions, change runtime/protocol bytes, or turn same-input replay
into unseen confirmation.  Packaging checks the layout and imports only; it
does not execute these aggregation, chain, or numerical commands.

The package builder itself performs no request, root factorization, historical
replay, or benchmark.  Its fresh-directory verification checks the actual ZIPs,
CRC, safe paths, member counts, bytes, hashes, Python compilation and real module
imports, frozen native-library loading, isolated native compilation, and history
bundle availability.  Exact results are in PACKAGE_MANIFEST.json.

## Test scope and a known legacy fixture limitation

The pre-freeze targeted run reported 117 passing tests, including nine V2 tests.
The prior full run executed 202 tests, with 201 successful tests and one legacy
error because the retained
`A1_CONFIRMATION_PROTOCOL` fixture is absent.  The package does not fabricate that
old protocol.  Relevant tests are retained for transparency, but this package
does not claim that the entire inherited suite passes.  Some integration tests
also need the separate Evidence and Inputs packages overlaid at their original
relative paths.  Fresh package verification is narrower than a complete test
suite and does not replay numerical experiments.  Consult the included validation
logs and TEST_SCOPE.txt for the exact retained scope and any additional limits.
"""


OVERLAY_SCRIPT = r'''#!/usr/bin/env python3
"""Overlay verified packages into a fresh destination; refuse changed files."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile

def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()

def digest_file(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("destination", type=Path)
p.add_argument("archives", nargs="+", type=Path)
a = p.parse_args()
a.destination.mkdir(parents=True, exist_ok=True)
if a.destination.is_symlink():
    raise SystemExit("Destination may not be a symlink")
for archive in a.archives:
    with zipfile.ZipFile(archive) as z:
        infos = z.infolist()
        names = [i.filename for i in infos]
        if len(set(names)) != len(names):
            raise SystemExit("Duplicate ZIP members")
        manifests = [name for name in names if name in {
            "MANIFEST_CODE.json", "MANIFEST_EVIDENCE.json", "MANIFEST_INPUTS.json"}]
        if len(manifests) != 1:
            raise SystemExit("Expected exactly one internal manifest")
        manifest = json.loads(z.read(manifests[0]))
        expected = {e["path"]: e for e in manifest["members"]}
        if set(names) != set(expected) | {manifests[0]}:
            raise SystemExit("Member set differs from manifest")
        bad = z.testzip()
        if bad is not None:
            raise SystemExit("CRC failure: " + bad)
        for info in infos:
            name = info.filename
            path = PurePosixPath(name)
            if (path.is_absolute() or ".." in path.parts or "\\" in name
                    or ":" in path.parts[0] or info.is_dir()
                    or ((info.external_attr >> 16) & 0o170000) == 0o120000):
                raise SystemExit("Unsafe ZIP path: " + name)
            out = a.destination.joinpath(*path.parts)
            for parent in out.parents:
                if parent == a.destination.parent:
                    break
                if parent.is_symlink():
                    raise SystemExit("Symlink in destination: " + str(parent))
            raw = z.read(name)
            actual = digest_bytes(raw)
            if name in expected and (len(raw) != expected[name]["bytes"]
                                      or actual != expected[name]["sha256"]):
                raise SystemExit("Payload hash mismatch: " + name)
            if out.exists():
                if not out.is_file() or out.stat().st_size != len(raw) or digest_file(out) != actual:
                    raise SystemExit("Refusing nonidentical overwrite: " + str(out))
                continue
            out.parent.mkdir(parents=True, exist_ok=True)
            with out.open("xb") as f:
                f.write(raw)
print("Verified package overlay completed")
'''


def generate_code_material(args, code, generated, source_map):
    runtime = args.runtime
    head = run_command(["git", "-C", runtime, "rev-parse", "HEAD"])["stdout"].strip()
    expected_head = run_command(["git", "-C", runtime, "rev-parse", RUNTIME_COMMIT])["stdout"].strip()
    if head != expected_head:
        fail(f"Runtime HEAD changed: expected {expected_head}, found {head}")
    status = run_command(["git", "-C", runtime, "status", "--porcelain", "--untracked-files=no"])["stdout"]
    if status.strip():
        fail("Tracked runtime files differ from frozen HEAD: " + status)
    hashes = {
        "runtime_commit": head,
        "historical_tie_commit": run_command(["git", "-C", runtime, "rev-parse", TIE_COMMIT])["stdout"].strip(),
        "retained_input_binding_commit": run_command(["git", "-C", runtime, "rev-parse", INPUT_BINDING_COMMIT])["stdout"].strip(),
        "original_a2_commit": run_command(["git", "-C", runtime, "rev-parse", A2_COMMIT])["stdout"].strip(),
    }
    reproduction = generated / "reproduction"
    reproduction.mkdir(parents=True, exist_ok=False)
    text_write_new(reproduction / "README_REPRODUCTION.md", REPRODUCTION_README)
    text_write_new(reproduction / "overlay_packages.py", OVERLAY_SCRIPT)
    tests = sorted(path for path in code.entries if path.startswith("tests/"))
    test_scope = (
        "TEST SCOPE AND KNOWN LIMITATION\n\n"
        "Pre-freeze targeted result supplied by the study operator: 117 passed, including 9 V2 tests.\n"
        "Prior full-suite log: 202 executed, 201 successful, one legacy error due to absent\n"
        "A1_CONFIRMATION_PROTOCOL fixture. No replacement fixture has been invented.\n"
        "The package builder does not rerun that suite or any numerical benchmark.\n"
        "Fresh package verification covers source compilation, actual imports, native loading/builds,\n"
        "archive integrity, source bindings, and Git history availability only.\n"
        "All text/code files selected from the runtime tests directory are listed below. Tests may\n"
        "require separately packaged evidence/input overlays and missing historical fixtures.\n\n"
        + "\n".join(tests) + "\n"
    )
    text_write_new(reproduction / "TEST_SCOPE.txt", test_scope)
    json_write_new(reproduction / "SOURCE_BINDING.json", {
        "commits": hashes, "source_files_sha256": source_map,
        "meaning": "Exact V2 frozen source map; package creation does not define a new freeze.",
    })
    for baseline, label in ((TIE_COMMIT, "531522d"), (A2_COMMIT, "365bc8e")):
        patch_path = reproduction / f"EXACT_DIFF_{label}_TO_4c2c7b7.patch"
        with patch_path.open("xb") as handle:
            result = subprocess.run(
                ["git", "-C", str(runtime), "diff", "--binary", "--full-index", baseline, head],
                stdout=handle, stderr=subprocess.PIPE, check=False,
            )
        if result.returncode:
            fail("Git patch creation failed: " + result.stderr.decode("utf-8", "replace"))
    bundle = reproduction / "RESEARCH_HISTORY_V2.bundle"
    bundle_creation = run_command(["git", "-C", runtime, "bundle", "create", bundle, "--all", "HEAD"], timeout=300)
    bundle_heads = run_command(["git", "bundle", "list-heads", bundle])
    builder_copy = reproduction / "package_builder_runtime_audit.py"
    shutil.copyfile(Path(__file__).resolve(), builder_copy)
    for source in regular_files(generated):
        code.add(source, source.relative_to(generated).as_posix(), "generated_reproduction_material")
    return {"commits": hashes, "bundle_creation": bundle_creation, "bundle_heads": bundle_heads}


def stage_plan(plan, target, cross_references):
    target.mkdir(parents=True, exist_ok=False)
    members = []
    for relative, item in sorted(plan.entries.items()):
        source = item["source"]
        before = source.stat()
        output = target / relative
        output.parent.mkdir(parents=True, exist_ok=True)
        digest = hashlib.sha256()
        size = 0
        with source.open("rb") as src, output.open("xb") as dst:
            for block in iter(lambda: src.read(1024 * 1024), b""):
                digest.update(block)
                size += len(block)
                dst.write(block)
        after = source.stat()
        if (before.st_size, before.st_mtime_ns, before.st_ino) != (after.st_size, after.st_mtime_ns, after.st_ino):
            fail(f"Source changed while copying: {source}")
        actual = digest.hexdigest()
        if item["expected_sha256"] and actual != item["expected_sha256"]:
            fail(f"Frozen/source-bound file SHA mismatch: {source}")
        if size != before.st_size:
            fail(f"Source byte count changed while copying: {source}")
        os.chmod(output, stat.S_IMODE(before.st_mode) & 0o777)
        members.append({"path": relative, "bytes": size, "sha256": actual,
                        "source_role": item["source_role"]})
    manifest_name = f"MANIFEST_{plan.kind}.json"
    manifest = {
        "schema": "jcert-plus-package-members-v1",
        "package_kind": plan.kind,
        "created_utc": utc_now(),
        "root_relative_paths": True,
        "payload_member_count": len(members),
        "payload_bytes": sum(item["bytes"] for item in members),
        "manifest_self_exclusion": (
            "This manifest lists every other member. Its own bytes and SHA-256 are "
            "bound by the external PACKAGE_MANIFEST.json, avoiding a circular self-hash."
        ),
        "separate_package_references": cross_references,
        "members": members,
        "notes": plan.notes,
    }
    json_write_new(target / manifest_name, manifest)
    return manifest_name, manifest


def create_zip(staged, archive):
    if archive.exists():
        fail(f"Refusing to overwrite a package: {archive}")
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=6, allowZip64=True) as bundle:
        for source in regular_files(staged):
            relative = safe_relative(source.relative_to(staged).as_posix())
            info = zipfile.ZipInfo(relative, date_time=(2026, 11, 26, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | (stat.S_IMODE(source.stat().st_mode) & 0o777)) << 16
            with source.open("rb") as src, bundle.open(info, "w", force_zip64=True) as dst:
                shutil.copyfileobj(src, dst, length=1024 * 1024)


def verify_archive(archive, kind, destination):
    destination.mkdir(parents=True, exist_ok=False)
    manifest_name = f"MANIFEST_{kind}.json"
    observed = []
    with zipfile.ZipFile(archive) as bundle:
        infos = bundle.infolist()
        names = [info.filename for info in infos]
        if len(names) != len(set(names)):
            fail(f"Duplicate member in {archive}")
        if manifest_name not in names:
            fail(f"Missing internal manifest in {archive}")
        manifest = json.loads(bundle.read(manifest_name))
        expected = {member["path"]: member for member in manifest["members"]}
        if len(expected) != len(manifest["members"]):
            fail(f"Duplicate manifest member in {archive}")
        if set(names) != set(expected) | {manifest_name}:
            fail(f"ZIP member set differs from manifest in {archive}")
        if len(expected) != manifest["payload_member_count"]:
            fail(f"Internal member count mismatch in {archive}")
        if kind == "EVIDENCE" and any(name.lower().endswith(".npz") for name in names):
            fail("Evidence ZIP contains an NPZ")
        bad_crc = bundle.testzip()
        if bad_crc is not None:
            fail(f"CRC failure in {archive}: {bad_crc}")
        for info in infos:
            relative = safe_relative(info.filename)
            if info.is_dir() or stat.S_ISLNK(info.external_attr >> 16):
                fail(f"Unsupported directory/symlink member: {relative}")
            out = destination / relative
            out.parent.mkdir(parents=True, exist_ok=True)
            with bundle.open(info) as src, out.open("xb") as dst:
                shutil.copyfileobj(src, dst, length=1024 * 1024)
            size, digest = out.stat().st_size, sha256(out)
            if size != info.file_size:
                fail(f"ZIP header byte count mismatch: {relative}")
            if relative in expected:
                bound = expected[relative]
                if size != bound["bytes"] or digest != bound["sha256"]:
                    fail(f"Extracted member differs from internal manifest: {relative}")
            observed.append({"path": relative, "bytes": size, "sha256": digest})
    return {
        "archive": archive.name, "bytes": archive.stat().st_size,
        "sha256": sha256(archive), "member_count_including_manifest": len(observed),
        "payload_member_count": manifest["payload_member_count"],
        "payload_bytes": manifest["payload_bytes"],
        "internal_manifest": next(item for item in observed if item["path"] == manifest_name),
        "crc_passed": True, "safe_paths_passed": True,
        "exact_member_set_passed": True, "member_byte_lengths_passed": True,
        "member_sha256_passed": True, "fresh_extraction_passed": True,
        "npz_member_count": sum(item["path"].lower().endswith(".npz") for item in observed),
        "members_including_manifest": observed,
    }


FRESH_IMPORT_PROGRAM = r'''
import ctypes
import importlib
import importlib.metadata
import json
import pathlib
import sys
root = pathlib.Path.cwd()
request = json.loads(sys.stdin.read())
report = {"python": sys.version, "imports": [], "native_loads": [], "dependencies": {}}
for name in request["imports"]:
    module = importlib.import_module(name)
    origin = pathlib.Path(module.__file__).resolve()
    origin.relative_to(root)
    report["imports"].append({"module": name, "source": origin.relative_to(root).as_posix()})
for relative in request["native_libraries"]:
    ctypes.CDLL(str(root / relative))
    report["native_loads"].append(relative)
for name, expected in request["dependencies"].items():
    actual = importlib.metadata.version(name)
    report["dependencies"][name] = {"expected": expected, "actual": actual, "matches": actual == expected}
    if actual != expected:
        raise RuntimeError("Dependency version differs: " + name)
from src.v2_runner import load_freeze
protocol, inputs = load_freeze()
report["frozen_loader"] = {
    "passed": True,
    "fixture_count": len(inputs["fixtures"]),
    "scope": "Source/environment/protocol/roster/seed metadata only; no NPZ load or numerical workload.",
}
print(json.dumps(report, sort_keys=True))
'''


def fresh_code_verification(root, verify_area, source_map, git_info):
    compiled = []
    for source in regular_files(root):
        if source.suffix == ".py":
            # Compilation only, no bytecode file and no module execution.
            compile(source.read_bytes(), str(source), "exec", dont_inherit=True)
            compiled.append(source.relative_to(root).as_posix())
    for relative, expected in source_map.items():
        if sha256(root / relative) != expected:
            fail(f"Fresh code extraction does not match CODE_FREEZE: {relative}")
    requirements_path = root / "requirements-research.txt"
    dependencies = {}
    for line in requirements_path.read_text(encoding="utf-8").splitlines():
        match = re.fullmatch(r"\s*([A-Za-z0-9_.-]+)==([^\s;#]+)\s*(?:#.*)?", line)
        if match:
            dependencies[match.group(1)] = match.group(2)
    if not dependencies:
        fail("Research requirements contain no exact dependency pins")
    imports = list(REQUIRED_IMPORTS)
    for name in imports:
        if not (root / (name.replace(".", "/") + ".py")).is_file():
            fail(f"Required fresh import source absent: {name}")
    native = sorted(relative for relative in source_map if relative.endswith(".so"))
    if len(native) < 2:
        fail("Frozen source map does not contain the expected native libraries")
    environment = os.environ.copy()
    environment.update({
        "PYTHONDONTWRITEBYTECODE": "1", "PYTHONPATH": str(root),
        "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1",
        "VECLIB_MAXIMUM_THREADS": "1", "BLIS_NUM_THREADS": "1",
    })
    request = {"imports": imports, "native_libraries": native, "dependencies": dependencies}
    result = subprocess.run(
        [sys.executable, "-B", "-c", FRESH_IMPORT_PROGRAM], input=json.dumps(request),
        cwd=root, env=environment, text=True, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, timeout=180, check=False,
    )
    if result.returncode:
        fail("Fresh module import/native load failed: " + result.stderr + result.stdout)
    import_report = json.loads(result.stdout)
    import_stderr = result.stderr
    compiler = shutil.which("cc") or shutil.which("gcc")
    if compiler is None:
        fail("No C compiler is available for isolated native source verification")
    compiler_version = run_command([compiler, "--version"])
    native_output = verify_area / "native_rebuild"
    native_output.mkdir(parents=True, exist_ok=False)
    native_builds = []
    for source_name, output_name in (("promotion_screen.c", "screen.so"),
                                     ("promotion_index_profile.c", "index.so")):
        candidates = [relative for relative in source_map if PurePosixPath(relative).name == source_name]
        if len(candidates) != 1:
            fail(f"Expected one frozen C source named {source_name}, found {candidates}")
        source = root / candidates[0]
        output = native_output / output_name
        result = run_command([compiler, "-O3", "-fPIC", "-shared", source, "-o", output], timeout=180)
        result.update({"source_relative": candidates[0], "output_name": output_name,
                       "output_bytes": output.stat().st_size, "output_sha256": sha256(output),
                       "frozen_binary_overwritten": False})
        native_builds.append(result)
    history = verify_area / "history.git"
    clone_report = run_command([
        "git", "clone", "--mirror", "--quiet", root / "reproduction/RESEARCH_HISTORY_V2.bundle", history,
    ], timeout=300)
    commit_checks = {}
    for label, commit in git_info["commits"].items():
        check = run_command(["git", "--git-dir", history, "cat-file", "-t", commit])
        if check["stdout"].strip() != "commit":
            fail(f"Expected commit unavailable in fresh bundle clone: {label}")
        commit_checks[label] = commit
    return {
        "python_compile_passed": True, "compiled_file_count": len(compiled),
        "compiled_python_paths": compiled,
        "frozen_source_sha256_passed": True, "frozen_source_file_count": len(source_map),
        "actual_module_imports_and_native_loads": import_report,
        "fresh_import_stderr": import_stderr,
        "compiler_version": compiler_version, "isolated_native_builds": native_builds,
        "history_bundle_fresh_clone": clone_report, "history_commits_available": commit_checks,
        "numerical_workloads_run": 0, "benchmarks_run": 0, "historical_replays_run": 0,
        "test_suite_run": False,
    }


def cross_package_consistency(reports):
    paths = {}
    shared = []
    for kind, report in reports.items():
        for item in report["members_including_manifest"]:
            previous = paths.get(item["path"])
            signature = (item["bytes"], item["sha256"])
            if previous is None:
                paths[item["path"]] = (kind, signature)
            elif previous[1] != signature:
                fail(f"Packages contain nonidentical files at shared path {item['path']}")
            else:
                shared.append({"path": item["path"], "packages": [previous[0], kind],
                               "bytes": item["bytes"], "sha256": item["sha256"]})
    return {"nonidentical_shared_paths": 0, "identical_shared_files": shared}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--timing-released", action="store_true")
    parser.add_argument("--final-ready", action="store_true")
    parser.add_argument("--mode", choices=("inventory", "build"), default="build")
    parser.add_argument("--workspace", type=Path, default=DEFAULT_WORKSPACE)
    parser.add_argument("--original", type=Path)
    parser.add_argument("--runtime", type=Path)
    parser.add_argument("--delivery", type=Path)
    parser.add_argument("--extra-evidence", action="append", default=[])
    args = parser.parse_args()
    if not args.timing_released:
        parser.error("Root's timing release is required before any inventory or build")
    if args.mode == "build" and not args.final_ready:
        parser.error("Root's final-ready signal is required before the final package snapshot")
    args.workspace = args.workspace.resolve()
    args.original = (args.original or args.workspace / "original" / ARCHIVE_BASENAME).resolve()
    args.runtime = (args.runtime or args.workspace / "runtime").resolve()
    args.delivery = (args.delivery or args.workspace / "delivery").resolve()
    plans, source_map, input_inventory = select_plans(args)
    if args.mode == "inventory":
        print(json.dumps({"plans": {key: plan.description() for key, plan in plans.items()},
                          "input_inventory": input_inventory}, indent=2, sort_keys=True))
        return

    args.delivery.mkdir(parents=True, exist_ok=True)
    external_manifest_path = args.delivery / "PACKAGE_MANIFEST.json"
    targets = [args.delivery / name for name in ZIP_NAMES.values()] + [external_manifest_path]
    if any(target.exists() for target in targets):
        fail("Refusing to overwrite existing package outputs: " + ", ".join(str(p) for p in targets if p.exists()))
    build_root = Path(tempfile.mkdtemp(prefix="_runtime_audit_package_build_", dir=args.delivery))
    generated = build_root / "generated"
    generated.mkdir()
    pending_archives = build_root / "pending_archives"
    pending_archives.mkdir()
    git_info = generate_code_material(args, plans["CODE"], generated, source_map)
    # The builder itself is a reproducibility utility, not a newly frozen runtime.
    cross_refs = {
        "CODE": {"inputs_archive": ZIP_NAMES["INPUTS"], "evidence_archive": ZIP_NAMES["EVIDENCE"],
                 "required_overlay_for_data_and_records": True},
        "EVIDENCE": {"inputs_archive": ZIP_NAMES["INPUTS"], "code_archive": ZIP_NAMES["CODE"],
                     "npz_arrays_deliberately_separate": True},
        "INPUTS": {"code_archive": ZIP_NAMES["CODE"], "evidence_archive": ZIP_NAMES["EVIDENCE"],
                   "bindings": ["protocol/A2_TIE_RETEST_INPUTS.json", "v2/INPUTS.json"]},
    }
    reports = {}
    extraction_roots = {}
    for kind in ("CODE", "EVIDENCE", "INPUTS"):
        staged = build_root / ("staged_" + kind.lower())
        stage_plan(plans[kind], staged, cross_refs[kind])
        archive = pending_archives / ZIP_NAMES[kind]
        create_zip(staged, archive)
        extraction = build_root / ("fresh_" + kind.lower())
        reports[kind] = verify_archive(archive, kind, extraction)
        extraction_roots[kind] = extraction
        print(json.dumps({"verified_archive": archive.name,
                          "bytes": reports[kind]["bytes"],
                          "member_count": reports[kind]["member_count_including_manifest"]}), flush=True)
    consistency = cross_package_consistency(reports)
    fresh_code = fresh_code_verification(extraction_roots["CODE"], build_root, source_map, git_info)
    final = {
        "schema": "jcert-plus-package-set-v1", "created_utc": utc_now(),
        "package_scope": "Code, Evidence, Inputs; paper/PDF/report are delivered separately by root.",
        "source_provenance": git_info,
        "immutable_original_modified": False, "frozen_runtime_modified": False,
        "new_runtime_freeze_created": False,
        "archives": reports,
        "cross_package_consistency": consistency,
        "fresh_code_verification": fresh_code,
        "input_inventory": input_inventory,
        "all_requested_verifications_passed": True,
        "test_scope": {
            "reported_pre_freeze_targeted_passes": 117, "reported_v2_targeted_tests": 9,
            "prior_full_suite_executed": 202, "prior_full_suite_successful": 201,
            "known_legacy_error": "Missing A1_CONFIRMATION_PROTOCOL fixture; not fabricated.",
            "full_suite_passing_claimed": False,
            "package_builder_reran_suite": False,
        },
    }
    # Publish only fully verified archives. Creating a hard link is exclusive;
    # an unexpected pre-existing destination is never replaced.
    for kind in ("CODE", "EVIDENCE", "INPUTS"):
        os.link(pending_archives / ZIP_NAMES[kind], args.delivery / ZIP_NAMES[kind])
    json_write_new(external_manifest_path, final)
    print(json.dumps({"package_manifest": str(external_manifest_path),
                      "all_requested_verifications_passed": True,
                      "verification_work_directory": str(build_root)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
