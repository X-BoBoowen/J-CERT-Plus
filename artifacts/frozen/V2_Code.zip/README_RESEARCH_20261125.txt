J-CERT+ research reproduction guide | 25 November 2026

Final result and stopping decision

Read RESEARCH_DECISION_20261125.txt for the full Chinese research report.
One development selection and one held-out confirmation are complete.
With B=floor(m/8), total Q16 service cost was 174.726642489 seconds versus
179.638383087 for the stronger rebuild baseline, a 2.7342% saving.
All frozen gates passed: worst paired cell ratio 1.07077, worst slow
ratio 0.92973, and zero validation issues across 108 complete workers.
The benefit is modest and concentrated in slow streams; all eight other
graph/family/seed cells are slower than rebuild. This is retained as a
robust engineering mechanism, not a new main theoretical contribution.
The old adaptive controller remains closed. A2 was not triggered, and
there was no second confirmation or further parameter selection.

Start with the work order in protocol/USER_WORK_ORDER.txt and the execution
record in review/PROGRESS.md. The 24 November input ZIP and R15 baseline
are frozen. review/INPUT_ARCHIVE.json records the original ZIP's name,
SHA-256 and extraction location. This research tree began at 11bf5a2 on
research/access-budget-20261125. Commit 55a27c3 contains the stronger
rebuild baseline and diagnostic. The guard's timed source was frozen at
ce5fc86. Each timed fixture manifest records the actual source digests.

Run commands below from the research package root. Keep baseline_r15/,
data/, and src/ together, including the bundled screen.so and index.so
under baseline_r15/experimental_records/evidence_supplement_20261124/
diagnostic/build/. The supplied binaries require a compatible Linux host.
Install the pinned packages in requirements-research.txt in the Python
environment. The small exact-tie tests also use SymPy. The timing workers
need Linux CPU affinity access to CPU 0. The test command below uses CPU 1.
The older src/anchor_service_bench.py and src/anchor_confirmation.py entry
points are historical helpers gated by the earlier source and protocol
hashes. Use the access_* entry points for this round.

Evidence and source map

- Gate A. protocol/ACCESS_DIAGNOSTIC.json, raw/access_diagnostic.json,
  reports/GATE_A.json and reports/GATE_A_RESEARCH_SPACE.txt. The four
  fixed requests use the historical seed 196613. The mechanism figure
  and caption are in analysis/MECHANISM_OLD_EVIDENCE.* and
  reports/MECHANISM_FIGURE.txt.
- Guard. src/coverage_budget.py defines visit reservation and single-use
  plan tickets. src/anchor_session.py implements the source switch.
  src/weighted_adapter.py and src/session.py prepare and share immutable
  weight groups. reports/ACCESS_BUDGET_PROOF.txt gives the coverage and
  work bounds. review/GUARD_IMPLEMENTATION.txt records the implementation
  and focused checks.
- Development. protocol/ACCESS_DEVELOPMENT.json and
  protocol/ACCESS_DEVELOPMENT_INPUTS.json freeze the one seed block, three
  candidate coefficients and matched repeats. raw/access_development/
  holds the schedule and the 60 timed workers. The analyzer selected
  B = floor(m/8), where m is the registered catalog size. Its aggregate
  full-service saving against the stronger rebuild control was 5.73% on
  development. See reports/ACCESS_DEVELOPMENT_RESULTS.json and
  reports/ACCESS_DEVELOPMENT_REPLAY.json for the measured scope.
- Confirmation. protocol/ACCESS_CONFIRMATION.json,
  protocol/ACCESS_CONFIRMATION_ADMISSION.json and
  protocol/ACCESS_CONFIRMATION_INPUTS.json record admission, acceptance
  thresholds and two new seed blocks. raw/access_confirmation/ holds
  the one registered schedule of 108 workers. The same catalog rule and
  coefficient apply to every confirmation stream.
  reports/ACCESS_CONFIRMATION_RESULTS.json and
  reports/ACCESS_CONFIRMATION_REPLAY.json contain the completed gate and
  independent proof of five selected original requests (75 decisions).
  analysis/FINAL_CONFIRMATION_AUDIT.json contains full work, memory,
  response, process-wall and fallback summaries, derived without timing
  by python -m src.access_final_summary.
  analysis/ACCESS_CONFIRMATION_COSTS.* shows all registered prefixes;
  analysis/MECHANISM_GUARD_OVERLAY.* adds observed historical-regression
  switch markers to the diagnostic work curves. These are not a spliced
  timed trajectory. review/FINAL_CONFIRMATION_REVIEW.txt is the final
  independent review.

Focused correctness tests

The following command generated logs/NEW_MECHANISM_TESTS.log with 38 tests.
Use a different log destination when reproducing from the supplied package.

mkdir -p reproduction
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  taskset -c 1 python - <<'PY' > reproduction/NEW_MECHANISM_TESTS.log 2>&1
import sys, unittest
sys.path.insert(0, 'tests')
names = ['test_weight_groups', 'test_weighted_adapter', 'test_anchor_session',
         'test_session', 'test_coverage_budget', 'test_access_bench',
         'test_access_replay']
suite = unittest.defaultTestLoader.loadTestsFromNames(names)
result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
PY

Gate A diagnostic reproduction

The diagnostic reads the original selected JSON files from
../frozen/J_CERT_Plus_VLDB_Research_20261124/raw/a1_confirmation/ relative
to the research root. The delivery ZIP includes the eight required old
trace/control files at that sibling path. If using the research tree
alone, extract them from the original 24 November ZIP into ../frozen/.
The diagnostic CLI takes
--repeats and uses the fixed frozen path. It reads the historical opinion
fixtures from data/confirmation_196613/ in the research tree. In a separate
copy, use the 55a27c3 diagnostic and runtime sources with the supplied
data and baseline dependencies. The recorded component source hashes are
in raw/access_diagnostic.json. The diagnostic writes that same path, so
use the separate copy to preserve the archived JSON. Run serially with
CPU 0 available.

    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
      python -m src.access_diagnostic --repeats 3

The diagnostic binds each restored state to its historical trace before
comparing old and fresh work at the same epoch, target and exclusions.
Restoration and validation are outside the timed diagnostic subtotal.
The later guard instrumented the request path, so use the pre-guard
snapshot to reproduce its timing setup. Exact component snapshots are
also included under review/gate_a_source/src/, with their digests in
review/GATE_A_SOURCE_SNAPSHOT.json. Restore those four files into the
separate diagnostic copy; leave all other dependencies in place.
For the figure alone, use the
supplied raw JSON and run python -m src.plot_access_mechanism with
--output-stem reproduction/MECHANISM_OLD_EVIDENCE if Matplotlib is installed.

Read, analyze, and check the registered batches

The supplied manifests already point to the frozen NPZs under data/access/.
Reuse the protocol/manifest pair for the corresponding timed directory.
This example reanalyzes development and independently replays the selected
timed results into new output files.

    mkdir -p reproduction
    python -m src.access_analyze \
      --protocol protocol/ACCESS_DEVELOPMENT.json \
      --manifest protocol/ACCESS_DEVELOPMENT_INPUTS.json \
      --directory raw/access_development \
      --output reproduction/ACCESS_DEVELOPMENT_RESULTS.json

    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
      python -m src.access_replay \
      --protocol protocol/ACCESS_DEVELOPMENT.json \
      --manifest protocol/ACCESS_DEVELOPMENT_INPUTS.json \
      --timed-dir raw/access_development --coefficient 1/8 \
      --output reproduction/ACCESS_DEVELOPMENT_REPLAY.json

The corresponding confirmation commands use ACCESS_CONFIRMATION.json,
ACCESS_CONFIRMATION_INPUTS.json, raw/access_confirmation, and new output
names. Keep --coefficient 1/8 for its replay. Analysis validates the
registered denominator, worker/source/input identities, cost and budget
accounting, and cross-arm output agreement across the batch. Replay
independently verifies selected actual timed decisions. It also compares
the recorded per-epoch access fields with an untimed reproduction and
audits that reproduction's state and emitted IDs. Full arrays and ID
digests are audit-only. The replay JSON records selected or missing
behaviors and independent verification time.

Final descriptive summaries and figures (no new performance run):

    python -m src.access_final_summary
    python -m src.plot_access_mechanism \
      --guard-regression raw/KNOWN_FAILURE_GUARD_REGRESSION.json
    python -m src.plot_access_costs

These write the already supplied analysis files. Use a separate copy if
you want to preserve their original bytes. PNGs are for inspection and
SVGs are included for publication layout. Plot bands are observed ranges,
not confidence intervals. RSS and response summaries are machine-readable
in analysis/ACCESS_CONFIRMATION_MEMORY_RHS.json.

Archive integrity and source history

review/FROZEN_INPUT_INTEGRITY.json records the final archive, extracted
original and baseline dependency checks. review/ARTIFACT_SHA256.json is
the per-file delivery manifest; it excludes itself to avoid a recursive
digest. review/RESEARCH_HISTORY.bundle preserves the local source commits
without shipping a live .git directory. To inspect that history separately:

    git clone review/RESEARCH_HISTORY.bundle reproduction/source-history

The bundle tracks code/protocol/review history; raw results, figures,
fixtures and baseline dependencies are in the delivery ZIP rather than
Git. Keep the original input archive as the authoritative full prior-round
record. Only the eight explicitly needed original trace/control files are
duplicated here; the input archive itself was not overwritten.

Rebuild a fixture freeze or repeat measurements separately

The original files suffice for analysis and replay. To reproduce the
fixture-generation procedure under the packaged source, use new paths.
prepare independently regenerates each opinion block, checks the projected
graph, and binds the protocol, exact sources and native libraries, NPZ
files, matrices and individual rows by digest. It refuses to replace an
existing manifest or fixture directory.

    python -m src.access_bench prepare \
      --protocol protocol/ACCESS_DEVELOPMENT.json \
      --manifest reproduction/DEVELOPMENT_INPUTS.json \
      --fixture-dir reproduction/development-fixtures

The following example uses the original freeze with a new output directory.
A freshly prepared freeze can also be supplied by its own manifest path.
Keep the protocol and freeze together throughout measurement and analysis.

    python -m src.access_bench batch \
      --protocol protocol/ACCESS_DEVELOPMENT.json \
      --manifest protocol/ACCESS_DEVELOPMENT_INPUTS.json \
      --output reproduction/access_development

batch requires an empty output directory, serializes timed workers, pins
them to CPU 0 and sets numerical thread pools to one. Its worker validates
the current source and the exact registered inputs against the freeze.
It preserves FROZEN_JOBS.json, SCHEDULE_RESULTS.json, request prefixes,
and failed or unfinished worker records. The protocols cap each worker at
90 seconds and 2 GiB RSS, and the serial batch at 1,800 seconds. Repeating
the same registered fixtures is a reproduction of the same seed blocks.
Keep any reproduction separate from the registered results and retain all
original workers, including failures. The original confirmation is the
one registered held-out batch.

Read the time, work, and memory fields together

- Service cost is structural_seconds plus the complete request_seconds
  through each registered prefix. Full process wall also includes startup,
  fixture validation, checkpoint writes and shutdown. Independent replay
  reports its own checker time. Prefixes on one stream overlap and repeated
  workers measure timing variation on the same input block.
- index_build_phases.{key_gather,stable_sort} are nested measurements
  within posting/index_build. discovery.access_phases breaks out plan,
  posting gather, tail-view creation, concatenate/deduplicate/exclude,
  hot and cold strict endpoint screening and the remaining query
  management. Use them to explain the full-request time, without adding
  them again to it.
- pre_dedup_visits is the posting-degree sum plus the selected group-tail
  lengths before either unique operation. returned_ids counts emitted IDs
  after exclusion. Budget consumption charges only admitted old-source
  raw visits. The denied plan is logged separately from the fresh plan
  that actually gathers. Time, response solves and unique IDs are separate
  measurements.
- structural_weight_grouping is the 4m-byte canonical member-ID payload.
  effective_weights is the 8m-byte scaled-weight vector.
  root_caps_retention_peak_bytes describes the saved 8m-byte rank vector
  for requests that start on an older source. The guard-specific
  incremental_root_caps_bytes records this retention. The end snapshot
  before request cleanup is root_caps_retained_at_end_bytes.
- retained_key_coordinate_bytes includes one anchor's sorted keys, IDs
  and coordinates. sorted_index_overlap_bytes logs simultaneous old and
  new key/ID payload at a fallback. Eager rebuild also overlaps two
  sorted payloads after the first request, 24m bytes from their dtypes.
  These payload fields exclude workspace and object overhead. Use process
  peak RSS and the scheduler's sampled peak RSS for whole-worker memory.
