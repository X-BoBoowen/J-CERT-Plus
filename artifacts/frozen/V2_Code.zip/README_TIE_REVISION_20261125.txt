J-CERT+ A2 精确平局修订：交付入口
2026-11-25

结论
A2 应纳入有明确适用域的核心系统叙事。共同比较器的精确单节点交换证书补齐了已定位的平局分支；在原十二单元的一次修订复测中，D/S/H 共108个 worker 全部完成 Q4/b15。H 相对强 D 的单元配对时间和加速为2.66–4.24倍，相对分块 S 为10.32–17.19倍。
原冻结确认仍为 failed；这次是已诊断固定输入上的修订复测，不是未见输入确认。A1关闭、R15保留。本轮不追加算法、调参、种子或性能批次。

建议阅读顺序
1. reports/A2_TIE_REVISION_REPORT_ZH.txt：完整研究判断、十二单元结果、成本来源、验证范围与论文定位。
2. reports/A2_PAPER_CLAIMS_ONE_PAGE_ZH.txt：主张—证据—章节目标。
3. figures/tie_revision/：联合覆盖、完整成本、成本与空间三张图，均含PNG/SVG；a2_tie_plot_data.json保留绘图数据与口径。
4. reports/TIE_EQUALITY_PROOF.txt 与 docs/TIE_CERTIFICATE_INTERFACE.txt：平局证明、证书字段、合法界传递和费用边界。
5. reports/A2_TIE_RETEST_SUMMARY.json、A2_TIE_RETEST_RESULTS.txt、TIE_RETEST_ANALYSIS.json：可复算汇总及全量逐重复结果。

实现与版本
独立分支：research/a2-exact-ties-20261125。
原 A2 完成版本：365bc8e5595203319fa121067e66aba64cd2beb9，原失败判定保留。
共同平局实现冻结：531522d。
原固定输入复测绑定冻结：9de16a7。
最终交付提交和逐文件SHA256见 review/ARTIFACT_SHA256.json；完整提交祖先见 review/RESEARCH_HISTORY.bundle。

新增 src/exact_ties.py；原计时运行时集合仅改 src/weighted_adapter.py 和 src/a2_session.py。H前沿、D索引、S扫描、意见、包络、精度和容差均不改。独立 checker、限定重放、复测编排与事后分析另列为工具。
旧 README、研究判断和原确认文件保持历史内容，请以本入口和新报告识别修订结果。压缩包不含工作树的 .git 指针；可用下列命令在新位置恢复源码历史：
  git clone review/RESEARCH_HISTORY.bundle recovered-source --branch research/a2-exact-ties-20261125
数据、原始轨迹与基线材料仍由本包 data/、raw/、baseline_r15/ 提供；这些大文件原来不受git跟踪，恢复源码时也应保留本包副本。

证据位置
protocol/A2_TIE_RETEST.json：修订复测规则及原失败文件的固定摘要。
protocol/A2_TIE_RETEST_ADMISSION.json：进入唯一复测前的条件与决定。
protocol/A2_TIE_RETEST_INPUTS.json：原十二份NPZ逐字节复用及修订源码绑定。
raw/a2_tie_retest/：108个正式worker、原顺序、全Q4及资源记录。
raw/a2_tie_fixed_replay/：7个原确认失败状态与3个开发失败状态的限定重放。
raw/a2_confirmation/、raw/a2_development/：原始不利结果及成功结果，均保留。
reports/A2_CONFIRMATION_JUDGMENT.json：原冻结 failed，不追溯改判。
reports/TIE_FIXED_STATE_INVENTORY.json、TIE_FIXED_STATE_REPLAY.json：固定状态与重放结果。
reports/TIE_FIXED_INDEPENDENT_VERIFICATION.json：10个固定请求的150步全目录独立验证。
reports/TIE_TIMED_WITNESS_VERIFICATION.json：432条实际计时请求链和90份见证观察的独立结构验证。
reports/TIE_TIMED_OTC_FULL_REPLAY.json：预选实际计时OTC请求的15步全目录独立验证。
review/TIE_FINAL_ACCOUNTING_AUDIT.json：从原始记录复算成本、输入/源码绑定和5769个原成功决定的一致性。
review/TIE_TARGETED_TESTS.txt、TIE_REVISION_CODE_REVIEW.txt、TIE_FINAL_REPORT_REVIEW.txt：针对性测试与独立审阅。
handoff/：用户提供的限定诊断和任务，原样保留。

已完成的验证与口径
108项针对性测试通过；全部108个正式worker完成、432次执行请求各15次提交，共6480次提交。这仅对应48条不同意见，不能将方法与重复当作独立输入。
完整全目录独立证明覆盖10个固定请求加1个实际计时请求；全部432请求的另一项检查是版本链与结构见证检查，范围不同。独立checker成本另报，不纳入算法主时间。
每单元时间为3次重复中位数；加速列为3次完整配对块之和的比；图中范围为最小—最大，不是置信区间。RSS是各worker进程高水位，不求和。全部版本重建、warm处理、在线平局工作均在主计时内。

复现入口（本轮已执行完毕；以下供之后在隔离副本中复算）
从包根目录运行。Python依赖见 requirements-research.txt；CPU亲和性与原环境见冻结协议。若机器没有相同CPU编号，必须记录环境差异，不将新机器时间冒充归档时间。
所有数值运行使用单线程环境：
  export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1

针对性测试：
  python -m unittest tests.test_exact_ties tests.test_a2_tie_integration tests.test_a2_session tests.test_a2_numeric tests.test_weighted_adapter tests.test_a2_checker tests.test_a2_tie_checker tests.test_a2_tie_retest tests.test_a2_bench -q

只重算统计，不执行服务：
  python -m src.a2_tie_retest analyze --protocol protocol/A2_TIE_RETEST.json --manifest protocol/A2_TIE_RETEST_INPUTS.json --directory raw/a2_tie_retest --output reports/LOCAL_RECOMPUTED_ANALYSIS.json
  python -m src.a2_tie_summarize --analysis reports/LOCAL_RECOMPUTED_ANALYSIS.json --summary reports/LOCAL_RECOMPUTED_SUMMARY.json --text reports/LOCAL_RECOMPUTED_RESULTS.txt
  python -m src.a2_tie_figures --analysis reports/LOCAL_RECOMPUTED_ANALYSIS.json --summary reports/LOCAL_RECOMPUTED_SUMMARY.json --output-dir figures/local_recomputed

独立验证（会做实际全目录数值计算）：
  python -m src.a2_tie_verify_fixed --output reports/LOCAL_FIXED_CHECK.json
  python -m src.a2_tie_verify_retest --witness-output reports/LOCAL_TIMED_WITNESSES.json --full-output reports/LOCAL_TIMED_FULL_CHECK.json

一次修订计时的原入口为 src.a2_tie_retest batch，使用上述冻结protocol/manifest和 --output 指向一个全新目录。已归档正式结果不可覆盖或补跑；新的复现结果应另命名，并声明它们是之后的复现。prepare仅用于新建修订输入绑定，本包已经包含冻结manifest，不需再调用。

范围
固定根、统一1/16非边插入、显式稀疏自然权重负边翻转；两张自然权重图的生成意见，Q4、最多15次连续提交。单节点交换证书不覆盖一般同构或全部平局。K最坏仍可达到M，前沿空间不等于整个引擎空间，不声称普遍次线性、实例最优或新的排序/阈值算法。后续进入论文整合。
