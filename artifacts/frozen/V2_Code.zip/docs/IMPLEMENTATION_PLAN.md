# Coverage access budget research implementation plan

**Goal:** Execute the user-authorized Task A–F gates and deliver code, measurements, proofs, and a stopping decision.
**Architecture:** Share immutable weighted catalog groups; preserve the certified numerical kernel. Diagnose necessary rebuild costs first. Conditional A1 uses exact pre-gather cumulative visits and at most one request-root fallback. Conditional A2 uses nonmaterialized all-nonedges on a common domain.
**Tech stack:** Existing Python/NumPy/SciPy and independent integer/interval checker.
**Spec:** ../protocol/USER_WORK_ORDER.txt, controlling authority; no further design approval required by the user's explicit autonomous execution instruction.

## Constraints
- Frozen input archive, R15 and 20261124 confirmations are not modified.
- Fixed root, fixed two-hop catalog plus negative flips, empty per-request numerical cache, no answer cache.
- Preserve numerical acceptance, ties, stop and unresolved semantics. No Route B.
- Performance processes run serially at fixed CPU and one thread; failures remain in denominators.
- At most one development batch (two graphs, three streams, one new seed, Q16, <=3 global coefficients), one selection and one new confirmation.
- Gate A may skip fallback implementation. Failure of A1 triggers one bounded A2 experiment, then conclusion.

## Review focus
- Shared grouping arrays and canonical tie order cannot be modified by per-request sorting.
- Root caps and certified coordinates must survive until fallback; current child and numerical views must survive a source switch.
- Preview must precede old gather; equality is admitted; no-query/zero budget/empty catalog are legal.
- Binding changes, exclusions and winner semantics cannot silently omit candidates.
- Raw visits, all request costs, retained memory and same-context counterfactuals are separate measures.

## Tasks
- [ ] A1: Implement immutable groups and stage accounting; focused lifecycle tests.
- [ ] A2: Recover four preregistered diagnostic requests, measure structural grouping/key/sort/plan/gather/dedup/strict, record Gate A.
- [ ] B/C (conditional): Implement visit guard, root fallback, meaningful safety tests, independent proof and review.
- [ ] D/E (conditional): Freeze one development batch, select once, register acceptance before any new confirmation, audit selected actual outputs.
- [ ] F (conditional): One common-domain A2 real-subgraph feasibility experiment with nonmaterialized implicit path and b=15 trajectory.
- [ ] Delivery: Verify preservation, package source/raw/protocol/results/claims and explanatory figure; persist complete deliverables.
