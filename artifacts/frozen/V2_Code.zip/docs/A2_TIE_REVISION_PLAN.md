# A2 Exact Tie Completion Implementation Plan

> **For agentic workers:** Use focused subagent work and root integration. User has explicitly authorized implementation, bounded regression and one fixed-input retest; no further design approval is needed.

**Goal:** Complete the shared weighted resolver with exact current-version node-transposition gain certificates, then evaluate the unchanged A2 access strategies on the original fixed inputs once.

**Architecture:** A small exact certificate module is called only by the common resolver on positive unresolved overlaps. A2Session supplies current integer opinion/version/legality context and records comparison evidence. The independent checker reconstructs the relation separately while keeping full-domain enumeration.

**Tech Stack:** Existing Python, NumPy, SciPy, integer/fraction certification; no dependency or precision changes.

**Spec:** handoff/NEXT_ACTIONS.txt and the user message; handoff/OTC_C1_Q4_overlap_diagnostic.json is evidence to verify, not a hardcoded decision input.

## Global Constraints

Original A1/R15 and A2 failed confirmation remain immutable. New branch is research/a2-exact-ties-20261125, based on365bc8e. No H/D/S access or seed/index/screen/opinion changes; delta=0, weight1/16 insertions, natural flips, Q4, budget15, all12 original cells, three repeats, serial CPU0/thread1, worker180s/RSS2048MiB/batch3600s. Original input matrices are reused byte for byte. A retest is not unseen confirmation. One functional regression of each of seven confirmation and three development failure states; do not repeat performance warmups. Root owns actual large-graph runs and final timing, with agents forbidden from launching performance.

## Review Focus

- A certificate handles only its own pair; an unproved third overlapping rival remains unresolved.
- Integer opinion, current parent operator, current legality, operation kind and coefficient all bind the witness.
- True equality transfers valid bounds by intersection, never lower-as-upper or fabricated point scores.
- Canonical winner switching must acquire the chosen winner response/pivot, not retain the old winner response.
- Checker validates exact relations independently and still covers every legal rival, including equal ones.

## Task 1: Verify diagnosis and implement common resolver

Owner root. Files create src/exact_ties.py, tests/test_exact_ties.py; modify src/weighted_adapter.py and only necessary A2Session context/certificate/counter recording in src/a2_session.py. No numerical score, precision, endpoint screen, access or opinion changes.

Interface: frozen dataclass TieContext(A, opinion, parent_version_id, chosen), where opinion is exact integer numerators with denominatorDEN and chosen is a frozen candidate-ID set. Kernel.resolve retains its five positional arguments and adds optional keyword-only tie_context=None, evidence=None. Existing callers without context retain their current behavior. A2 passes the current context. Evidence is a JSON-compatible output dictionary, copied to decision comparison_resolution when nonempty, including failure decisions.

Certificate witness schema: kind=weighted_node_transposition_v1, parent_version_id, operator_sha256, opinion_sha256, opinion_denominator=65536, operator_scale=16, score_unit=2**48, source_candidate_id, target_candidate_id, swap=[u,v], source_edit and target_edit with i,j,flip,d. It proves current legal actions, P A P^T=A, P s=s, and P Delta_source P^T=Delta_target. Exact sparse integer row checks (plus symmetry verification where needed) suffice; no full graph isomorphism search.

Resolution evidence: method=structural_node_transposition, provisional_winner_id, overlap_ids, witnesses, unresolved_ids, canonical_winner_id on success, source_lower/source_upper and shared_lower/shared_upper. Original best>0 is required. Shared upper is min(valid equal-candidate uppers), shared lower is the existing valid positive incumbent lower. All overlapping candidates must be certified before accepting via this route. Unsupported overlap retains the original small-rational fallback or large unresolved.

- [ ] Reproduce the supplied original OTC failure without accepting a new winner; verify current A/opinion/child permutation and six-step prefix.
- [ ] Write failing >16-node and exact-small behavior tests; changed opinion/weight/type/parent, stale witness, unproved third rival, positive/zero/negative and canonical winner switch must be covered.
- [ ] Implement the bounded certificate and resolve integration; preserve response binding and outward intervals.
- [ ] Run affected A2/weighted targeted tests only; record the newly changed contract clearly.

## Task 2: Independent checker and proof

Owner checker agent. Files src/a2_checker.py, tests/test_a2_tie_checker.py, reports/TIE_EQUALITY_PROOF.txt. May read Task1 files but do not import the execution tie module in the checker. Only write these files.

Consumes the witness/decision schema above. The checker independently decodes candidate IDs, reconstructs current A and exact s, verifies current legality, declared units/kind/weight/version/hash, and checks full sparse parent and child conjugacy for the given transposition. Every declared witness must be validated; a boolean is insufficient. It may discover the same single-swap relation for another independently encountered rival, and records such proof work. Exact equality plus canonical ordering can discharge equality comparisons; no demand for strict interval separation between proven equal gains. Positive acceptance still requires a strictly positive independent winner lower bound.

- [ ] Add tests that fail on a legal >16-node tie trace and reject tampered opinion/version/weight/swap and noncanonical winners, using independent rational small-graph references where useful.
- [ ] Implement verifier extension while preserving full legal enumeration and interval-intersection consistency scope.
- [ ] Prove equality, bound transfer, complete rivalry and next-winner response obligations; explicitly charge Session hot|chosen construction, warm sorting/screening in addition to the frontier bound.
- [ ] Run only targeted checker tests and report exact commands/results; do not run real performance or duplicate large replays.

## Task 3: Fixed-state diagnostics and one retest

Root owns execution; a diagnostics agent may prepare read-only inventory and harness in disjoint files after interface agreement. Files create src/a2_tie_diagnostics.py, src/a2_tie_retest.py, protocol/A2_TIE_RETEST.json, reports/TIE_FIXED_STATES.json; original protocols/results never edited.

- [ ] Derive exactly seven confirmation and three development failed states from existing H/repeat0 raw, capture actual contenders on original implementation and independently check candidate pair relations before claiming common cause.
- [ ] On unchanged opinions replay the revision, match the original accepted prefix exactly through its old failure point, then continue under the new common certificate contract. Preserve any new unsupported state without repeated precision experiments.
- [ ] After tests/fixed-state viability, freeze revision source/inputs/protocol and run exactly108 paired workers from the old confirmation roster, same rotated order/resources. No new seeds or new matrices and no duplicate timing trial.
- [ ] Independently verify full real requests exercising the new tie path, at least the originally failing OTC C1 q4; use declared bounded checker resources. Preserve remaining gaps.

## Task 4: Judgment, paper integration and delivery

- [ ] Independent bounded whole-change review of resolver, checker, freeze and actual evidence; no redundant old A1 audit.
- [ ] Report original failed confirmation separately from this diagnosed fixed-input retest; complete-cost denominators include every original cell and any new unresolved.
- [ ] Deliver code, proof, targeted tests, ten-state table, raw retest, independent checks, three focused figures and a one-page claim/evidence/section-goals note. Evaluate A2 as a scoped systems result, not from the failed label or absence of an optimality theorem alone.
- [ ] Preserve old bytes; package and save all final artifacts. No A3, graph-isomorphism generalization, heap/index optimization, anchor work or precision scheduling.
