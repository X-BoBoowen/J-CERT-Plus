# J-CERT+ V2 bounded execution plan

The user's complete V2 work order supplied in this conversation is the authority. It explicitly authorizes execution, two finite experiment batches, and a continuous paper; no additional design approval is required.

## Frozen scope

- Preserve the supplied archive, R15 and all historical records. Original confirmation remains failed; diagnosed twelve-cell revision retest remains a revision retest.
- Restore full Git history and separate runtime and manuscript work. Only root starts performance workers.
- No algorithm, precision, backend, preconditioner, weight, or access-policy optimization. A2 uses its existing SuperLU direct factor at every admitted graph size.
- Compatibility change: widen A2Session's input admission from 10,000 to 82,140 vertices. Preserve D's M<2^31 guard; its mandatory explicit pool alone exceeds the chosen resource ceiling, so it never starts on Slashdot.
- Run one six-cell unseen Q4 batch, D/S/H three repeats (54 workers), with 180 seconds and a hard 2 GiB virtual-address limit per worker. Every outcome retained.
- Slashdot: 4 GiB hard virtual-address limit (less than half of currently available host RAM); root profile 600 s, Q1 600 s/path, Q4 1800 s/path/repeat, at most three repeats, 6 h branch ceiling. Fixed existing direct solver. Gate failures terminate affected paths.
- Single numerical thread, worker CPU0, supervisor CPU8. All performance workers serial; no PDF rendering or large archive verification while running.
- Freeze actual code/native dependencies before drawing a single new 256-bit master seed. Derive six cells and one Slashdot stream by SHA256, reject previously registered seed collisions by deterministic counter, never inspect outcomes before choosing inputs.
- Independent checks: Alpha and OTC H/repeat0/independent/q1 selected before timing, plus every actual equality witness and version chain. Existing checker reused; checker cost separate.

## Tasks and deliverables

- [x] CRC-verify all 2,403 archive members and recover full Git history.
- [ ] Read-only old-record accounting audit; independently recompute relevant totals and preserve verification scope.
- [ ] Static 64-bit/allocation/backend audit and small regression for input admission, high endpoint identities, D preflight, and frozen batch scheduler.
- [ ] Commit compatible runtime and metering/orchestration; hash actual native artifacts; generate inputs and publish immutable protocol/manifest.
- [ ] Execute the single unseen batch and staged Slashdot branch. Resource/unresolved/error outcomes remain results; never retry a worker or change bounds after outcomes.
- [ ] Reconcile all outputs, perform prespecified independent checks and state precise coverage.
- [ ] Write and render continuous PVLDB English paper, Chinese paragraph goals, contribution mapping and R15 edit log.
- [ ] Package independent minimal source and raw-evidence ZIPs, separate input archive, verify actual archives after extraction and publish.

## Review focus

1. Candidate identity must survive >2^32 and M>2^31 without allocating M entries.
2. Hard resource limits precede numerical imports; RSS sampling is measurement only.
3. Timeout, memory failure, unresolved and legal stop cannot collapse to success.
4. No input/version replacement or outcome-driven seed redraw; no old performance rerun.
5. Paper distinguishes mathematical coverage from limited independent experimental replay.

## Decisions

2026-11-26: Supplied ZIP is intact; prior truncation applies to an earlier review copy, not this attachment.
2026-11-26: Existing D's int32 ordinal limitation remains explicit; do not widen an inadmissible 53.404 GiB mandatory payload merely to launch an allocation failure.
2026-11-26: Use hard RLIMIT_AS rather than an unenforceable RSS-only limit. It limits virtual address space, so label this policy accurately and report RSS separately.
