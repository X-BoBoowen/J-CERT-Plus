# A2 Candidate-Lazy Full-Catalog Research Implementation Plan

> **For agentic workers:** Use superpowers:executing-plans for root integration;
> independent implementation, proof and checker tasks run in parallel.

**Goal:** Remove complete catalog preprocessing from H and S while comparing all
three methods under the same certified continuous-edit service.

**Architecture:** One endpoint-based numerical kernel and decision loop. Access
strategies supply batches from an explicit root index, bounded scan, or a joint
insertion/flip frontier. Retain the original weighted response/transport core.

**Tech Stack:** Python3.12, NumPy2.3.5, SciPy1.17, existing native/verified kernels.

**Spec:** docs/A2_SPEC_20261125.txt (user already authorized execution and autonomy).

## Global Constraints

Fixed all-nonedges weight1/16 + original weighted negative flips; delta0; b15;
Q4; no cross-opinion numerical reuse; no M-sized H/S objects; CPU0/thread1 serial
timing; one development and at most one confirmation; preserve all failures.

## Review Focus

- Positive equal gains with different seed/heap orders must choose canonical ID.
- A negative root edge is a flip only; insertions cannot revisit committed pairs.
- Current-state caps/frontiers cannot survive a graph commit without rebuilding.
- Hidden max/weight scans cannot make virtual singleton screening O(nK) or O(MK).
- A resource-limited D worker must remain in results without an infinite speedup.

## Task 1: Sparse identity, batches and joint frontier

Files src/a2_catalog.py, tests/test_a2_catalog.py. Interfaces:
`CandidateBatch(ids,i,j,flip,weights)` arrays with int64 canonical ids;
`AllCatalog(W)` with n,m,insertions,flip_ids,flip_weights, graph sparse bindings;
`batch(ids)`, `iter_blocks(block_size=65536,excluded=())`, `materialize()`;
`scalar(e)->(i,j,flip,d)`, `dense_positions(ids)`, `memory()`;
`MixedFrontier(catalog,xc,rc,chosen=())` with `upper`,
`pop_batch(limit,threshold=None,excluded=())`, counters and memory().
Use exact coarse integer caps, positive equality retained. No emitted history.

- [x] Test canonical enumeration vs independent combinations, mixed signs,
  bounded blocks, nonnegative integer caps, blocked/current exclusions, tied
  centers, full frontier ordering and complete upper coverage after each pop.
- [x] Run failing new tests before implementation; implement sparse structures
  and heap; run targeted tests and record architecture/space assumptions.

## Task 2: Shared virtual numerical kernel and certified service

Files src/a2_numeric.py, src/a2_access.py, src/a2_session.py,
tests/test_a2_numeric.py, tests/test_a2_session.py.
`A2Session(W,method,hot_size=64,timers=True,graph_hash=None)` methods D/S/H;
`request(s,budget=15,delta=0,audit=False)` returns existing decision/status/gain
schema with canonical IDs, counts, memory, phases and access per-version records.
Expose setup_seconds/setup_phases/n/m/root_id/operator_hash/catalog_hash.
`EndpointKernel` reuses weighted Kernel child/resolve and WeightedViews with
virtual columns. `CachedStrict.screen(CandidateBatch|ids,best)` shares endpoint
formulas and caches version-wide validation. Access D retains root Index/groups.

- [x] Independent small-graph gains/ties, no-positive stop, unresolved, mixed
  continuous commits, identical winners, Gram transport preserved, forbidden
  global-array constructors on H/S paths, singleton screen without global scans.
- [x] Implement and exercise those tests, including root!=child for later steps.
- [x] Record necessary field/representation differences; no numerical precision
  adjustment or response simplification in any arm.

## Task 3: Independent proof and replay

Files src/a2_checker.py, tests/test_a2_checker.py,
reports/A2_APPLICABILITY_AND_PRIOR_ART.txt, reports/A2_COVERAGE_PROOF.txt.
Independent sparse/double-loop blocks and exact small-graph check; reuse existing
checker operator/dyadic/response primitives but import no execution catalog or
frontier. `A2CatalogReplay(W).verify(s,decisions,budget,...)` accepts canonical
IDs and validates all legal rivals. Rejected/tampered winners must fail.

- [x] Prior-art note before large implementation, primary sources only.
- [x] Test exhaustiveness, tie, flip identity, current legality and bad outputs;
  build checker and review current-version coverage and true complexity.

## Task 4: Frozen harness and bounded research

Files src/a2_bench.py, src/a2_analyze.py, tests/test_a2_bench.py;
protocol/A2_DEVELOPMENT.json and exact input manifest, raw/a2_development/.
Prepare deterministically from specified labels; validate all hashes, source and
directory semantics before each worker. Adapt existing serial supervisor rather
than a new benchmarking stack. Include all scheduled/error/partial outcomes.

- [x] Test label seed derivation, fixture protection, rotated 54-job schedule,
  Q4 accounting and failure retention on deterministic synthetic records.
- [x] Run small resource preflight, freeze protocol/runtime, execute development
  serially. Independently replay the preselected complete requests.
- [x] Gate on real structural/correctness/value evidence. If admitted, freeze
  exact claim/acceptance then run one full 108-worker confirmation and its
  preselected replay; otherwise close A2 at development.

## Task 5: Whole review, reporting and delivery

- [x] Independent review of numerical contract, no hidden M structures, strong
  D/S controls, complete denominator, source freeze, proof and memory scope.
- [x] Produce <=3 focused visuals plus complete cost/work/memory tables, one
  research decision and reproduction commands. Include every negative outcome.
- [x] Verify A1/source provenance unchanged; package code/data/raw/reviews and
  save actual deliverables. No automatic next research route.

Execution choice: root owns integration and serial performance; catalog, checker/
proof and harness tasks have disjoint files. No agent runs real timed experiments.

Pre-freeze integration record: fixed synthetic128 preflight completed, same15 edits in all arms and independent full-catalog replay. Independent review found only bounded failure-path/counter defects; those are being closed before the single real development freeze. Full peak RSS, boundary response payload and actual cache payload are separately named.

Development completed: all54 workers retained;45 complete Q4 workers,9 common Alpha signed-neighbor unresolved workers, no resource failures. Strict analyzer and independent stdlib raw recomputation agree. Two preregistered independent full real-graph replays certified30 decisions and366190935 legal candidate-decision rows. Four preregistered root/last same-context diagnostics completed without new response RHS. One confirmation is admitted under protocol/A2_CONFIRMATION.json; its40% named-scenario time claim is separate from novelty.

Final confirmation completed: all108 workers retained;81 complete Q4 workers,
27 common unresolved workers, no resource failures. Official analysis and the
independent portable recomputation agree. Both selected full-catalog replays
passed. Frozen judgment FAILED because OTC/signed-neighbor/confirmation-1 is a
primary cell with q4 unresolved after6 accepted edits in all arms/repeats.
The other9 primary cells have favorable observed cost ratios, but no substitute
aggregate or complete-primary result is formed. H/S structural removal stands;
this bounded A2 round is closed as a scoped engineering extension. The full
archive carries code/data/raw/reviews, final reports, three figures, a file-hash
manifest and the self-contained branch history; no additional experiment or
research gate is deferred to a later round.
