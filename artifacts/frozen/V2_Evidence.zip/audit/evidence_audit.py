#!/usr/bin/env python3
"""Read-only bookkeeping audit of archived A2 and directional evidence.

Standard library only. No archived runtime/checker imports, no numerical replay,
no solves, and no performance measurement. All outputs stay beside this script.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import statistics
from collections import Counter, defaultdict
from datetime import datetime, timezone
from decimal import Decimal, getcontext
from itertools import product
from pathlib import Path

getcontext().prec = 60
OUT = Path(__file__).resolve().parent
ROOT = OUT.parent / 'original/J_CERT_Plus_A2_Exact_Tie_Revision_20261125'
SUPPLEMENT = ROOT / 'baseline_r15/experimental_records/evidence_supplement_20261124'
METHODS = ('D', 'S', 'H')
LABELS = {'D': 'D-all', 'S': 'Stream-all', 'H': 'Implicit-all'}
COUNTERS = ('endpoint_checked', 'endpoint_excluded', 'gram_materializations',
            'gram_first', 'gram_rematerializations', 'gram_hits', 'response_blocks',
            'response_residual_matvec_columns', 'state_rhs', 'candidate_rhs',
            'winner_rhs', 'policy_refresh_rhs', 'numerical_reanchor_rhs',
            'score_calls', 'comparison_calls', 'overlap_comparisons')
ACCESS = ('insertion_emissions', 'flips_emitted', 'raw_heap_pops', 'legal_insertion_pops',
          'flip_cursor_pops', 'total_source_pops', 'frontier_rebuilds', 'frontier_resets',
          'emitted_for_screen', 'cold_emitted_for_screen', 'warm_screen_rows',
          'seed_candidates', 'seed_screen_rows', 'seed_insertions', 'seed_flips',
          'stream_pairs_examined', 'stream_insertions_emitted', 'stream_flips_emitted',
          'explicit_raw_visits', 'processed_insertion_skips', 'processed_flip_skips',
          'insertion_caps_built', 'flip_caps_built', 'heap_build_items')
TIE_FIELDS = ('structural_tie_attempts', 'structural_tie_witnesses',
              'structural_tie_decisions', 'structural_tie_canonical_switches')
manifest = {}
issues = []


def record(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    manifest[str(path)] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
    return data


def reject_constant(value):
    raise ValueError('Nonfinite JSON constant: ' + value)


def unique_pairs(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError('Duplicate JSON key: ' + key)
        out[key] = value
    return out


def read_json(path):
    return json.loads(record(path), object_pairs_hook=unique_pairs, parse_constant=reject_constant)


def need(condition, message):
    if not condition:
        issues.append(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def relation_identity(witness):
    candidates = sorted(((witness['source_candidate_id'], witness['source_edit']),
                         (witness['target_candidate_id'], witness['target_edit'])))
    return {**{k: witness[k] for k in ('kind', 'parent_version_id', 'operator_sha256',
                'opinion_sha256', 'opinion_denominator', 'operator_scale', 'score_unit', 'swap')},
            'candidates': [{'candidate_id': e, 'edit': edit} for e, edit in candidates]}


def distribution(values):
    return {'n': len(values), 'median': statistics.median(values),
            'minimum': min(values), 'maximum': max(values)}


def work_metric(rows, section, key):
    records = [q['counters'] for w in rows for q in w['trace']['requests']] if section == 'numeric' else [
        a for w in rows for q in w['trace']['requests'] for a in q['access']['epochs']]
    known = [r[key] for r in records if type(r.get(key)) is int]
    return {'total': sum(known), 'mean_per_Q4_worker': sum(known) / len(rows),
            'records_with_field': len(known), 'records_in_scope': len(records),
            'complete_field_coverage': len(known) == len(records)}


def stats_group(rows):
    return {
        'workers': len(rows),
        'service_seconds': distribution([w['cost'] for w in rows]),
        'service_seconds_total': sum(w['cost'] for w in rows),
        'service_seconds_decimal_sum_of_serialized_values': str(sum((w['decimal_cost'] for w in rows), Decimal(0))),
        'process_wall_seconds_total': sum(w['scheduler']['process_wall_seconds'] for w in rows),
        'process_peak_rss_bytes': distribution([w['trace']['process_peak_rss_bytes'] for w in rows]),
        'process_peak_rss_MiB': distribution([w['trace']['process_peak_rss_bytes'] / 2**20 for w in rows]),
        'external_sampled_peak_rss_bytes': distribution([w['scheduler']['external_sampled_peak_rss_bytes'] for w in rows]),
        'numeric_work': {key: work_metric(rows, 'numeric', key) for key in COUNTERS},
        'access_work': {key: work_metric(rows, 'access', key) for key in ACCESS},
        'source_files': [str(w['path']) for w in rows],
    }


cfg = read_json(ROOT / 'protocol/A2_TIE_RETEST.json')
input_manifest = read_json(ROOT / 'protocol/A2_TIE_RETEST_INPUTS.json')
old_input_manifest = read_json(ROOT / 'protocol/A2_CONFIRMATION_INPUTS.json')
schedule = read_json(ROOT / 'raw/a2_tie_retest/SCHEDULE_RESULTS.json')
frozen = read_json(ROOT / 'raw/a2_tie_retest/FROZEN_JOBS.json')
old_frozen = read_json(ROOT / 'raw/a2_confirmation/FROZEN_JOBS.json')
archived_summary = read_json(ROOT / 'reports/A2_TIE_RETEST_SUMMARY.json')
archived_analysis = read_json(ROOT / 'reports/TIE_RETEST_ANALYSIS.json')
old_judgment = read_json(ROOT / 'reports/A2_CONFIRMATION_JUDGMENT.json')
accounting_archive = read_json(ROOT / 'review/TIE_FINAL_ACCOUNTING_AUDIT.json')
witness_archive = read_json(ROOT / 'reports/TIE_TIMED_WITNESS_VERIFICATION.json')
full_timed_archive = read_json(ROOT / 'reports/TIE_TIMED_OTC_FULL_REPLAY.json')
fixed_archive = read_json(ROOT / 'reports/TIE_FIXED_INDEPENDENT_VERIFICATION.json')

need(cfg['stage'] == 'revision_retest' and cfg['unseen_confirmation'] is False, 'Retest labels differ')
need(old_judgment['status'] == 'failed', 'Original confirmation judgment not failed')
need(frozen['jobs'] == old_frozen['jobs'], 'Retest and original rosters differ')
fixture_fields = ('graphs', 'fixtures', 'domain', 'independent_opinion_rows', 'input_source_files_sha256')
fixture_identity = {k: input_manifest.get(k) == old_input_manifest.get(k) for k in fixture_fields}
need(all(fixture_identity.values()), 'Retest exact input declarations differ from original')
cells = list(product(cfg['graphs'], cfg['streams'], cfg['seed_labels']))
need(len(cells) == 12 and len(frozen['jobs']) == 108, 'Planned roster shape differs')
scheduled = {r['position']: r for r in schedule['jobs']}
analyzed = {r['position']: r for r in archived_analysis['workers']}
need(len(scheduled) == 108 and len(analyzed) == 108, 'Scheduler or analyzer missing worker')
files = sorted((ROOT / 'raw/a2_tie_retest').glob('[0-9]*.json'))
need(len(files) == 108, 'Numbered raw worker JSON count differs')
workers = []
prefix_rows = []
relations = {}
declarations = Counter()
tie_counts = Counter()
tie_from_evidence = Counter()
old_statuses = Counter()
new_statuses = Counter()
old_worker_statuses = Counter()
exact_request_keys = set()
accepted = 0
old_accepted = 0
request_commit_sum = 0
counter_discrepancies = []
max_cost_reconciliation_error = 0.0
old_new_source_pairs = []

for position, job in enumerate(frozen['jobs']):
    name = f"{position:03d}_{job['graph']}_{job['stream']}_{job['seed_label']}_{job['label']}.json"
    path = ROOT / 'raw/a2_tie_retest' / name
    trace = read_json(path)
    dec_trace = json.loads(path.read_bytes(), parse_float=Decimal)
    old_path = ROOT / 'raw/a2_confirmation' / name
    old = read_json(old_path)
    old_worker_statuses[old['status']] += 1
    row = scheduled[position]
    need(row['job'] == job and row['result'] == name, f'Job binding failed: {name}')
    need(all(trace.get(k) == v and old.get(k) == v for k, v in job.items()), f'Raw identity differs: {name}')
    need(trace['schedule_position'] == old['schedule_position'] == position, f'Position differs: {name}')
    need(trace['status'] == row['status'] == 'completed' and row['returncode'] == 0, f'Worker incomplete: {name}')
    need(trace['unseen_confirmation'] is False and trace['original_confirmation_status'] == 'failed', f'Raw study label differs: {name}')
    need(analyzed[position]['valid'] is True and analyzed[position]['complete'] is True, f'Archived analyzer did not accept worker: {name}')
    cost = trace['prefixes']['4']
    components = trace['structural_seconds'] + sum(q['request_seconds'] for q in trace['requests'])
    err = abs(cost - components)
    max_cost_reconciliation_error = max(max_cost_reconciliation_error, err)
    need(err <= 1e-7 and cost == trace['service_accounted_seconds'], f'Complete cost accounting differs: {name}')
    need(abs(cost - analyzed[position]['Q4_seconds']) <= 1e-7, f'Archived analyzer cost differs: {name}')
    need([q['query_position'] for q in trace['requests']] == [1, 2, 3, 4], f'Request roster differs: {name}')
    old_by_q = {q['query_position']: q for q in old['requests']}
    need(set(old_by_q) == {1, 2, 3, 4}, f'Original request roster differs: {name}')
    for field in ('graph_hash', 'fixture_npz_sha256', 'fixture_matrix_sha256', 'root_version_id'):
        need(trace[field] == old[field], f'Input/root changed {field}: {name}')
    old_new_source_pairs.append({'original': str(old_path), 'revision': str(path)})
    for request in trace['requests']:
        query = request['query_position']
        before = old_by_q[query]
        new_statuses[request['status']] += 1
        old_statuses[before['status']] += 1
        request_commit_sum += request['commits']
        need(request['status'] == 'budget_stop' and request['commits'] == 15, f'Request incomplete: {name} Q{query}')
        exact_request_keys.add((trace['graph'], trace['stream'], trace['seed_label'], trace['graph_hash'],
                                trace['fixture_npz_sha256'], query, request['opinion_hash']))
        left = [d for d in before['decisions'] if d['status'] == 'accepted']
        right = [d for d in request['decisions'] if d['status'] == 'accepted']
        old_accepted += len(left)
        accepted += len(right)
        differences = []
        for key in ('opinion_hash', 'root_version_id'):
            if before[key] != request[key]:
                differences.append({'field': key, 'old': before[key], 'new': request[key]})
        for i, decision in enumerate(left):
            for key in ('epoch', 'winner_id', 'parent_version_id', 'current_version_id', 'low', 'high'):
                if i >= len(right) or decision.get(key) != right[i].get(key):
                    differences.append({'accepted_position': i + 1, 'field': key,
                                        'old': decision.get(key), 'new': right[i].get(key) if i < len(right) else None})
        prefix_rows.append({'raw_original': str(old_path), 'raw_revision': str(path), 'query_position': query,
                            'old_accepted_prefix': len(left), 'revised_accepted': len(right),
                            'original_status': before['status'], 'revised_status': request['status'],
                            'mismatches': differences})
        need(not differences, f'Original accepted prefix mismatch: {name} Q{query}')
        derived = Counter({k: 0 for k in TIE_FIELDS})
        for decision in request['decisions']:
            proof = decision.get('comparison_resolution')
            if proof is None:
                continue
            success = type(proof.get('canonical_winner_id')) is int
            switch = success and proof['canonical_winner_id'] != proof['provisional_winner_id']
            derived['structural_tie_attempts'] += len(proof['overlap_ids'])
            derived['structural_tie_witnesses'] += len(proof['witnesses'])
            derived['structural_tie_decisions'] += int(success)
            derived['structural_tie_canonical_switches'] += int(switch)
            for i, witness in enumerate(proof['witnesses']):
                declaration = hashlib.sha256(canonical(witness).encode()).hexdigest()
                declarations[declaration] += 1
                identity = relation_identity(witness)
                relation_hash = hashlib.sha256(canonical(identity).encode()).hexdigest()
                rel = relations.setdefault(relation_hash, {'identity': identity, 'observations': []})
                rel['observations'].append({'raw_file': str(path), 'schedule_position': position,
                    'graph': trace['graph'], 'stream': trace['stream'], 'seed_label': trace['seed_label'],
                    'method': trace['method'], 'repeat_id': trace['repeat_id'], 'query_position': query,
                    'epoch': decision['epoch'], 'witness_index': i,
                    'canonical_switch': switch, 'winner_id': decision['winner_id'],
                    'provisional_winner_id': proof['provisional_winner_id'],
                    'source_field': f'requests[{query-1}].decisions[{decision["epoch"]-1}].comparison_resolution.witnesses[{i}]'})
                need(not proof['unresolved_ids'], f'Unsupported tie declaration: {name} Q{query}')
        for field in TIE_FIELDS:
            tie_counts[field] += request['counters'][field]
            tie_from_evidence[field] += derived[field]
            if request['counters'][field] != derived[field]:
                counter_discrepancies.append({'raw': str(path), 'query': query, 'field': field})
    workers.append({'path': path, 'trace': trace, 'cost': cost,
                    'decimal_cost': dec_trace['prefixes']['4'], 'scheduler': row})

need(not counter_discrepancies, 'Tie counters differ from witness declarations')
need(accepted == request_commit_sum == 6480, 'Accepted/reported commit total differs')
need(old_accepted == 5769, 'Original accepted decision count differs')
need(len(exact_request_keys) == 48, 'Distinct exact request count differs')
need(tie_counts['structural_tie_witnesses'] == 90 and len(relations) == 10, 'Witness observation/relation counts differ')
need(all(len(v['observations']) == 9 for v in relations.values()), 'Relation exposures differ from 3 methods x 3 repeats')

overall = {m: stats_group([w for w in workers if w['trace']['method'] == m]) for m in METHODS}
graph_groups = {g: {m: stats_group([w for w in workers if w['trace']['graph'] == g and w['trace']['method'] == m])
                    for m in METHODS} for g in cfg['graphs']}
cell_rows, csv_rows, method_csv_rows = [], [], []
lookup = {(w['trace']['graph'], w['trace']['stream'], w['trace']['seed_label'], w['trace']['repeat_id'], w['trace']['method']): w for w in workers}
pairwise = []
for cell in cells:
    values = {}
    for method in METHODS:
        rows = [lookup[(*cell, repeat, method)] for repeat in range(3)]
        values[method] = stats_group(rows)
        values[method]['seconds_by_repeat'] = [w['cost'] for w in rows]
        method_csv_rows.append({'graph': cell[0], 'stream': cell[1], 'seed_label': cell[2], 'method': method,
            'workers': 3, 'seconds_r0': rows[0]['cost'], 'seconds_r1': rows[1]['cost'], 'seconds_r2': rows[2]['cost'],
            'median_seconds': values[method]['service_seconds']['median'], 'sum_seconds': values[method]['service_seconds_total'],
            'median_RSS_MiB': values[method]['process_peak_rss_MiB']['median'],
            **{k+'_per_Q4_mean': values[method]['numeric_work'][k]['mean_per_Q4_worker'] for k in ('endpoint_checked','gram_materializations','response_blocks')},
            **{k+'_per_Q4_mean': values[method]['access_work'][k]['mean_per_Q4_worker'] for k in ('frontier_rebuilds','insertion_emissions','flips_emitted','raw_heap_pops','warm_screen_rows')},
            'source_r0': str(rows[0]['path']), 'source_r1': str(rows[1]['path']), 'source_r2': str(rows[2]['path']),
            'cost_field': 'prefixes.4', 'RSS_field': 'process_peak_rss_bytes / 1048576',
            'numeric_count_fields': 'sum(requests[*].counters.<metric>) / 3 workers',
            'access_count_fields': 'sum(requests[*].access.epochs[*].<metric>) / 3 workers'})
    ratios = {m+'_over_H': values[m]['service_seconds_total'] / values['H']['service_seconds_total'] for m in ('D','S')}
    archived_cell = next(x for x in archived_summary['cells'] if (x['graph'],x['stream'],x['seed_label']) == cell)
    for m in METHODS:
        need(values[m]['service_seconds']['median'] == archived_cell['methods'][m]['median_seconds'], f'Cell median differs: {cell} {m}')
    for m in ('D','S'):
        need(abs(ratios[m+'_over_H'] - archived_cell['comparisons']['H_over_'+m]['inverse_speedup_reference_over_H']) < 1e-12, f'Cell paired ratio differs: {cell} {m}')
    for repeat in range(3):
        costs = {m: lookup[(*cell,repeat,m)]['cost'] for m in METHODS}
        pairwise.append({'graph': cell[0], 'stream': cell[1], 'seed_label': cell[2], 'repeat_id': repeat,
            'H_over_D': costs['H']/costs['D'], 'H_over_S': costs['H']/costs['S'],
            'D_faster_than_S': costs['D'] < costs['S'], 'H_faster_than_D': costs['H'] < costs['D'],
            'H_faster_than_S': costs['H'] < costs['S']})
    cell_rows.append({'graph': cell[0], 'stream': cell[1], 'seed_label': cell[2], 'methods': values, 'paired_sum_ratios': ratios})
    csv_rows.append({'graph': cell[0], 'stream': cell[1], 'seed_label': cell[2], 'repeats_per_method': 3,
        **{m+'_median_seconds': values[m]['service_seconds']['median'] for m in METHODS},
        **{m+'_sum_seconds': values[m]['service_seconds_total'] for m in METHODS}, **ratios,
        **{m+'_median_RSS_MiB': values[m]['process_peak_rss_MiB']['median'] for m in METHODS},
        'cost_field': 'prefixes.4', 'ratio_definition': 'sum(reference 3 repeats) / sum(H 3 repeats)',
        'raw_source_paths_json': json.dumps([p for m in METHODS for p in values[m]['source_files']])})

totals = {m: overall[m]['service_seconds_total'] for m in METHODS}
speedups = {m: totals[m]/totals['H'] for m in ('D','S')}
savings = {m: 100*(1-totals['H']/totals[m]) for m in ('D','S')}
archived_prose_path = ROOT / 'reports/A2_TIE_REVISION_REPORT_ZH.txt'
archived_prose = record(archived_prose_path).decode('utf-8')
maximum_cell_D_over_H = max(c['paired_sum_ratios']['D_over_H'] for c in cell_rows)
presentation_notes = [{
    'kind': 'minor_archived_prose_rounding_discrepancy',
    'source_file': str(archived_prose_path),
    'archived_prose': 'D/H 2.660–4.244',
    'archived_phrase_present': 'D/H 2.660–4.244' in archived_prose,
    'recomputed_maximum_cell_ratio': maximum_cell_D_over_H,
    'direct_rounding_to_3_decimals': f'{maximum_cell_D_over_H:.3f}',
    'interpretation': 'The archived table already gives 4.243. The prose maximum 4.244 is consistent with double rounding through 4.2435; direct rounding of raw-derived ratio gives 4.243. Core raw aggregation remains consistent.',
}]
for m in METHODS:
    need(abs(totals[m] - accounting_archive['full_service_totals_seconds'][m]) <= 1e-10, f'Archived full total differs: {m}')

archive_relation_map = {x['exact_relation_sha256']: x for x in witness_archive['deduplicated_verified_relations']}
need(set(relations) == set(archive_relation_map), 'Recounted relation identities differ from archived verified relation identities')
need(dict(declarations) == witness_archive['declaration_observation_counts'], 'Declaration hashes/exposures differ from archived checker')
archive_raw_binding_mismatches = []
for w in workers:
    relative = str(w['path'].relative_to(ROOT))
    archived = witness_archive['input_and_raw_files'].get(relative)
    if not archived or archived['sha256'] != manifest[str(w['path'])]['sha256']:
        archive_raw_binding_mismatches.append(relative)
need(not archive_raw_binding_mismatches, 'Archived witness checker is not bound to all observed raw files')
selected = ROOT / full_timed_archive['raw_file']
need(manifest[str(selected)]['sha256'] == full_timed_archive['raw_sha256'], 'Timed full replay raw binding differs')
selected_trace = next(w['trace'] for w in workers if w['path'] == selected)
selected_request = selected_trace['requests'][3]
need(hashlib.sha256(canonical(selected_request).encode()).hexdigest() == full_timed_archive['request_sha256'], 'Timed full replay Q4 binding differs')

directional_out = OUT / 'directional_recomputed'
directional_checks = read_json(directional_out / 'verification.json')
old_directional_checks = read_json(SUPPLEMENT / 'evidence/directional/verification.json')
need(directional_checks == old_directional_checks, 'Directional reaggregation differs from archived verification')
directional_exact_files = []
for filename in ('summary.csv','pairing_summary.csv','run_alignment.csv','field_quality.csv','event_audit.csv','source_locations.csv','source_manifest.csv'):
    a, b = directional_out / filename, SUPPLEMENT / 'evidence/directional' / filename
    identical = record(a) == record(b)
    directional_exact_files.append({'file': filename, 'fresh_output': str(a), 'archived_output': str(b), 'byte_identical': identical})
    need(identical, f'Directional aggregation output changed: {filename}')
with (directional_out/'summary.csv').open(newline='') as handle:
    dir_summary = list(csv.DictReader(handle))
with (directional_out/'pairing_summary.csv').open(newline='') as handle:
    pairing = list(csv.DictReader(handle))
with (directional_out/'source_manifest.csv').open(newline='') as handle:
    source_manifest = list(csv.DictReader(handle))
for item in source_manifest:
    path = SUPPLEMENT / 'source/legacy_v6' / item['source_file']
    record(path)
    need(manifest[str(path)]['sha256'] == item['sha256_before'] == item['sha256_after'], f'Directional source hash differs: {path}')
directional_groups = []
for co,w in product(('alpha','bio'),(1,4,16,64)):
    group = [r for r in dir_summary if r['cohort'] == co and int(r['weight']) == w and r['aggregation'] == 'weight_all_retained_tolerances']
    directional_groups.append({'cohort': co, 'weight': w, 'events': int(group[0]['n_events']),
        **{r['metric']: float(r['ratio_median']) for r in group},
        'source_file': str(SUPPLEMENT / f'source/legacy_v6/data/directional_stress_{co}_{w}_events.csv'),
        'formula_fields': ['same_state_old','completed'], 'policy_fields': ['baseline_radius','radius']})

figures = [
    ('figures/tie_revision/a2_tie_complete_cost.svg','Old fixed-input revision complete service costs; accompanying a2_tie_plot_data.json'),
    ('figures/tie_revision/a2_tie_cost_memory.svg','Old fixed-input revision cost and memory'),
    ('figures/tie_revision/a2_tie_coverage.svg','Old fixed-input revision coverage and work'),
    ('figures/tie_revision/a2_tie_plot_data.json','Existing numeric plot data; reaggregation available in audit tables'),
    ('baseline_r15/figures/directional_radius_r10.pdf','Existing maintained-history baseline_radius/radius panel; cannot label as same-state formula ratio'),
    ('baseline_r15/figures/directional_stress.pdf','Existing full directional multi-panel figure; first panel is policy-history ratio'),
    ('baseline_r15/experimental_records/legacy_v6/figures/directional_stress.pdf','Original directional multi-panel PDF'),
    ('baseline_r15/figures/build_r10_panels.py','Existing panel extraction source; no numerical experiment required to reuse PDF'),
    ('baseline_r15/sections/eval_coupling_figure.tex','Existing manuscript caption/layout reference'),
]
figure_inventory = []
for rel,note in figures:
    path = ROOT/rel
    record(path)
    figure_inventory.append({'path': str(path), 'sha256': manifest[str(path)]['sha256'], 'reuse_note': note})

result = {
    'schema_version': 1, 'generated_at_utc': datetime.now(timezone.utc).isoformat(),
    'audit_kind': 'existing_record_bookkeeping_and_saved_radius_aggregation_only',
    'source_root': str(ROOT), 'no_numerical_replay': True, 'no_new_performance_measurement': True,
    'no_archived_runtime_or_checker_imports': True,
    'scope': 'Diagnosed fixed-input revision retest, not unseen confirmation. Original confirmation remains failed. No old/new hardware timing ratio.',
    'status': 'passed' if not issues else 'issues_found', 'issues': issues,
    'nonfatal_presentation_notes': presentation_notes,
    'denominators': {'input_cells': len(cells), 'methods': 3, 'repeats': 3, 'raw_workers': len(workers),
        'worker_requests': sum(new_statuses.values()), 'distinct_fixed_requests': len(exact_request_keys),
        'accepted_decisions': accepted, 'request_commit_sum': request_commit_sum, 'paired_repeats': len(pairwise)},
    'new_request_status_counts': dict(new_statuses),
    'cost_definition': 'Per-worker prefixes.4 = structural_seconds + sum(requests[*].request_seconds), includes full setup and Q4.',
    'cost_accounting_max_abs_error_seconds': max_cost_reconciliation_error,
    'cost_totals_seconds_binary64': totals,
    'cost_totals_seconds_decimal_sum_of_serialized_values': {m: overall[m]['service_seconds_decimal_sum_of_serialized_values'] for m in METHODS},
    'display_totals_3dp_seconds': {m: f'{totals[m]:.3f}' for m in METHODS},
    'paired_ratio_definition': 'sum(reference complete service costs) / sum(H complete service costs), over all three repeats within each complete input cell; not a ratio of medians.',
    'speedup_reference_over_H': speedups, 'display_speedup_2dp': {m: f'{speedups[m]:.2f}' for m in ('D','S')},
    'savings_percent': savings,
    'paired_repeat_checks': {'all_D_faster_than_S': all(r['D_faster_than_S'] for r in pairwise),
        'H_faster_than_D_count': sum(r['H_faster_than_D'] for r in pairwise),
        'H_faster_than_S_count': sum(r['H_faster_than_S'] for r in pairwise),
        'maximum_H_over_D': max(r['H_over_D'] for r in pairwise),
        'minimum_H_over_D': min(r['H_over_D'] for r in pairwise),
        'maximum_H_over_S': max(r['H_over_S'] for r in pairwise),
        'minimum_H_over_S': min(r['H_over_S'] for r in pairwise)},
    'cells': cell_rows, 'graph_method_summaries': graph_groups, 'overall_method_summaries': overall,
    'per_repeat_pairs': pairwise,
    'original_prefix_reproduction': {'original_successful_decisions_recounted': old_accepted,
        'compared_requests': len(prefix_rows), 'matched_requests': sum(not r['mismatches'] for r in prefix_rows),
        'prefix_fields': ['epoch','winner_id','parent_version_id','current_version_id','low','high'],
        'request_binding_fields': ['opinion_hash','root_version_id'],
        'trace_binding_fields': ['graph_hash','fixture_npz_sha256','fixture_matrix_sha256','root_version_id'],
        'original_worker_status_counts': dict(old_worker_statuses), 'original_request_status_counts': dict(old_statuses),
        'added_accepted_decisions_after_old_prefixes': accepted-old_accepted,
        'mismatches': [r for r in prefix_rows if r['mismatches']], 'requests': prefix_rows,
        'scope': 'Exact comparison of saved IDs, versions, interval integers and bindings. No independent objective recomputation.'},
    'ties_recounted_from_raw': {'counter_totals': dict(tie_counts), 'declaration_derived_totals': dict(tie_from_evidence),
        'counter_discrepancies': counter_discrepancies, 'witness_observations': sum(declarations.values()),
        'unique_declaration_hashes': len(declarations), 'distinct_exact_relations': len(relations),
        'distinct_switch_relations': sum(any(o['canonical_switch'] for o in r['observations']) for r in relations.values()),
        'declared_relations': [{'relation_sha256': k, **v} for k,v in sorted(relations.items())],
        'scope': 'Declaration counts and exact-record identity/deduplication reproduced. Matrix symmetry, candidate legality, positive gain and full-catalog optimality are not reverified here.'},
    'archived_independent_checker_evidence': {
        'record_only_not_rerun': True,
        'witness_report': str(ROOT/'reports/TIE_TIMED_WITNESS_VERIFICATION.json'),
        'witness_report_status': witness_archive['status'], 'witness_report_counts': witness_archive['counts'],
        'witness_scope': witness_archive['scope'], 'all_108_raw_digest_bindings_match': not archive_raw_binding_mismatches,
        'relation_identity_sets_match_raw_recount': set(relations) == set(archive_relation_map),
        'fixed_report': str(ROOT/'reports/TIE_FIXED_INDEPENDENT_VERIFICATION.json'),
        'fixed_status': fixed_archive['status'], 'fixed_complete_requests': len(fixed_archive['cases']),
        'fixed_decisions': fixed_archive['decisions'],
        'timed_full_catalog_report': str(ROOT/'reports/TIE_TIMED_OTC_FULL_REPLAY.json'),
        'timed_full_catalog_status': full_timed_archive['status'],
        'timed_full_catalog_request': {'raw_file': str(selected), 'query_position': 4, 'decisions': len(selected_request['decisions'])},
        'timed_full_catalog_scope': full_timed_archive['scope'],
        'published_intervals': 'Archived full timed replay checks interval intersection consistency, not full interval enclosure.',
        'does_not_imply': 'No all-432 independent full-catalog optimality or independent positive-gain certification.'},
    'retained_adverse_findings': {'original_confirmation_status': old_judgment['status'],
        'original_confirmation_source': str(ROOT/'reports/A2_CONFIRMATION_JUDGMENT.json'),
        'original_planned_workers': old_judgment['planned_workers'], 'original_complete_workers': old_judgment['complete_workers'],
        'original_failed_gates': old_judgment['failed_gates'], 'original_scope': old_judgment['scope'],
        'exact_input_manifest_fields_match_original': fixture_identity, 'unseen_confirmation': False,
        'new_gate_applied_to_old_run': False},
    'directional_reproduction': {'checks': directional_checks, 'archive_comparison': directional_exact_files,
        'groups': directional_groups, 'paired_key': ['cohort','w','Decimal-normalized rtol','epoch','edge'],
        'event_stage': 'First candidate score in accepted-action epoch, before within-epoch refinement/reanchor/commit; stopping-round candidates excluded by original event-writing scope.',
        'same_input_raw_completed': 'same_state_old/completed: two finite-precision formulas evaluated at the same saved directional-policy approximate state; formulas have corresponding distinct centers.',
        'same_input_selected': 'same_state_old/radius, with radius=min(same_state_old,completed); the ratio>=1 property follows from the selection rule.',
        'own_history_policy': 'baseline_radius/radius: matched candidate times under two separately maintained histories; not a fixed-history formula-only comparison.',
        'old_vs_baseline_radius_different_rows': sum(int(r['old_baseline_radius_different_n']) for r in pairing),
        'posterior_vs_baseline_gram_different_rows': sum(int(r['posterior_baseline_gram_different_n']) for r in pairing),
        'age_different_rows': sum(int(r['baseline_directional_age_different_n']) for r in pairing),
        'first_epoch_events': sum(int(r['epoch1_n']) for r in pairing),
        'first_epoch_old_equals_baseline_events': sum(int(r['epoch1_old_baseline_exact_n']) for r in pairing),
        'arithmetic_only_limit': 'Saved radii and source semantics were audited; per-event full G,h,T,P and residual vectors are not retained, so no independent reconstruction of every radius or bound validity is claimed.',
        'no_new_speedup_or_causal_performance_claim': True,
        'reproduction_command': 'python -B '+str(SUPPLEMENT/'evidence/directional/audit_directional.py')+' --source '+str(SUPPLEMENT/'source/legacy_v6')+' --out '+str(directional_out)},
    'reusable_figures_and_data': figure_inventory,
    'precision_and_rounding': {'input': 'Use the full precision of serialized JSON/CSV values; no early rounding.',
        'timing_math': 'Python binary64 sums/medians/ratios, matching archived summaries within 1e-10 seconds; exact decimal sums of serialized timings also retained as strings.',
        'display': 'Timing table: 3 decimal seconds; speedups: 2 or 3 decimals as labeled; work means: 1 decimal; RSS: 2 decimal MiB (2^20 bytes).',
        'range': 'Observed min-max across repeats/workers, not confidence intervals.',
        'directional': 'Median of rowwise ratios; all retained candidate events weighted equally. Quantiles use linear interpolation at index (n-1)*p.',
        'time_precision_limit': 'Serialized digits are arithmetic precision, not a claim about physical timer accuracy.',
        'rss': 'Process-lifetime high-water RSS distribution, not an additive sum; external sampled maxima retained separately.',
        'work': 'Separate executed visit/Gram/response/emission/pop counts; repeated visits do not count unique candidates.'},
    'source_file_manifest': manifest,
}

def write_csv(name, rows):
    with (OUT/name).open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

write_csv('a2_tie_cells.csv', csv_rows)
write_csv('a2_tie_cell_methods.csv', method_csv_rows)
write_csv('directional_groups.csv', directional_groups)
write_csv('a2_graph_method_work.csv', [
    {'graph': graph, 'method': method, 'workers': group['workers'],
     'RSS_median_MiB': group['process_peak_rss_MiB']['median'],
     'RSS_min_MiB': group['process_peak_rss_MiB']['minimum'], 'RSS_max_MiB': group['process_peak_rss_MiB']['maximum'],
     **{key+'_total': group['numeric_work'][key]['total'] for key in ('endpoint_checked','gram_materializations','response_blocks')},
     **{key+'_per_Q4_mean': group['numeric_work'][key]['mean_per_Q4_worker'] for key in ('endpoint_checked','gram_materializations','response_blocks')},
     **{key+'_per_Q4_mean': group['access_work'][key]['mean_per_Q4_worker'] for key in ('frontier_rebuilds','insertion_emissions','flips_emitted','raw_heap_pops','warm_screen_rows','seed_screen_rows','cold_emitted_for_screen')},
     'numeric_fields': 'requests[*].counters.<metric>', 'access_fields': 'requests[*].access.epochs[*].<metric>',
     'RSS_field': 'process_peak_rss_bytes / 1048576'}
    for graph, groups in graph_groups.items() for method, group in groups.items()])

# Verify all source bytes observed in this audit remain unchanged at completion.
changed = [path for path,item in manifest.items() if hashlib.sha256(Path(path).read_bytes()).hexdigest() != item['sha256']]
result['source_files_changed_during_audit'] = changed
need(not changed, 'Observed source files changed during audit')
result['status'] = 'passed' if not issues else 'issues_found'
(OUT/'evidence_audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')

lines = ['J-CERT+ V2：旧证据只读核算审计', '',
    '范围：只读现有 JSON/CSV、源码与归档 checker 报告；没有执行旧数值 replay、求解或性能实验。',
    '原冻结 confirmation 仍为 failed；12 单元结果属于已诊断固定输入上的修订复测，不属于新未见确认。',
    '本审计不计算旧/新硬件之间的时间比。', '',
    '1. 本轮从原始记录复算',
    f'108 个 worker，432 次请求，48 条不同固定意见请求，6480 次接受提交；请求状态 {dict(new_statuses)}。',
    '完整服务成本 = prefixes.4 = structural_seconds + sum(requests[*].request_seconds)。',
    '全量成本 D/S/H：'+' / '.join(f'{totals[m]:.9f}' for m in METHODS)+' 秒。',
    '三位小数：'+' / '.join(f'{totals[m]:.3f}' for m in METHODS)+' 秒。',
    f'D/H = {speedups["D"]:.12f}，S/H = {speedups["S"]:.12f}；两位小数 3.59×、14.26×。',
    f'节省比例：对 D {savings["D"]:.6f}%，对 S {savings["S"]:.6f}%。',
    f'36 个配对重复中 D 均快于 S，H 均快于 D/S；最大 H/D={max(r["H_over_D"] for r in pairwise):.12f}。',
    '单元耗时为三次重复中位数；加速比为该单元三个配对重复的总成本比，不是中位数之比。', '',
    '图 | 意见族 | 标签 | D中位秒 | S中位秒 | H中位秒 | 配对和D/H | 配对和S/H']
for row in csv_rows:
    lines.append(f'{row["graph"]} | {row["stream"]} | {row["seed_label"]} | {row["D_median_seconds"]:.3f} | {row["S_median_seconds"]:.3f} | {row["H_median_seconds"]:.3f} | {row["D_over_H"]:.3f} | {row["S_over_H"]:.3f}')
lines += ['', '2. 工作与进程峰值 RSS', '每图每臂 18 个 Q4 worker；工作量为每 worker 均值；RSS 为跨 worker 中位数及 min–max，单位 MiB。',
          '图/臂 | 端点检查 | Gram物化 | 响应块 | 前沿重建 | warm检查 | RSS中位 (min–max)']
for graph, groups in graph_groups.items():
    for method, group in groups.items():
        n, a, rss = group['numeric_work'], group['access_work'], group['process_peak_rss_MiB']
        lines.append(f'{graph}/{method} | {n["endpoint_checked"]["mean_per_Q4_worker"]:.1f} | {n["gram_materializations"]["mean_per_Q4_worker"]:.1f} | {n["response_blocks"]["mean_per_Q4_worker"]:.1f} | {a["frontier_rebuilds"]["mean_per_Q4_worker"]:.1f} | {a["warm_screen_rows"]["mean_per_Q4_worker"]:.1f} | {rss["median"]:.2f} ({rss["minimum"]:.2f}–{rss["maximum"]:.2f})')
lines += ['端点检查是跨版本可重复访问，不能改写为不同候选数；Gram、响应块、插入发出、翻转发出、heap pop、warm检查分别保留。',
          'RSS 是进程生命周期高水位；外部采样峰值在 JSON 另列；不能把重叠内存字段相加。', '',
          '3. 5769 原成功决策与 90/10 平局账目',
          f'从 108 份原 confirmation JSON 重新计数 accepted={old_accepted}，逐项匹配到修订的成功前缀；432 次请求均匹配。',
          '核对 epoch、winner_id、parent_version_id、current_version_id、low、high；请求 opinion_hash/root_version_id 和图/fixture 摘要亦一致。',
          f'复算 90 条 witness 观测、10 个不同精确关系，每关系 9 次暴露（3 臂×3 重复）；规范赢家切换 9 次，来自 1 个固定状态。',
          '这些是已保存声明的重计数和身份比较。本轮没有重新证明每条见证的矩阵对称、候选合法性或目标优性。',
          '归档独立 checker 报告 TIE_TIMED_WITNESS_VERIFICATION.json 的全部 108 份 raw 摘要、关系集合和声明次数与本轮读取结果一致。',
          '该旧报告验证了 432 条父链/6480 个当前父状态以及 90 条关系声明；不声称所有 432 次请求均做了全目录最优性或独立正增益验证。',
          '归档固定故障请求验证覆盖 10 次完整请求/150 次决策；实际 timed 全目录验证只覆盖 OTC/signed-neighbor/C1/Q4 的 1 次请求/15 次决策。',
          '原始公布增益区间检查为与独立区间相交一致性，不是完整包含性。上述数值验证结论来自归档 checker，本轮未 rerun。', '',
          '4. 方向性事件复算与语义',
          '已逐段检查并执行归档标准库聚合脚本 audit_directional.py，输出全部写入 audit/directional_recomputed。未导入源数值模块。',
          '重新得到 8 个权重组、20 个容差运行、41744 条事件；配对键为 cohort/w/规范化rtol/epoch/edge。',
          '全部事件唯一配对，三种比值均无无效行/零分母；completed<same_state_old 为41744，=或>为0；radius=min(...)违例为0。',
          'fresh summary、event_audit、pairing、alignment、field_quality、source_locations、source_manifest 与归档对应文件逐字节一致。',
          'same_state_old/completed：同一方向性策略状态上的两种公式；两证书分别用各自中心，不应写成固定同一中心。',
          'same_state_old/radius：与实际选择 min(old,completed) 比较；其>=1 是选择规则的结果。',
          'baseline_radius/radius：两次完整策略各自历史下的配对半径比；不能用作固定误差历史的公式独立收益。',
          'cohort | w | 事件数 | 同状态公式中位比 | 两策略历史中位比']
for group in directional_groups:
    lines.append(f'{group["cohort"]} | {group["weight"]} | {group["events"]} | {group["same_input_raw_completed"]:.12g} | {group["own_history_policy"]:.12g}')
lines += ['40352 行 same_state_old 与 baseline_radius 不同，40352 行 posterior 与 baseline_gram 不同；5260 行 age 不同。首轮1392行同状态旧半径与baseline半径一致。',
          '现有 directional_radius_r10.pdf 曲线使用 baseline_radius/radius；同状态公式数值请使用新的 directional_groups.csv 或 summary.csv 的 same_input_raw_completed 行。',
          '事件仅保存首次打分时点，先于本轮精化/重锚/提交；停止轮候选不在原始事件总体。',
          '事件未保留完整 G,h,T,P 和残差向量；本轮不声称独立重构每个半径或逐条重验有限精度上界。', '',
          '5. 保留不利结论与精度',
          f'原确认 108 个计划 worker 中仅 {old_judgment["complete_workers"]} 完成；原失败 gates：'+', '.join(old_judgment['failed_gates'])+'。',
          '固定输入在修订前后完全保留；旧失败不被本轮复测重分类。没有将复测解释成未见确认，也没有形成旧新硬件计时比。',
          '先按完整输入精度计算，最后呈现：秒3位小数、倍数2或3位、RSS2位、工作均值1位；原始数值和精确十进制序列和在JSON保留。',
          '发现一处旧正文末位舍入差异：最大单元D/H=4.2434988652427315，直接保留3位为4.243，旧表已正确；旧正文范围写4.244，疑似先舍入至4.2435再舍入所致。底层账目与汇总无差异。',
          'min–max 仅为观测范围，不是置信区间；反复计时和多方法不增加独立输入样本。', '',
          '6. 文件与出处', str(OUT/'a2_tie_cells.csv'), str(OUT/'a2_tie_cell_methods.csv'),
          str(OUT/'a2_graph_method_work.csv'), str(OUT/'directional_groups.csv'),
          str(OUT/'evidence_audit.json'),
          'JSON包含全部原始源文件绝对路径、字段定义、逐请求前缀核对、关系暴露与SHA-256。',
          '审计状态：'+result['status'], '审计问题：'+json.dumps(issues, ensure_ascii=False),
          '源文件在审计中变化：'+json.dumps(changed, ensure_ascii=False), '']
(OUT/'evidence_audit_zh.txt').write_text('\n'.join(lines), encoding='utf-8')
print(json.dumps({'status': result['status'], 'issues': issues, 'workers': len(workers), 'requests': sum(new_statuses.values()),
    'old_accepted': old_accepted, 'new_accepted': accepted, 'witnesses': sum(declarations.values()),
    'distinct_relations': len(relations), 'totals': totals, 'speedups': speedups,
    'source_files_changed': changed, 'outputs': ['evidence_audit.json','evidence_audit_zh.txt','a2_tie_cells.csv',
    'a2_tie_cell_methods.csv','a2_graph_method_work.csv','directional_groups.csv']}, ensure_ascii=False, indent=2))
raise SystemExit(0 if not issues else 1)
