"""Tiny width/input audit only; no service request, factorization, or full scan.

The n=82140 fixtures have at most six stored edges and O(n) CSR/vector storage.
Candidate operations touch at most five IDs or a seven-row emitted block.
All outputs stay beside this file; the archived source is imported read-only.
"""
import hashlib
import importlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch

sys.dont_write_bytecode = True
ROOT = Path('/workspace/scratch/faa1a8a62f06/original/J_CERT_Plus_A2_Exact_Tie_Revision_20261125')
sys.path.insert(0, str(ROOT))

import numpy as np
from scipy import sparse
from src.a2_catalog import AllCatalog, MixedFrontier
from src.a2_numeric import EndpointKernel
from src.a2_access import Access
from src.a2_session import A2Session, make_ledger
from src.a2_checker import A2CatalogReplay
from src.common import DEN, UNIT


def expect_raises(kind, fn):
    try:
        fn()
    except kind as error:
        return f'{type(error).__name__}: {error}'
    raise AssertionError(f'{kind.__name__} was not raised')


def run():
    n = 82140
    ids = np.array([26145*n+26146, 52289*n+52290, (n-2)*n+n-1], dtype=np.int64)
    assert ids[0] > 2**31-1 and ids[1] > 2**32-1
    assert int(ids[-1]) == 6746897459
    endpoints = [(int(e)//n, int(e)%n) for e in ids]
    left = [i for i, j in endpoints] + [j for i, j in endpoints]
    right = [j for i, j in endpoints] + [i for i, j in endpoints]
    W = sparse.csr_matrix((np.array([-1, 1, -1]*2, dtype=np.int8), (left, right)), shape=(n,n))
    cat = AllCatalog(W)
    assert cat.root_edge_ids.dtype == np.int64
    assert np.array_equal(cat.root_edge_ids, ids)
    assert np.array_equal(cat.flip_ids, ids[[0,2]])
    positive_reject = expect_raises(ValueError, lambda: cat.batch(ids[[1]]))
    b = cat.batch(ids[[0,2]])
    assert b.ids.dtype == b.i.dtype == b.j.dtype == b.weights.dtype == np.int64
    assert all(int(i)*n+int(j)==int(e) for i,j,e in zip(b.i,b.j,b.ids))
    assert b.flip.tolist() == [True, True] and b.weights.tolist() == [16,16]

    empty = sparse.csr_matrix((n,n),dtype=np.int8)
    allcat = AllCatalog(empty)
    positions = allcat.dense_positions(ids)
    assert positions.dtype == np.int64
    assert int(positions[-1]) == allcat.m-1 > 2**31-1
    for e, p in zip(ids, positions):
        i,j = divmod(int(e),n)
        assert int(p) == i*(2*n-i-1)//2+j-i-1
    checked = allcat.batch(ids.astype(np.uint64))
    assert np.array_equal(checked.ids,ids)
    rejects = {
        'positive_root_edge': positive_reject,
        'uint64_above_int64': expect_raises(OverflowError, lambda: allcat.batch(np.array([2**63],np.uint64))),
        'float_id': expect_raises(ValueError, lambda: allcat.batch([float(ids[-1])])),
        'negative_id': expect_raises(ValueError, lambda: allcat.batch([-1])),
        'reversed_pair': expect_raises(ValueError, lambda: allcat.batch([n])),
    }

    counts = {}
    first = next(allcat.iter_blocks(block_size=7,counters=counts))
    assert first.ids.tolist() == list(range(1,8))
    assert first.ids.dtype == np.int64 and counts['stream_pairs_examined']==7
    # Exercise the exact iterator expression at the last row without scanning M.
    i,j = n-2,n-1
    tail_expression = i*n + np.arange(j,j+1,dtype=np.int64)
    assert int(tail_expression[0]) == int(ids[-1])

    # Invoke the real heap-entry constructor with two sparse endpoint positions.
    frontier = MixedFrontier.__new__(MixedFrontier)
    frontier.catalog = allcat
    frontier.order = np.array([n-2,n-1],dtype=np.int64)
    frontier.xc = {n-2: np.int64(-(2**62)), n-1: np.int64(2**62-1)}
    frontier.rc = 3
    frontier.counters = {'insertion_caps_built':0}
    entry = frontier._entry(0,1)
    assert entry[1] == int(ids[-1])
    assert -entry[0] == (2**63-1+6)**2 > 2**63

    # Independent checker candidate decode and a bounded first block.
    replay = A2CatalogReplay(W, block_size=7)
    assert replay.candidate(int(ids[-1])) == (n-2,n-1,16,True)
    check_ids, _ = next(replay.iter_blocks())
    assert check_ids.dtype == np.int64 and len(check_ids)==7

    # The actual strict adapter handles a high canonical ID, using an exactly
    # representable diagonal-system state; no linear solver is involved.
    kernel = EndpointKernel(allcat)
    A = kernel.operator(empty)
    s = np.zeros(n,dtype=np.int64)
    s[n-2],s[n-1] = DEN//2, -DEN//2
    x = np.zeros(n,dtype=np.int64)
    x[n-2],x[n-1] = UNIT//32, -UNIT//32
    residual = np.abs(A@x-s*(UNIT//DEN))
    assert not residual.any()
    strict = kernel.strict(A,s,x,(A,s,x,UNIT,A.diagonal(),residual))
    survived,upper = strict.screen(ids[-1:],0)
    assert survived.tolist()==[int(ids[-1])] and survived.dtype==np.int64
    assert int(upper[0])>0

    # Both fail-closed admission guards are reached before numerical allocation.
    with patch('src.a2_session.lp.UpdatedFactor',side_effect=AssertionError('factor must not run')):
        n_reject = expect_raises(ValueError, lambda: A2Session(empty,'H'))
    fake = SimpleNamespace(m=3373067797)
    m_reject = expect_raises(ValueError, lambda: Access(fake,'D',make_ledger(False)))

    # Python JSON, NumPy <i8 hashing, and cache-key set dedup preserve >uint32 IDs.
    serialized = json.loads(json.dumps({'ids':ids.tolist(),'M':3373067797}))
    assert serialized['ids']==ids.tolist() and type(serialized['M']) is int
    assert len(set(map(int,np.r_[ids,ids]))) == len(ids)
    little = ids.astype('<i8',copy=False)
    raw_hash = hashlib.sha256(little.tobytes()).hexdigest()
    assert raw_hash == hashlib.sha256(b''.join(int(e).to_bytes(8,'little',signed=True) for e in ids)).hexdigest()

    # This documents an adapter boundary weakness, separate from the safe
    # engine-owned integer path: EndpointColumn coerces scalar floats with int.
    adapter_float = kernel.pool[0][float(ids[-1]) + .5]
    assert int(adapter_float) == n-2

    return {
        'status':'passed',
        'scope':'integer/input boundary tests only; no performance data or service request',
        'n':n,'tested_ids':ids.tolist(),'positions':positions.tolist(),
        'maximum_candidate_batch_rows':7,'full_catalog_allocations':0,
        'factorizations':0,'strict_high_id_rows':len(survived),
        'root_edge_promotion':'passed','frontier_python_integer_caps':'passed',
        'checker_high_id_decode':'passed','serialization_and_dedup':'passed',
        'fail_closed_admissions':{'n_guard':n_reject,'M_guard':m_reject},
        'catalog_input_rejections':rejects,
        'non_engine_adapter_observation':'EndpointColumn scalar int(key) accepts and truncates a fractional float; trusted A2 callers supply integers',
    }


if __name__=='__main__':
    result = run()
    output = Path(__file__).with_name('boundary_results.json')
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
