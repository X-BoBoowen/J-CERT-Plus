# J-CERT+ V2 runtime, integer-width, allocation, and harness audit

## Admission decision

**Admit H and Stream only to the preregistered, resource-bounded attempt after the narrow A2Session input-limit change. Keep D unstarted on Slashdot.** This is an admission decision, not evidence that the direct factor, a request, or the scale study completes. The existing numerical path always uses SciPy SuperLU direct factorization. Increasing the admitted vertex count does not select an iterative solver or a different sparse backend.

The archived source rejects `n > 10000`; V2 commit **4c2c7b7** raises that input boundary to `82140` and leaves the operator, solve, update, proof units, tolerances, and access decisions unchanged. D independently rejects `M >= 2**31`. Its mandatory endpoint/kind/weight payload alone is **57,342,152,549 bytes = 53.404041 GiB**, already far above V2's 4 GiB scale cap. Removing D's ordinal guard would also be incorrect without additional integer-width changes.

No blocking issue remains from the reviewed pre-freeze harness findings. The root implementer addressed the source/input/environment binding, job validation, memory classification, B1 timing, and skipped-stage accounting findings in commit 4c2c7b7. This audit independently reread those changes; the root, not this auditor, ran the runner's worker and regression tests.

## Scope and evidence

The original tree was inspected read-only at:

`/workspace/scratch/faa1a8a62f06/original/J_CERT_Plus_A2_Exact_Tie_Revision_20261125`

Unless a reference is explicitly labeled **V2**, line references below refer to that original tree. `legacy/` abbreviates:

`baseline_r15/experimental_records/evidence_supplement_20261124/source/legacy_v6/tools/`

The additional runner review refers to `/workspace/scratch/faa1a8a62f06/runtime`, commit 4c2c7b7. The audit made no production edits, started no experiment or benchmark, and performed no factorization or service request. The executed tests used at most seven candidate rows, sparse fixtures with at most six stored directed entries, and O(n) vectors/CSR metadata at n=82140. They did not enumerate or allocate the full candidate domain. All numerical imports and tests stopped before the root began measured work.

Evidence files beside this report:

- `dataset_and_payload.json`: read-only Slashdot archive verification, graph counts, dtypes, and arithmetic payload calculation.
- `boundary_audit.py` and `boundary_results.json`: passing integer and input-boundary checks against archived code.
- `import_inventory.json`: actual archive modules imported by A2Session and comparison with the retest manifest's source hashes. There were no mismatches.
- `native_inventory.json`: archived shared-object identities, SciPy SuperLU extension identity, linkage, and import-time BLAS inventory. The inventory's default thread counts are not benchmark settings; V2 explicitly limits the workers to one numerical thread.

The two historical revisions are distinct and must retain their meanings. `531522d09b962286afdcde9038ad1a1b0b5d90fa` is the frozen tie runtime; `9de16a76f5cddcdd4aba0c82d555f2ed42e46fe2` adds the retest input binding. A read-only Git diff between them contains only `protocol/A2_TIE_RETEST_INPUTS.json`, with no runtime-code change. Their history is available in the supplied `review/RESEARCH_HISTORY.bundle` restored by the root. This audit does not reinterpret the original confirmation or the diagnosed revision retest as new confirmation evidence.

## 1. Exact Slashdot input identity

The archive read was:

`baseline_r15/experimental_records/legacy_v6/datasets/Slashdot.npz`

Its SHA-256 is exactly:

`78d004ff0f3cab226ef2190244a3f59675337adcbd7c445fa98a343964ba86b0`

| Property | Observed value |
|---|---:|
| Vertices n | 82,140 |
| Directed CSR nonzeros | 997,064 |
| Undirected root edges | 498,532 |
| Positive root edges | 380,933 |
| Negative root edges / legal flips | 117,599 |
| Root nonedges / legal insertions | 3,372,950,198 |
| Legal candidates M | 3,373,067,797 |
| Maximum canonical ID `(n-2)*n+(n-1)` | 6,746,897,459 |
| Maximum unweighted degree | 2,548 |
| CSR array payload | 5,313,884 bytes |

The matrix is a square, symmetric, canonical CSR, has zero diagonal, and contains only nonzero int8 values -1 and +1. The last vertex pair is a nonedge, so the maximum triangular code is a legal insertion. The stored `indices` and `indptr` are int32; the two-element `shape` array is int64. These sparse index widths are sufficient: neither vertex numbers nor the graph's stored-entry offsets approach 2**31. They are different quantities from candidate IDs and candidate ordinals.

This is the archived undirected, signed, unit-magnitude projection. It must not be described as a newly downloaded graph or as a natural-rating projection with unobserved weights. V2 uses the frozen archive directly.

## 2. Canonical IDs, ranks, counts, and serialization

### Safe A2 paths

The public ID is `e=i*n+j`, with `0 <= i < j < n`. The following inspected paths preserve it above both signed-int32 and unsigned-int32 limits.

| Path | Width and behavior | Source |
|---|---|---|
| Sparse root-edge keys | `upper.row.astype(np.int64) * n + upper.col.astype(np.int64)` promotes before multiplication | `src/a2_catalog.py:80–106`, especially 95 |
| Integer input validation | Rejects noninteger arrays and unsigned values above signed-int64 before conversion | `src/a2_catalog.py:20–50` |
| Candidate scalar lookup | Python integer validation and `divmod`; endpoint/weight results are int64 | `src/a2_catalog.py:137–151` |
| Bounded Stream ID generation | Python integer row offset plus int64 `arange`; int64 buffer | `src/a2_catalog.py:156–205`, especially 174–179 |
| Dense ordinal calculation | int64 arithmetic; output switches to int64 at M>=2**31 | `src/a2_catalog.py:225–233` |
| H heap entries | Endpoint positions converted to Python `int` before multiplication; Python integer caps avoid int64 overflow | `src/a2_catalog.py:329–336` |
| H output batch | Canonical IDs converted to int64 at the bounded output boundary | `src/a2_catalog.py:395–419` |
| Explicit seeds and query output | int64 promotion occurs before `i*n+j` | `src/a2_access.py:73`, `156` |
| A2 strict screening | Canonical IDs decoded through catalog; outputs int64; large fine-grid upper bounds use Python integers/object arrays | `src/a2_numeric.py:65–103` |
| Decisions, tie witnesses, caches | Python integer IDs and dictionary/set keys; witnesses explicitly serialize `int(source/target)` | `src/a2_session.py:98–125,182–218`; `src/exact_ties.py:23–44,94–99` |
| Independent checker | Python integer decode; int64 bounded output buffers and row arithmetic; little-endian `<i8` candidate hashes | `src/a2_checker.py:263–297,299–354,465,504` |

Candidate cardinality, stream counters, heap counters, count accumulations, and `live_catalog_denominator` use Python integers or explicitly converted integer reductions. For example, fifteen full-domain denominators can exceed 50 billion, but `src/a2_session.py:161,234` does not put them in int32. D's incidence offsets are explicitly int64 at `src/a2_access.py:41–45`; `legacy/universe_index.py:44–47` also switches the incidence ID vector to int64 when M reaches 2**31.

JSON output uses Python integer values; NumPy generics are converted with `.item()` by the legacy JSON helper (`diagnostic/common.py:21–27`). `tolist()`, dictionary/set membership, and independent `<i8` hashes do not truncate the tested IDs. The maximum Slashdot candidate ID is also below 2**53, so it can be represented exactly by a JavaScript Number, although fine-grid score numerators can be much larger and should continue to be interpreted with Python/exact-integer tools. No claimed score identity should rely on converting those score integers to binary64.

### Limits intentionally retained

`Access.__init__` rejects `M >= 2**31` before D materialization (`src/a2_access.py:30–35`). That is a real explicit-index limitation, not a canonical-ID limitation:

- Weight-group member ordinals are serialized as int32 and reconstructed as int32 (`src/weighted_adapter.py:192,200`).
- The explicit index's exclusion set becomes an int32 array (`src/weighted_adapter.py:252`).
- The standalone explicit `Strict.screen/scan` path uses int32 ordinals (`src/weighted_adapter.py:142,169,172`). A2's service uses `CachedStrict` instead, but a general explicit ordinal migration must cover these methods as well.
- Dormant native legacy index and screen APIs use int32 candidate ordinals/counts. See the native section below.

Therefore **do not remove the D M guard alone**. A future compatible width migration would retain int32 vertex endpoints (n fits) but consistently widen candidate ordinals and all associated member/exclusion/output buffers. It would not make D admissible under the present memory cap.

### Input-boundary observation, not an engine failure

The catalog's own public validator rejects fractional float IDs, but `EndpointColumn.__getitem__` performs `int(key)` on scalar input and `np.asarray(...,dtype=np.int64)` on vector input first (`src/a2_numeric.py:17–23`). `CachedStrict.screen` similarly coerces a supplied ID array (`65–67`). Thus an external caller can supply a fractional float that is truncated before catalog validation. The boundary test documents this behavior.

The inspected A2 execution path supplies validated engine-owned integer IDs, so this is not an observed correctness failure for the frozen runs and does not require a numerical or access-policy change. If these adapters become public untrusted-input APIs, pass the original value into `catalog.scalar/batch` and let the strict catalog validator reject it before coercion. Do not alter the frozen study after outcomes merely to make this optional hardening change.

## 3. Allocation audit

### H and Stream do not create an obligatory M-sized array

`AllCatalog` owns sparse root CSR arrays, O(root_edges) identity arrays and a Python root-edge membership set (`src/a2_catalog.py:85–110`). Its candidate domain is implicit. The virtual endpoint and weight columns deliberately reject slicing, conversion to a whole array, and iteration (`src/a2_numeric.py:13–49`).

H's `MixedFrontier` owns one integer center vector, one node order, at most n-1 insertion heap heads, and a sparse negative-edge order (`src/a2_catalog.py:284–327`). It does not retain an all-emitted history (`395–419,421–444`). A child version rebuilds this state; root edges, committed edits, and actual processed candidates are rejected through sparse or caller-owned sets.

Stream uses candidate chunks of 65,536 rows (`src/a2_access.py:132`; `src/a2_catalog.py:156–205`). Its preparation pays for the same sparse joint frontier to select the common 64 seeds, then releases that frontier and retains only its counters (`src/a2_access.py:81–97`). Its per-version exclusion vector is proportional to the actual warm/chosen set, not the full domain.

No reachable H/Stream allocation uses shape M or n*n. However, **absence of a predetermined M-sized access array is not a universal constant-memory guarantee**:

- `hot`, `seen`, and the Gram dictionary grow with candidates actually scored (`src/a2_session.py:75–77,98–125`). In a worst case that set can itself approach M.
- `evaluated` is a per-version dictionary of scored candidate bounds.
- `hot|chosen` creates temporary unions when the source is opened and queried; Stream copies/sorts the initial excluded IDs.
- Child sparse operators, state/residual vectors, one- or two-column responses, sparse-factor fill, logs, and sorting workspace also consume memory.

The existing reports correctly label the candidate caches as actual evaluated-candidate storage (`src/a2_session.py:253–260`). Avoid a paper statement that total H memory is always O(n+root_edges) independently of the refinement set.

### D obligatory payload from the actual representation

For Slashdot M=3,373,067,797, the following are array payloads, not Python object headers, factor storage, or measured peak RSS. These are calculated without creating any M-sized array.

| Structure | Dtype/length in source | Payload bytes | GiB |
|---|---|---:|---:|
| Left and right endpoint arrays | 2 × int32[M] | 26,984,542,376 | 25.131313 |
| Flip/kind array | bool[M] | 3,373,067,797 | 3.141414 |
| Effective edit coefficients | int64[M] | 26,984,542,376 | 25.131313 |
| **Pool plus weights, obligatory before index work** | **17M bytes** | **57,342,152,549** | **53.404041** |
| Weight members as written, unsafe at this M | int32 ordinals, total M | 13,492,271,188 | 12.565657 |
| Incidence candidate IDs | int64[M] at this M | 26,984,542,376 | 25.131313 |
| Incidence left/right offsets plus degree | 2 × int64[n+1] + int64[n] | 1,971,376 | 0.001836 |
| Sorted root-cap keys | int64, total M | 26,984,542,376 | 25.131313 |
| Sorted candidate ordinals as written, unsafe | int32, total M | 13,492,271,188 | 12.565657 |
| Temporary full root-cap array | int64[M] | 26,984,542,376 | 25.131313 |
| Per-request root-center copy | int64[n] | 657,120 | 0.000612 |

Sources: explicit pool allocation `src/a2_catalog.py:207–223`; weight array `src/weighted_adapter.py:268–278`; immutable group backing and members `179–204,281–287`; incidence `legacy/universe_index.py:43–47`; sorted key/ID arrays `src/weighted_adapter.py:214–234`; root caps and root-center copy `src/a2_access.py:61–77`.

The listed persistent payload with the current *unsafe* int32 members/sorted ordinals would be `41M+24n+16 = 138,297,751,053 bytes` before the root-center copy. This is not a runnable alternative: current code correctly refuses it.

If candidate ordinals were consistently widened to int64, the listed persistent lower bound would be `49M+24n+16 = 165,282,293,429 bytes = 153.931131 GiB`, or **165,282,950,549 bytes** including the dedicated root-center vector. Keeping the full root-cap array live during index construction raises that listed lower bound by another **25.131313 GiB**. Full-key sorting, `np.partition`, temporary endpoint gathers, immutable `tobytes()` copies of pool and weights, `np.unique`/concatenation in queries, and the graph/factor can increase peak memory further.

The 17M lower bound is already decisive and uses only arrays that the existing implementation must allocate. It is appropriately a representation-specific bound, not an information-theoretic lower bound or a measured D timeout.

### Memory reporting cautions

`Access.memory()` reports explicit persistent arrays plus maximum observed frontier/batch payloads (`src/a2_access.py:194–214`). It excludes temporary sorting/deduplication/strict/solver work by design. The session explicitly sets `root_factor_resident_bytes=None` and reports only `base.nnz` (`src/a2_session.py:252,257`). Treat factor nnz as an entry-count diagnostic, not resident bytes.

The `graph_csr` field and the `sparse_catalog` field overlap: the catalog owns the same W CSR. Do not add them as if they were disjoint allocations. Likewise, per-component observed maxima are not a synchronized process peak. The external RSS measurement and hard address-space limit have distinct meanings.

## 4. Solve backend, reuse, and dense-operation reachability

`src/common.py:12–16` executes the diagnostic import bootstrap; `diagnostic/common.py:7–10` puts the evidence supplement's copied legacy tools first on `sys.path`. The active backend therefore comes from that copied `legacy/long_promotion.py`, not from whichever similarly named tool appears elsewhere in the archive.

The actual path is:

1. `A2Session` builds the scaled integer sparse operator through `EndpointKernel`/`Kernel.operator` (`src/a2_session.py:56–62`; `src/weighted_adapter.py:289–293`).
2. `lp.UpdatedFactor` performs `splu(A.astype(float).tocsc())` once (`legacy/long_promotion.py:117–121`). No method, graph-size, or backend selection is present here.
3. Every request shallow-copies that factor wrapper, shares its immutable SuperLU base, and installs an empty private update list (`src/a2_session.py:73–77`). It starts a new Gram store and has no answer cache.
4. A solve calls the retained base and applies the accumulated low-rank corrections (`legacy/long_promotion.py:123–127`). Accepted edits append an n×1 or n×2 response and a 1×1 or 2×2 inverse (`src/weighted_adapter.py:93–111`).
5. Request close releases request views, factor wrapper, child operator, and state (`src/a2_session.py:262–264`); the structural root persists for the next opinion.

The separate `Iterative` class with Jacobi-preconditioned CG exists at `legacy/long_promotion.py:28–53`, but A2 never selects it. The archive also contains CHOLMOD, paired-PCG, direct residual, and symbolic-analysis tools. Their presence does not make them the active A2 backend. Switching to any of them would exceed the allowed integer/input/metering compatibility change.

Dense-operation findings are bounded or unreachable:

- `np.linalg.inv` at `src/weighted_adapter.py:108` is a one- or two-dimensional edit pivot, not an n×n inverse.
- The exact rational `A.toarray().inv()` fallback is gated by `A.shape[0] <= 16` at `src/weighted_adapter.py:351–360`; on a larger unresolved contest the code raises instead.
- The independent A2 checker permits exact reference inversion only for n<=12 (`src/a2_checker.py:257–259,455–485`). Its larger-case `response` is separate checker-only Jacobi-CG (`src/checker.py:88–93`), not the production solve.
- Dense complete-pool and brute-force inverse routines in `legacy/promotion.py:598–608,611–674`, and the dense small fixture in `src/a2_preflight.py:20`, are not invoked by A2Session or the V2 runner. They must not be substituted for scale validation.
- There is no reachable full `eye(n)`/`identity(n)` solve or n×n inverse construction in the audited A2 service path. Sparse diagonal construction is O(n).

For the frozen Slashdot graph, the root operator's maximum diagonal is 40,784; fifteen insertion updates can increase it to at most 40,799. The exact-state infinity bound |z|<=1/16 implies an indicative fine-grid magnitude <=2**44. Substituting that into the existing residual-range expression gives approximately 1.435×10**18, below 2**63. This supports the absence of an inherent arithmetic-size obstruction at n=82140. It does not replace the runtime checks on the actual rounded solve: those remain unchanged at `legacy/long_promotion.py:167–185` and `src/weighted_adapter.py:64–69,134–139`.

Sparse LU fill and solve/refinement cost remain unknown until the bounded attempt. A cap failure is an experimental result; it does not authorize changing the solver, tolerance, precision, or seed.

## 5. Native interfaces and dependencies

The only shared libraries shipped in the archived baseline tree are:

| File | SHA-256 |
|---|---|
| `diagnostic/build/screen.so` | `65f6419fcba0ea1939471d913d3980509487f911136b38fbff85e4e463d0b15c` |
| `diagnostic/build/index.so` | `e522c80ab1655731c1c68c4a0dc8e3a76921eeb1a7d9141876137d28b45b59a0` |

Both are ELF64 x86-64 shared objects with no dynamic-library dependencies reported by `ldd`. The A2 source-freeze procedure hashes them, but A2Session does not call `legacy.native()`. That loader belongs to the separate older `Session` constructor (`src/session.py:135`). A2 D uses the Python weighted index, and A2 H/S use `CachedStrict`, so canonical IDs do not cross these native candidate APIs in the audited service path.

The dormant native interfaces have genuine 32-bit ordinal restrictions:

- `promotion_screen.c:10–24,34–89`: signed-int32 begin/end, candidate IDs, counts and visited fields.
- `promotion_index_profile.c:13–43,101–115`: signed-int32 M/order/output/count and loops; although incidence offsets are int64, loop starts are cast to int32.
- Python bindings match these types (`diagnostic/common.py:55–63`; `legacy/promotion_index_profile.py:28–38`; `legacy/promotion_strict.py:75–78`). Their constructors explicitly reject M>=2**31.
- Native legacy stamped deduplication allocates `uint8[M]` (`legacy/promotion_index_profile.py:87,93,150`). This is not reached by A2 H/S or A2's weighted D index; it must not be cited as a hidden H allocation.

No native candidate rewrite is needed for the admitted H/S path. If a future study enables a native explicit path for M>=2**31, widening only Python arrays is insufficient: the C signatures, loop indices, counts, ctypes declarations, output arrays and dedup indexing must change together and receive a new freeze.

The active binary numeric dependency is SciPy's SuperLU extension plus its bundled BLAS/runtime libraries. In the inspected environment the extension was:

`_superlu.cpython-312-x86_64-linux-gnu.so`, SHA-256 `8bc863fc723ee3bc4d603bf2cdf540fa728ce5df35302686588f0ee926dae261`.

It links to SciPy's OpenBLAS, libc/libm, libpthread, libgfortran, libquadmath, libgcc and libz. NumPy and SciPy have distinct bundled OpenBLAS libraries; both reported OpenBLAS 0.3.30 in the import-only inventory. V2's environment and actual worker threadpool reports should remain the authoritative run records.

### Reproduction and build instructions

Use the top-level `requirements-research.txt`, not the older copied `legacy_v6/requirements.txt`, for this A2/V2 runtime. The inspected runtime pins are Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0, psutil 7.2.2, threadpoolctl 3.6.0 and SymPy 1.14.0; matplotlib 3.10.8 is needed for the reporting environment, not candidate selection.

In an isolated reproduction checkout, dependencies may be installed with:

```sh
python -m pip install -r requirements-research.txt
```

The historical native build record uses the following commands, with paths resolved inside that checkout:

```sh
gcc -O3 -fPIC -shared baseline_r15/experimental_records/evidence_supplement_20261124/source/legacy_v6/tools/promotion_screen.c -o baseline_r15/experimental_records/evidence_supplement_20261124/diagnostic/build/screen.so
gcc -O3 -fPIC -shared baseline_r15/experimental_records/evidence_supplement_20261124/source/legacy_v6/tools/promotion_index_profile.c -o baseline_r15/experimental_records/evidence_supplement_20261124/diagnostic/build/index.so
```

Do not rebuild the immutable historical binaries in place. A compiler/toolchain change can change their hashes even with identical source; finish any required rebuild before a new source/native freeze and record the resulting identities. CHOLMOD headers/libraries, `JCERT_CHOLMOD_LIB`, and `JCERT_SCALE_SYMBOLIC` are unnecessary for the audited A2 path and should not be introduced as a solver replacement.

Set `OPENBLAS_NUM_THREADS=1`, `OMP_NUM_THREADS=1`, `MKL_NUM_THREADS=1`, and `NUMEXPR_NUM_THREADS=1` before numerical imports and retain `threadpool_limits(1)` around the worker's numerical work. The V2 runner does both. The tiny audit command, if reproduced outside measured work, is `python runtime_audit/boundary_audit.py`; it is not a benchmark command.

## 6. V2 harness review and resolution record

The root requested a separate pre-freeze review of `src/v2_runner.py`. Findings were sent immediately, before the unseen draw. The final reviewed source is commit 4c2c7b7.

| Finding in the initial draft | Resolution observed in frozen candidate |
|---|---|
| Manifest loader did not verify CODE_FREEZE/SEED_DRAW identities, environment or the exact job roster | V2 `v2_runner.py:233–253` verifies protocol hashes, named freezes, roster equality, environment, source map, fixture grid, deterministic seed derivation and shape; `221–224` binds the roster hash |
| Worker job fields could allow unregistered count/cap combinations, including an empty request loop | `81–100` validates stage, graph, method, repeats, budget, requests and cap values; worker validates before execution at `259` |
| Worker could observe a different manifest than its supervisor | `376` passes a frozen manifest hash and `276` checks it |
| Caught SuperLU allocation errors could be mislabeled as certificate/runtime errors | Common `memory_failure` at `75–78`, used for request failures `351–352`, worker exceptions `363–367`, and process stderr `399–402` |
| B1 frontier phase ledger was unfinished and included an earlier state interval in its elapsed boundary | Fresh ledger immediately around `access.begin`, followed by `finish()`, at `333–338` |
| H Q1 failure omitted explicit S Q1 and per-repeat B3 skip records | All affected stage/method/repeat skip rows now recorded at `439–455` |

The existing `load_fixture` interface is compatible with V2 records: file paths are relative to V2, and `npz_sha256`, `shape`, `matrix_sha256`, and `opinion_hashes` are supplied. The existing reader checks exact members `['opinions']`, little-endian int64 shape/range/contiguity, full-matrix hash, and each row hash (`src/access_bench.py:135–157`).

Hard `RLIMIT_AS` and the core-dump restriction are applied before numerical imports (`V2 src/v2_runner.py:256–282`). Worker CPU0 and supervisor CPU8 are fixed. RSS and VMS are sampled independently (`387–395`). **The 2/4 GiB policy is an address-space limit, not a promise that RSS reaches that value.** Library mappings and allocator reservations also consume the limited address space. A timeout has no complete-service duration (`398–407`); stopped or unadmitted stages are not treated as completed performance observations.

The metering class preserves `super().__init__(A)` and `super().solve(rhs)` (`294–307`). It adds a factor-attempt timer, solve-call count, scalar-RHS count and elapsed solve time. Shallow request copies retain the same SuperLU base and the same metering closure. The timed solve includes the original low-rank correction loop; it is not a pure triangular-solve-only timer. Checkpoint I/O introduced inside factor construction is part of the instrumented structural wall, while `factor_attempt_seconds` measures the actual constructor body. Interpret these fields accordingly.

The runner freezes code and preregistration before its one `secrets.token_hex(32)` draw, then uses SHA-256-derived per-cell seeds and verifies independent input regeneration (`prepare`, V2 lines 144–229). The seven streams are six small graph/family cells plus one Slashdot independent stream. The six small streams provide 24 correlated requests; repetitions are timing repetitions of the same frozen input, not additional independent input samples.

Independent replay and final scientific aggregation are root-owned subsequent work. This audit does not claim that selecting replay rows establishes their successful verification, that a complete request exists on Slashdot, or that any runtime/performance outcome has yet been observed.

## 7. Verification performed and remaining limits

`boundary_audit.py` completed successfully and checked:

- Root-edge promotion before multiplication at IDs 2,147,576,446; 4,295,070,750; and 6,746,897,459.
- int64 candidate batches, scalar endpoint decoding, rank values above 2**31, and rejection of values outside signed-int64/domain constraints.
- Bounded Stream generation, the exact final-row arithmetic expression, and Python-integer heap caps above int64.
- Independent checker decoding of the maximum ID and bounded first-block generation.
- A2 strict screening of a maximum-ID candidate using an exactly representable diagonal-system state, with no solve.
- Catalog fail-closed n/M guards before any factorization or M-sized allocation.
- JSON round-trip, set deduplication and `<i8` byte hashing above uint32.

The audit separately verified the dataset archive and reachable module/native identities. It did not run the legacy dense experiments, native rebuilds, complete-catalog traversal, performance cohorts, a full independent replay, or a scale factorization. The root reported 117 targeted tests passing, including nine V2 tests and a tiny real direct-service/profile worker under the 2 GiB hard cap; this report attributes that validation to the root rather than presenting it as independently rerun here.

The appropriate final scientific claims must depend on the retained worker results and independent checker records. Static compatibility and passing narrow width tests establish that the bounded attempt can be made without silently narrowing canonical IDs; they do not establish successful scale service or a speed advantage.
