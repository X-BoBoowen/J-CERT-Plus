"""Tiny path-only regression: no validator import, inputs, raw reads or hashes."""
import ast
from pathlib import Path
import tempfile
import unittest


HERE = Path(__file__).resolve().parent
ARCHIVE = 'J_CERT_Plus_A2_Exact_Tie_Revision_20261125'
tree = ast.parse((HERE/'v2_validate.py').read_text())
function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'inside')
namespace = {'Path': Path}
exec(compile(ast.Module(body=[function], type_ignores=[]), '<path-guard-only>', 'exec'), namespace)
inside = namespace['inside']


class PathGuardTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='path_guard_', dir=HERE)
        self.base = Path(self.temp.name)
        self.root = self.base/'runtime'
        self.root.mkdir()
        (self.root/'src').mkdir()
        (self.root/'src/file.py').touch()
        self.original = self.base/'original'/ARCHIVE
        for name in ('data', 'baseline_r15'):
            target = self.original/name
            target.mkdir(parents=True)
            (target/'item.txt').touch()
            (self.root/name).symlink_to(target, target_is_directory=True)
        self.outside = self.base/'unapproved'
        self.outside.mkdir()
        (self.outside/'item.txt').touch()

    def tearDown(self):
        self.temp.cleanup()

    def test_supplied_data_alias_is_allowed(self):
        self.assertEqual(inside(self.root, 'data/item.txt'), self.original/'data/item.txt')

    def test_supplied_baseline_alias_is_allowed(self):
        self.assertEqual(inside(self.root, 'baseline_r15/item.txt'), self.original/'baseline_r15/item.txt')

    def test_regular_extracted_directories_are_allowed(self):
        (self.root/'data').unlink()
        (self.root/'data').mkdir()
        (self.root/'data/item.txt').touch()
        self.assertEqual(inside(self.root, 'data/item.txt'), self.root/'data/item.txt')
        self.assertEqual(inside(self.root, 'src/file.py'), self.root/'src/file.py')

    def test_parent_traversal_is_rejected_even_if_final_path_is_internal(self):
        with self.assertRaises(ValueError):
            inside(self.root, 'src/../src/file.py')

    def test_absolute_path_is_rejected_even_if_internal(self):
        with self.assertRaises(ValueError):
            inside(self.root, self.root/'src/file.py')

    def test_unrecognized_external_alias_is_rejected(self):
        (self.root/'other').symlink_to(self.original/'data', target_is_directory=True)
        with self.assertRaises(ValueError):
            inside(self.root, 'other/item.txt')

    def test_named_alias_with_wrong_target_is_rejected(self):
        (self.root/'data').unlink()
        (self.root/'data').symlink_to(self.outside, target_is_directory=True)
        with self.assertRaises(ValueError):
            inside(self.root, 'data/item.txt')

    def test_named_alias_to_deeper_target_is_rejected(self):
        deeper = self.original/'data/deeper'
        deeper.mkdir()
        (deeper/'item.txt').touch()
        (self.root/'data').unlink()
        (self.root/'data').symlink_to(deeper, target_is_directory=True)
        with self.assertRaises(ValueError):
            inside(self.root, 'data/item.txt')

    def test_nested_symlink_escape_from_allowed_alias_is_rejected(self):
        (self.original/'data/escape').symlink_to(self.outside, target_is_directory=True)
        with self.assertRaises(ValueError):
            inside(self.root, 'data/escape/item.txt')

    def test_redirected_expected_source_directory_is_rejected(self):
        (self.original/'data/item.txt').unlink()
        (self.original/'data').rmdir()
        (self.original/'data').symlink_to(self.outside, target_is_directory=True)
        with self.assertRaises(ValueError):
            inside(self.root, 'data/item.txt')

    def test_different_alias_cannot_enter_approved_source(self):
        (self.root/'src/redirect').symlink_to(self.original/'data', target_is_directory=True)
        with self.assertRaises(ValueError):
            inside(self.root, 'src/redirect/item.txt')


if __name__ == '__main__':
    unittest.main(verbosity=2)
