J-CERT+ V2 post-measurement validation — 2026-11-26

Prepared for the frozen source boundary
4c2c7b7e84c7c03ee56d45453fea6950c94817bd.

VALIDATION STATUS — COMPLETED AFTER MEASUREMENT
The validator was prepared while batch A was timing, using only source and
frozen-protocol inspection. Actual aggregation and structural verification ran
after the root released timing. The root then ran the two selected numerical
checks separately. No algorithm measurement was rerun for validation.

Final a_aggregate.json is accounting_verified: all 54 raw workers and 216 request
executions are retained; 45 workers have complete Q4 service, 207 requests reach
budget_stop, and nine Alpha/signed-neighbor/q1 executions remain unresolved
after three accepted edits. Total accepted decisions are 3132. The five wholly
completed cells provide 15 of 18 planned paired repeats: D=211.01984770500349 s,
S=787.4625900870051 s, H=55.62411935000091 s, yielding D/H=3.7936753007668074
and S/H=14.156854963079828. These are complete matched-subset ratios; the sixth
cell remains visible with unavailable complete-Q4 costs.

All 24 distinct opinion rows have identical accepted winner/edit/version
sequences across their nine method/repeat exposures. Terminal statuses and
accepted sequence lengths also agree. Of 12528 shared accepted-decision
pairwise interval comparisons, 12492 have exactly equal endpoints and 36 differ
(72 individual endpoint differences). Those differences are disclosed and do
not alone imply incorrect intervals.

a_parent_witness.json is verified_with_preserved_partial_or_unsupported_cases:
all 216 parent chains and 3141 recorded parents were reconstructed; all 54
actual witness observations, representing six exact relations, were verified;
all 45 comparison-resolution metadata records were verified. No witness was
unprocessed or invalid. The 18 unsupported entries are nine unresolved overlap
records plus nine terminal failure entries for the same nine failed requests.

Both prespecified full-catalog reports are full_selected_request_verified:
  Alpha H/r0/independent/q1: 15 accepted decisions, 107113155 checked candidate
  decision rows, 48 independent RHS; wrapper checker wall 6.211483897001017 s
  (internal checker_seconds 6.157847882001079 s).
  OTC H/r0/independent/q1: 15 accepted decisions, 259077780 checked candidate
  decision rows, 44 independent RHS; wrapper checker wall 13.064212393001071 s
  (internal checker_seconds 13.012066418999893 s).
These two numerical checks do not extend full-catalog optimality verification
to every request. Published large-graph intervals retain the intersection-only
scope described below. Every final A report records no changed input hashes.

The final reporting-wrapper SHA-256, shared by all four final A reports, is
fea934ec1661054e729a044c2a51cd749a1a6178b97fc6b09884f1827d814908.

PRESERVED REPORTING ERRORS AND FIXES
Two wrapper schema bugs occurred before final reporting and are preserved:
  a_aggregate_attempt01_error.json: duplicate requests keyword when expanding
  the frozen job's integer request count and adding the analyzed request list.
  a_aggregate_attempt02_schema_gap.json, with its companion cells/requests CSV:
  the wrapper compared job.requests=4 against raw.requests, which the frozen
  runner intentionally initializes as a list of recorded requests. This caused
  54 artificial binding errors; the attempt had no timing/phase accounting
  errors. It must not be used as the final experimental outcome.
The wrapper now stores planned_requests separately and validates the exact job
file, actual request count/order, completion and unchanged full-service/phase
reconciliations. Frozen runtime, checkers, raw records, seeds and protocol were
not changed. wrapper_fix_provenance.json records error-output hashes and wrapper
hashes before/after both fixes. These were reporting reruns, not algorithm runs.

Before those attempts, source-only review also corrected the guard to accept
only the two authorized attachment source aliases while preserving traversal
and symlink-escape rejection; the tiny path-only regression passed 11 cases.
That regression imports neither the validator nor numerical/experiment code.

B bookkeeping is complete in b_bookkeeping.json and b_bookkeeping_zh.txt:
the root profile timed out at 600.1059425960011 s before any query, and all eight
followup stage slots remain not_run_gate_failed. The source/raw declarations
and preflight arithmetic are verified, with no changed input files. This is
read-only accounting, without a scale numerical replay. The separate B report
distinguishes the 4 GiB virtual-address-space cap, last-checkpoint self-reported
RSS and externally sampled RSS/VMS. D was not started by its representation
preflight; it is not labeled an observed execution OOM.

EXECUTED COMMANDS
The following used the frozen Python interpreter after timing ended. Outputs
are exclusive creates; existing final evidence is not overwritten:

/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -B /workspace/scratch/faa1a8a62f06/validation/v2_validate.py aggregate

/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -B /workspace/scratch/faa1a8a62f06/validation/v2_validate.py chains

Root controls each selected numerical check separately; do not run the two
commands concurrently with each other or any algorithm measurement:

/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -B /workspace/scratch/faa1a8a62f06/validation/v2_validate.py full-catalog --sample Alpha --max-seconds 1800

/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -B /workspace/scratch/faa1a8a62f06/validation/v2_validate.py full-catalog --sample OTC --max-seconds 1800

All modes acquire the existing runtime/logs/.measurement.lock, nonblocking and
read-only, before freeze hashing or raw reads. A held lock means the command
refuses to start. Every output is an exclusive create under validation/.
No mode starts a benchmark, regenerates inputs, changes seeds, modifies source,
replaces a selected sample or overwrites prior validation evidence.

MODES AND EXPECTED OUTPUTS

aggregate:
  a_aggregate.json
  a_aggregate_cells.csv
  a_aggregate_requests.csv

Reads all 54 registered slots and keeps every status, including not-started,
timeout, memory failure, runtime/certificate error and unresolved. Denominators
are six seeded streams, 24 distinct opinion rows, three methods, three repeats,
54 planned workers, 216 planned request executions, and at most 3240 accepted
decisions. Requests in one stream can be correlated; repeated methods/timings
do not add independent inputs.

Full Q4 worker costs require a bound complete worker, all four completed
requests, finite positive complete_service_seconds, and reconciled exclusive
phases. Worker cost is graph/setup plus the four request walls. Unresolved
workers retain their recorded partial-work time but are excluded from complete
Q4 comparisons. Their later completed requests are still shown individually.

Primary cell medians and ranges require all three completed repeats. Available
completed-service distributions also retain their explicit reduced count.
Paired speedups are ratios of cost sums over WHOLE matched three-repeat input
cells. For H/D or H/S both methods must complete all repeats of an included
cell; the faster-reference comparison requires all D/S/H repeats. The report
lists excluded cells, planned and included pairs, finite positive denominators
and selected reference counts. No speed threshold is applied. Sums of actual
partial work across all slots are separate, labeled partial workload, and must
not be interpreted as complete-Q4 speedups.

All nine method/repeat exposures are compared for each of the 24 opinion rows,
using all 36 unordered exposure pairs (864 planned comparisons). Shared
accepted prefixes compare epoch, candidate ID, root/parent/child version IDs,
edit fields and integer interval endpoints. Terminal status, prefix length,
all-recorded-decision projection, missing records and empty prefixes are
reported separately. An equal empty sequence is not positive evidence of
correct decisions. Different interval endpoints are disclosed separately from
winner/version disagreements and are not automatically called an invalid
numerical certificate.

Shared accepted winner/edit/version disagreements are flagged as deterministic
identity disagreements. Exact low/high endpoint match counts have their own
denominator. Different valid enclosures can arise from access-history or Gram
refresh differences; an endpoint difference alone is not a scientific
correctness failure. A common unresolved terminal is recorded agreement on an
unsuccessful outcome, not successful numerical completion.

RSS is process-lifetime high-water bytes, not an additive memory decomposition.
External sampled RSS remains separate. Numeric work, emissions, warm/cold
screen rows, heap pops, Gram materializations, responses and exclusive phases
remain separate counters. solve_seconds/factor diagnostics can overlap phases
and are not added to service totals.

chains:
  a_parent_witness.json

Loads the frozen exact graph and int64 opinion files and validates their
dimensions, layout and matrix/row digests. It calls the UNMODIFIED
src.a2_tie_verify_retest.inspect_request, which calls the UNMODIFIED
src.a2_checker._TieProofs. The wrapper supplies seed_label="V2" solely as a
location label; the actual recorded requests, decisions and witnesses are
passed unchanged.

The checks reconstruct current parents and legal edits, parent/child version
chains and each actually declared transposition witness. Raw witness counts,
processed counts and verified counts are all retained, so malformed or
unprocessed declarations cannot disappear from the denominator. Unresolved
terminal rows and accepted prefixes remain present, including unsupported
weighted overlaps. A structurally verified unresolved request remains an
unresolved algorithm outcome.

Positive low/high morphology and gain-total equality are checks of the reported
integer data. This mode does NOT independently re-prove numerical positive gain,
all-catalog optimality, or every published bound. The numerical full-catalog
scope is confined to the two explicit sample commands below.

The actual A2 policy remains the frozen binary64 solve and literal precision
configuration: operator scale 16, score proof unit 2^48, screen unit 2^20,
opinion denominator 65536, and current-parent exact single-transposition checks.
Unsupported overlaps remain unresolved under that policy. This validation does
not imply that A2 inherits the historical planner's adaptive Gram-refinement
ladder or expands its decision/refinement policy.

full-catalog --sample Alpha / OTC:
  a_full_catalog_Alpha.json / a_full_catalog_OTC.json

The ONLY permitted selection for each graph is frozen in PROTOCOL.json:
method H, repeat 0, stream independent, query position 1. There is no replacement
on failure and no trimming of an unresolved request to its accepted prefix.
The wrapper calls src.a2_checker.replay_file with the original raw worker file,
exact graph file and exact fixture file, request=1.

If the unchanged checker accepts the full terminal outcome, it can certify the
whole selected request. If it returns an unresolved termination, only the
accepted decisions explicitly certified in decision_checks are claimed; the
terminal decision remains uncertified. If it rejects a runtime/error terminal,
the wrapper records that error without retry, trimming or substitution. A
timeout similarly preserves the attempt without claiming unreturned partial
proof work. Large-graph published intervals are checked for intersection with
independent intervals; this is not full interval enclosure.

--max-seconds controls an operational validation timeout and is stored in the
report. It is not an algorithm completion/speed gate and is not included in
algorithm timings. The default and shown commands use 1800 seconds. The
checker uses one numerical thread, CPU 0 and the frozen small-worker 2 GiB
RLIMIT_AS; its wall/CPU/RSS are reported separately.

FREEZE AND PROVENANCE

The validator pins exact PROTOCOL, INPUTS, CODE_FREEZE, SEED_DRAW and A_JOBS
bytes, checks the current runtime Git HEAD against 4c2c7b7, hashes every frozen
runtime/checker/source/native object, checks graph/fixture byte bindings and
seed derivation/collision handling, and verifies the interpreter/package
environment. Raw/job/scheduler/input/source bindings are checked for each
present worker. If a process failed before saving all bindings, the raw failure
is retained and its unbound decisions are not claimed verified.

Path handling rejects absolute input paths and every lexical parent traversal.
Ordinary extracted source directories must resolve beneath runtime/. In this
workspace only runtime/data and runtime/baseline_r15 may instead be read-only
symlinks to the exact corresponding tree under
original/J_CERT_Plus_A2_Exact_Tie_Revision_20261125/. Both the alias target and
the final descendant are checked. Other external aliases, changed alias
targets, redirected source trees and nested symlink escapes are rejected.
No external raw-result alias is admitted. validation/test_path_guard.py tests
this path boundary without importing the validator or reading experiment data.

Every input observed is hashed again at completion. Current-source or frozen
identity failures produce a saved validation error; they are not bypassed.
All outputs include the validator hash and actual validation UTC timestamp.
The study/report date remains 2026-11-26; host wall-clock timestamps are retained
as observed. All previous original audit files are unchanged by this workflow.
