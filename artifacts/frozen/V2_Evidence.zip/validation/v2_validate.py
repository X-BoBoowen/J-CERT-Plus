#!/usr/bin/env python3
"""Post-measurement V2 validation, dated 2026-11-26.

Prepared separately from the frozen execution runtime. Each mode acquires the
runner's existing measurement lock before reading raw results. The aggregation
mode performs no numerical solve. The chains mode reuses the frozen,
unmodified structural checker. Full-catalog verification is an explicit,
one-sample command and never substitutes or trims the selected request.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from contextlib import contextmanager
import csv
from datetime import datetime, timezone
from decimal import Decimal
import fcntl
import hashlib
from importlib import metadata
from itertools import combinations, product
import json
import math
import os
from pathlib import Path
import platform
import resource
import signal
import statistics
import subprocess
import sys
from time import perf_counter, process_time
import traceback

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
DEFAULT_RUNTIME = HERE.parent / 'runtime'
DOCUMENT_DATE = '2026-11-26'
FROZEN_COMMIT = '4c2c7b7e84c7c03ee56d45453fea6950c94817bd'
PINS = {
    'PROTOCOL.json': 'b846b2a8eec9805e8fa9dc788eae8b146463cc9c18636da935a7716e9674b810',
    'INPUTS.json': 'ef1e835f6d97a50fb0cc50ab42defefa20b10a6f23fd70f4d28709b28b829780',
    'CODE_FREEZE.json': '536a87dd8a28ebb0e2523dea5de9eb9e3c29056feeeedd98edeaf9adb67f00b5',
    'SEED_DRAW.json': '92ea28429941c172eeb7ee9fbe0bb8e8dd20c4ee8fee98b9ae170d3d69ae2a9e',
    'A_JOBS.json': '814984a04a91d80401a51b7936c79eb2feb75b4ee0213c302d0ade37f7e4bf75',
}
GRAPHS = ('Alpha', 'OTC')
STREAMS = ('slow', 'independent', 'signed-neighbor')
METHODS = ('D', 'S', 'H')
COMPLETE_WORKERS = {'completed_budget', 'certified_stop'}
COMPLETE_REQUESTS = {'budget_stop', 'tolerance_stop'}
THREAD_ENV = ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS',
              'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')
STATUS_MAP = {'budget_stop': 'completed_budget', 'tolerance_stop': 'certified_stop',
              'unresolved': 'unresolved', 'memory_error': 'memory_limit_exceeded',
              'error': 'runtime/certificate_error'}
ACCEPTED = {'accept', 'accepted'}
IDENTITY_FIELDS = ('epoch', 'winner_id', 'root_version_id', 'parent_version_id',
                   'current_version_id', 'i', 'j', 'd', 'flip')
INTERVAL_FIELDS = ('low', 'high')
COUNTERS = ('endpoint_checked', 'endpoint_excluded', 'live_catalog_denominator',
            'gram_materializations', 'gram_first', 'gram_rematerializations',
            'gram_hits', 'response_blocks', 'response_residual_matvec_columns',
            'state_rhs', 'candidate_rhs', 'winner_rhs', 'policy_refresh_rhs',
            'numerical_reanchor_rhs', 'score_calls', 'comparison_calls',
            'overlap_comparisons', 'structural_tie_attempts',
            'structural_tie_witnesses', 'structural_tie_decisions',
            'structural_tie_canonical_switches')
ACCESS = ('insertion_emissions', 'flips_emitted', 'raw_heap_pops',
          'legal_insertion_pops', 'flip_cursor_pops', 'total_source_pops',
          'frontier_rebuilds', 'frontier_resets', 'warm_screen_rows',
          'cold_emitted_for_screen', 'emitted_for_screen', 'seed_screen_rows',
          'seed_candidates', 'seed_insertions', 'seed_flips',
          'stream_pairs_examined', 'stream_insertions_emitted',
          'stream_flips_emitted', 'explicit_raw_visits',
          'processed_insertion_skips', 'processed_flip_skips',
          'node_sort_items', 'flip_sort_items', 'insertion_caps_built',
          'flip_caps_built', 'heap_build_items')


def utc():
    return datetime.now(timezone.utc).isoformat()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest_json(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def finite(value, *, positive=False):
    return type(value) in (int, float) and math.isfinite(value) and (value > 0 if positive else value >= 0)


def integer(value, minimum=0):
    return type(value) is int and value >= minimum


def unique_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError('duplicate JSON key: ' + key)
        value[key] = item
    return value


def bad_constant(value):
    raise ValueError('nonfinite JSON constant: ' + value)


def objects(value):
    return [x for x in value if isinstance(x, dict)] if isinstance(value, list) else []


def distribution(values, planned=None):
    values = [x for x in values if finite(x)]
    return {'samples': len(values), 'planned_samples': planned,
            'median': statistics.median(values) if values else None,
            'minimum': min(values) if values else None,
            'maximum': max(values) if values else None}


def error_text(error):
    return type(error).__name__ + ': ' + str(error)


class Reader:
    def __init__(self):
        self.files = {}

    def read(self, path):
        path = Path(path).resolve()
        data = path.read_bytes()
        record = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
        if str(path) in self.files and self.files[str(path)] != record:
            raise ValueError('input changed while being read: ' + str(path))
        self.files[str(path)] = record
        return data

    def json(self, path):
        return json.loads(self.read(path), object_pairs_hook=unique_object, parse_constant=bad_constant)

    def bound(self, path, expected):
        self.read(path)
        if self.files[str(Path(path).resolve())]['sha256'] != expected:
            raise ValueError('frozen digest mismatch: ' + str(path))

    def unchanged(self):
        changed = []
        for name, before in self.files.items():
            try:
                with Path(name).open('rb') as handle:
                    current = hashlib.file_digest(handle, 'sha256').hexdigest()
                if current != before['sha256']:
                    changed.append(name)
            except OSError:
                changed.append(name)
        return changed


@contextmanager
def idle_measurement_lock(runtime):
    path = runtime / 'logs/.measurement.lock'
    if not path.is_file():
        raise RuntimeError('runner measurement lock does not exist; refusing to assume measurements ended')
    # Open existing file read-only: validation never changes runtime artifacts.
    with path.open('rb') as handle:
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise RuntimeError('measurement is active; no raw results were read and no validation was launched') from error
        try:
            yield
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def inside(root, relative):
    root = Path(root).resolve()
    relative = Path(relative)
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('absolute path or lexical parent traversal: ' + str(relative))
    value = (root / relative).resolve()
    if value.is_relative_to(root):
        return value
    # The working runtime intentionally reuses these two read-only trees from
    # the supplied attachment. An alias must resolve to the exact known tree;
    # resolving its requested descendant must remain beneath that same tree.
    # Keep expected lexical: redirecting the expected tree itself is rejected.
    if relative.parts and relative.parts[0] in ('data', 'baseline_r15'):
        alias = root / relative.parts[0]
        expected = (root.parent / 'original' /
                    'J_CERT_Plus_A2_Exact_Tie_Revision_20261125' / relative.parts[0])
        if alias.is_symlink() and alias.resolve() == expected and value.is_relative_to(expected):
            return value
    raise ValueError('path escapes frozen root or approved source alias: ' + str(relative))


def expected_jobs():
    jobs = []
    for repeat in range(3):
        for cell, (graph, stream) in enumerate(product(GRAPHS, STREAMS)):
            pivot = (repeat + cell) % 3
            for method in METHODS[pivot:] + METHODS[:pivot]:
                jobs.append(dict(graph=graph, stream=stream, repeat_id=repeat,
                                 method=method, stage='A', requests=4, budget=15))
    return jobs


def load_freeze(runtime, reader):
    v2 = runtime / 'v2'
    for filename, expected in PINS.items():
        reader.bound(v2 / filename, expected)
    protocol = reader.json(v2 / 'PROTOCOL.json')
    manifest = reader.json(v2 / 'INPUTS.json')
    code = reader.json(v2 / 'CODE_FREEZE.json')
    draw = reader.json(v2 / 'SEED_DRAW.json')
    jobs = reader.json(v2 / 'A_JOBS.json')
    if jobs != expected_jobs():
        raise ValueError('frozen 54-worker rotation differs from declared A roster')
    if code['commit'] != FROZEN_COMMIT or manifest['code'] != code:
        raise ValueError('source boundary is not the pinned 4c2c7b7 freeze')
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=runtime, text=True).strip()
    if head != code['commit']:
        raise ValueError('current runtime HEAD differs from the frozen source commit')
    if manifest['protocol_sha256'] != PINS['PROTOCOL.json']:
        raise ValueError('input manifest does not bind the frozen protocol')
    for field, filename in (('code_freeze_sha256', 'CODE_FREEZE.json'),
                            ('seed_draw_sha256', 'SEED_DRAW.json'),
                            ('a_jobs_sha256', 'A_JOBS.json')):
        if protocol[field] != PINS[filename]:
            raise ValueError('protocol binding differs: ' + field)
    selections = [dict(graph=g, stream='independent', method='H', repeat_id=0, query_position=1) for g in GRAPHS]
    if protocol['independent_selection'] != selections:
        raise ValueError('prespecified full-catalog selections changed')
    if (manifest.get('verified') is not True or manifest.get('small_streams') != 6
            or manifest.get('small_opinions') != 24):
        raise ValueError('frozen distinct-input denominator differs')
    current_environment = dict(python=sys.version, executable=str(Path(sys.executable).resolve()),
        platform=platform.platform(), packages={name: metadata.version(name) for name in code['environment']['packages']})
    if current_environment != code['environment']:
        raise ValueError('validation interpreter/package environment differs from freeze; use frozen Python executable')
    for relative, expected in code['source_files_sha256'].items():
        reader.bound(inside(runtime, relative), expected)
    for graph, spec in manifest['graphs'].items():
        for path_key, hash_key in (('weighted_path', 'weighted_sha256'), ('unit_path', 'unit_sha256'),
                                   ('metadata_path', 'metadata_sha256')):
            if path_key in spec:
                reader.bound(inside(runtime, spec[path_key]), spec[hash_key])
    fixture_roster = [(g, s) for g in GRAPHS for s in STREAMS] + [('Slashdot', 'independent')]
    if [(r['graph'], r['stream']) for r in manifest['fixtures']] != fixture_roster:
        raise ValueError('fixture roster differs from freeze')
    used = set(draw['prior_seed_integers'])
    for row in manifest['fixtures']:
        counter = 0
        while True:
            label = f'J-CERT+|V2|2026-11-26|{draw["master_seed_hex"]}|{row["graph"]}|{row["stream"]}|{counter}'
            seed = int.from_bytes(hashlib.sha256(label.encode()).digest()[:8], 'big')
            if seed not in used:
                break
            counter += 1
        if (row['seed'], row['collision_counter'], row['derivation_label']) != (seed, counter, label):
            raise ValueError('seed derivation/collision rule differs for ' + row['fixture_id'])
        used.add(seed)
        if row['shape'] != [4, manifest['graphs'][row['graph']]['n']] or len(row['opinion_hashes']) != 4:
            raise ValueError('frozen fixture shape/row count differs')
        reader.bound(inside(v2, row['file']), row['npz_sha256'])
    return dict(runtime=runtime, v2=v2, protocol=protocol, manifest=manifest, code=code,
                jobs=jobs, fixtures={(r['graph'], r['stream']): r for r in manifest['fixtures']},
                current_environment=current_environment, head=head)


def file_label(position, job):
    return f"{position:03d}_{job['graph']}_{job['stream']}_{job['method']}_r{job['repeat_id']}"


def phases_check(value, elapsed):
    return (isinstance(value, dict) and finite(elapsed)
            and all(type(x) in (int, float) and math.isfinite(x) and x >= -1e-8 for x in value.values())
            and abs(sum(value.values()) - elapsed) <= 1e-7)


def request_record(request, query, fixture):
    if request is None:
        return dict(query_position=query, availability='missing', status='not_recorded',
                    completed=False, accepted_decisions=0, recorded_decisions=0,
                    no_decisions=True, binding_issues=[], accounting_issues=[])
    binding, accounting = [], []
    if request.get('query_position') != query or request.get('opinion_hash') != fixture['opinion_hashes'][query-1]:
        binding.append('query/opinion binding differs')
    if request.get('budget') != 15 or request.get('delta') != 0 or request.get('gain_denominator') != 2**96:
        binding.append('request numerical contract differs')
    decisions = request.get('decisions')
    if not isinstance(decisions, list) or len(objects(decisions)) != len(decisions):
        accounting.append('malformed decision list')
    rows = objects(decisions)
    accepted = [r for r in rows if r.get('status') in ACCEPTED]
    intervals = all(type(r.get('low')) is int and type(r.get('high')) is int and 0 < r['low'] <= r['high'] for r in accepted)
    if request.get('commits') != len(accepted) or len(accepted) > 15:
        accounting.append('commit count differs from accepted records')
    if not intervals:
        accounting.append('reported accepted interval malformed/nonpositive')
    elif (request.get('gain_low') != sum(r['low'] for r in accepted)
          or request.get('gain_high') != sum(r['high'] for r in accepted)):
        accounting.append('reported gain totals differ from accepted interval integers')
    if not phases_check(request.get('phases'), request.get('request_seconds')):
        accounting.append('request phase accounting differs')
    status = request.get('status', 'missing_status')
    if status == 'budget_stop' and len(accepted) != 15:
        accounting.append('budget_stop without 15 accepts')
    mapped = STATUS_MAP.get(status, 'runtime/certificate_error')
    if request.get('result_status') != mapped and not (status == 'error' and request.get('result_status') == 'memory_limit_exceeded'):
        accounting.append('request status classification differs')
    return dict(query_position=query, availability='recorded', status=status,
        result_status=request.get('result_status'), completed=status in COMPLETE_REQUESTS and not binding and not accounting,
        accepted_decisions=len(accepted), recorded_decisions=len(rows), no_decisions=not rows,
        reported_positive_interval_morphology=intervals if accepted else None,
        independent_positive_gain_reproved=False,
        terminal_decision_status=rows[-1].get('status') if rows else None,
        failure_reason=request.get('failure_reason'), binding_issues=binding,
        accounting_issues=accounting, request_sha256=digest_json(request),
        accepted_prefix_sha256=digest_json([{k:r.get(k) for k in (*IDENTITY_FIELDS, *INTERVAL_FIELDS)} for r in accepted]),
        _request=request)


def load_batch(freeze, reader):
    raw = freeze['v2'] / 'raw_a'
    schedule_path = raw / 'SCHEDULE_RESULTS.json'
    schedule = reader.json(schedule_path)
    if schedule.get('registered_jobs') != 54 or len(schedule.get('jobs', [])) != 54:
        raise RuntimeError('A schedule is not a finished 54-slot roster; do not inspect an active/partial schedule')
    workers, global_issues = [], []
    expected_files = {file_label(i,j)+'.json' for i,j in enumerate(freeze['jobs'])}
    unexpected = sorted(p.name for p in raw.glob('*.json') if p.name not in expected_files
                        and not p.name.endswith('.job.json') and p.name != 'SCHEDULE_RESULTS.json')
    if unexpected:
        global_issues.append('unexpected raw result files: '+','.join(unexpected))
    for position, (job, scheduled) in enumerate(zip(freeze['jobs'], schedule['jobs'])):
        label = file_label(position, job)
        path, job_path = raw/(label+'.json'), raw/(label+'.job.json')
        fixture = freeze['fixtures'][(job['graph'],job['stream'])]
        expected_job = job | dict(seconds=freeze['protocol']['small']['worker_seconds'],
            memory_bytes=freeze['protocol']['small']['memory_bytes'], frozen_manifest_sha256=PINS['INPUTS.json'])
        binding, accounting, trace, read_error = [], [], {}, None
        not_started = scheduled.get('status') == 'not_run_gate_failed' and 'file' not in scheduled
        if not_started:
            if scheduled.get('job') != {k:v for k,v in expected_job.items() if k != 'frozen_manifest_sha256'}:
                binding.append('not-started schedule job differs from frozen limits/roster')
            if path.exists() or job_path.exists():
                binding.append('not-started slot unexpectedly has raw/job file')
        else:
            if scheduled.get('file') != str(path.relative_to(freeze['runtime'])):
                binding.append('scheduler filename differs from frozen roster')
            try:
                if reader.json(job_path) != expected_job:
                    binding.append('worker job binding differs')
                trace = reader.json(path)
                if not isinstance(trace, dict):
                    raise ValueError('raw worker must be an object')
            except (OSError, ValueError, TypeError) as error:
                trace, read_error = {}, error_text(error)
                binding.append(read_error)
        if trace:
            for key, value in expected_job.items():
                # The frozen runner intentionally replaces job.requests=4
                # with the recorded request list in its trace. The integer
                # remains bound by A_JOBS and the exact .job.json above.
                if key == 'requests':
                    continue
                if trace.get(key) != value:
                    binding.append('raw job differs: '+key)
            for key, value in dict(protocol_sha256=PINS['PROTOCOL.json'], input_manifest_sha256=PINS['INPUTS.json'],
                source_files_sha256=freeze['code']['source_files_sha256'], fixture=fixture,
                graph_hash=freeze['manifest']['graphs'][job['graph']]['weighted_sha256'],
                n=freeze['manifest']['graphs'][job['graph']]['n'],
                catalog_size=freeze['manifest']['graphs'][job['graph']]['catalog_size'],
                hard_limit=expected_job['memory_bytes'], affinity=[freeze['protocol']['cpu']]).items():
                if trace.get(key) != value:
                    binding.append('raw source/input/limits binding missing or different: '+key)
            if trace.get('status') != scheduled.get('status') or trace.get('returncode') != scheduled.get('returncode'):
                binding.append('scheduler/raw terminal classification differs')
            if trace.get('process_wall_seconds') != scheduled.get('process_wall_seconds'):
                accounting.append('scheduler/raw process wall differs')
            if any(p.get('num_threads') != 1 for p in objects(trace.get('threadpools'))):
                binding.append('numerical threadpool differs from single thread')
        requests = trace.get('requests', [])
        if not isinstance(requests, list) or len(objects(requests)) != len(requests):
            accounting.append('malformed request list')
        if len(objects(requests)) > job['requests']:
            accounting.append('recorded request count exceeds the frozen planned count')
        if trace and [r.get('query_position') for r in objects(requests)] != list(range(1,len(objects(requests))+1)):
            binding.append('raw request ordering differs from the frozen Q1 through Q4 sequence')
        if trace and scheduled.get('completed_requests') != len(objects(requests)):
            accounting.append('scheduler recorded-request count differs from raw request count')
        indexed = defaultdict(list)
        for request in objects(requests):
            indexed[request.get('query_position')].append(request)
        invalid_query_rows = sum(len(v) for q,v in indexed.items() if type(q) is not int or not 1 <= q <= 4)
        if invalid_query_rows or any(len(v) != 1 for v in indexed.values()):
            accounting.append('duplicate or invalid request positions')
        qrows = [request_record(indexed[q][0] if len(indexed[q]) == 1 else None, q, fixture) for q in range(1,5)]
        for q in qrows:
            request=q.get('_request')
            if request is not None:
                if request.get('method') != job['method'] or request.get('root_version_id') != trace.get('root_version_id'):
                    q['binding_issues'].append('request method/root binding differs from worker')
                    q['completed']=False
        if trace and not_started:
            binding.append('not-started slot contains trace')
        cost = trace.get('complete_service_seconds')
        complete = (trace.get('status') in COMPLETE_WORKERS and trace.get('returncode') == 0
                    and len(objects(requests)) == 4 and all(q['completed'] for q in qrows)
                    and not binding and not accounting)
        if trace.get('status') in COMPLETE_WORKERS:
            if not finite(cost, positive=True):
                accounting.append('complete worker lacks positive finite complete_service_seconds')
            if trace.get('prefixes',{}).get('4') != cost or trace.get('service_accounted_seconds') != cost:
                accounting.append('complete service/prefix total differs')
        elif cost is not None:
            accounting.append('incomplete worker exposes a complete-service cost')
        if 'structural_seconds' in trace:
            if not phases_check(trace.get('structural_phases'), trace['structural_seconds']):
                accounting.append('structural phase accounting differs')
            elapsed = trace['structural_seconds']
            for request in objects(requests):
                if finite(request.get('request_seconds')):
                    elapsed += request['request_seconds']
                    q = request.get('query_position')
                    prefix = trace.get('prefixes',{}).get(str(q))
                    if not finite(prefix) or abs(prefix-elapsed)>1e-7:
                        accounting.append('recorded prefix cost differs: '+str(q))
                else:
                    accounting.append('request has invalid elapsed time')
            if not finite(trace.get('service_accounted_seconds')) or abs(trace['service_accounted_seconds']-elapsed)>1e-7:
                accounting.append('recorded service total does not reconcile with saved completed request walls')
        complete = complete and not accounting and finite(cost, positive=True)
        worker_identity = {key:value for key,value in job.items() if key != 'requests'}
        workers.append(dict(position=position, **worker_identity, planned_requests=job['requests'],
            raw_file=str(path), job_file=str(job_path),
            scheduled_status=scheduled.get('status','missing_status'), trace_status=trace.get('status','not_recorded'),
            failure_reason=trace.get('failure_reason') or scheduled.get('reason'),
            read_error=read_error, source_input_binding_issues=binding, accounting_issues=accounting,
            raw_present=bool(trace), not_started=not_started, complete_service=complete,
            complete_service_seconds=cost if complete else None,
            recorded_service_seconds=trace.get('service_accounted_seconds'),
            process_wall_seconds=trace.get('process_wall_seconds',scheduled.get('process_wall_seconds')),
            process_peak_rss_bytes=trace.get('process_peak_rss_bytes'),
            external_sampled_peak_rss_bytes=trace.get('external_sampled_peak_rss_bytes'),
            metering=trace.get('metering'), requests=qrows, _trace=trace, _scheduled=scheduled))
    return dict(workers=workers, schedule=schedule, global_issues=global_issues,
                unexpected_files=unexpected, schedule_path=str(schedule_path))


def clean(value):
    if isinstance(value, dict):
        return {k:clean(v) for k,v in value.items() if not k.startswith('_')}
    if isinstance(value,list):
        return [clean(v) for v in value]
    return value


def aggregate_numeric(rows):
    sections = dict(numeric=[q['counters'] for w in rows for q in objects(w['_trace'].get('requests')) if isinstance(q.get('counters'),dict)],
                    access=[a for w in rows for q in objects(w['_trace'].get('requests'))
                            for a in objects(q.get('access',{}).get('epochs'))])
    result = {}
    for section, fields in (('numeric',COUNTERS),('access',ACCESS)):
        records = sections[section]
        result[section] = {}
        for field in fields:
            values = [r[field] for r in records if integer(r.get(field))]
            result[section][field] = dict(observed_total=sum(values), records_with_value=len(values),
                recorded_denominator=len(records), all_recorded_rows_have_value=len(values)==len(records),
                mean_per_worker=sum(values)/len(rows) if rows and len(values)==len(records) else None,
                workers=len(rows))
    phase_values = defaultdict(list)
    phase_scope = Counter()
    for w in rows:
        for scope, records in (('structural',[w['_trace'].get('structural_phases')]),
                               ('request',[q.get('phases') for q in objects(w['_trace'].get('requests'))])):
            phase_scope[scope] += len(records)
            for phases in records:
                if isinstance(phases,dict):
                    for key,value in phases.items():
                        if type(value) in (int,float) and math.isfinite(value):
                            phase_values[scope+'.'+key].append(value)
    result['phases'] = {name:dict(total_seconds=sum(values), records_with_value=len(values),
        recorded_denominator=phase_scope[name.split('.')[0]]) for name,values in sorted(phase_values.items())}
    result['phase_note'] = 'Exclusive structural and request phase totals; metering.solve_seconds is an overlapping diagnostic and is not added.'
    return result


def method_group(rows):
    complete = [w for w in rows if w['complete_service']]
    costs = [w['complete_service_seconds'] for w in complete]
    actual = [w['recorded_service_seconds'] for w in rows if finite(w.get('recorded_service_seconds'))]
    return dict(planned_workers=len(rows), completed_service_workers=len(complete),
        full_roster_service_total_seconds=sum(costs) if len(complete)==len(rows) and rows else None,
        completed_service_distribution=distribution(costs,len(rows)),
        completed_service_sum_seconds=sum(costs) if costs else None,
        actual_recorded_service_sum_seconds=sum(actual), actual_recorded_service_values=len(actual),
        actual_work_scope='Checkpointed setup plus retained request walls, including unresolved requests with fewer accepted edits. An interrupted unfinished request may not be included; process wall is separate. This sum is not a complete-Q4 comparison.',
        process_wall_distribution=distribution([w.get('process_wall_seconds') for w in rows],len(rows)),
        process_peak_rss_all_attempted=distribution([w.get('process_peak_rss_bytes') for w in rows],len(rows)),
        process_peak_rss_complete_services=distribution([w.get('process_peak_rss_bytes') for w in complete],len(complete)),
        external_sampled_rss_all_attempted=distribution([w.get('external_sampled_peak_rss_bytes') for w in rows],len(rows)),
        recorded_work_all_attempted=aggregate_numeric(rows), completed_service_work=aggregate_numeric(complete))


def paired(cells, lookup, reference):
    matched, excluded, available_repeat_pairs = [], [], []
    for cell in cells:
        required = ('H','D','S') if reference=='better' else ('H',reference)
        missing = [{'repeat_id':r,'method':m,'status':lookup[(*cell,r,m)]['scheduled_status']}
                   for r in range(3) for m in required if not lookup[(*cell,r,m)]['complete_service']]
        pairs=[]
        for repeat in range(3):
            if all(lookup[(*cell,repeat,m)]['complete_service'] for m in required):
                h=lookup[(*cell,repeat,'H')]['complete_service_seconds']
                refs=('D','S') if reference=='better' else (reference,)
                m,cost=min(((m,lookup[(*cell,repeat,m)]['complete_service_seconds']) for m in refs),key=lambda x:(x[1],x[0]))
                pair=dict(graph=cell[0],stream=cell[1],repeat_id=repeat,H_seconds=h,reference_method=m,reference_seconds=cost,
                          H_over_reference=h/cost,reference_over_H=cost/h)
                pairs.append(pair);available_repeat_pairs.append(pair)
        if missing:
            excluded.append(dict(graph=cell[0],stream=cell[1],missing_complete_services=missing))
        else:
            matched.extend(pairs)
    hsum=sum(p['H_seconds'] for p in matched)
    rsum=sum(p['reference_seconds'] for p in matched)
    return dict(reference=reference,planned_cells=len(cells),matched_whole_cells=len(cells)-len(excluded),
        excluded_cells=excluded,planned_repeat_pairs=3*len(cells),matched_repeat_pairs=len(matched),
        finite_positive_matched_pairs=sum(finite(p['H_seconds'],positive=True) and finite(p['reference_seconds'],positive=True) for p in matched),
        eligible_repeat_pairs_without_whole_cell_requirement=len(available_repeat_pairs),
        sum_H_seconds=hsum if matched else None,sum_reference_seconds=rsum if matched else None,
        reference_over_H=rsum/hsum if matched else None,H_over_reference=hsum/rsum if matched else None,
        all_planned_cells_included=not excluded,selected_reference_counts=dict(Counter(p['reference_method'] for p in matched)),
        scope='Ratio of sums over completed whole 3-repeat cells. Excluded incomplete services are retained in roster/status outputs.',
        matched_pairs=matched,available_repeat_pairs=available_repeat_pairs)


def compare_requests(workers):
    by_cell=defaultdict(list)
    for w in workers:
        by_cell[(w['graph'],w['stream'])].append(w)
    reports=[]
    for cell,rows in by_cell.items():
        for query in range(1,5):
            exposures=[]
            for w in sorted(rows,key=lambda r:(r['repeat_id'],r['method'])):
                q=w['requests'][query-1]
                exposures.append(dict(position=w['position'],method=w['method'],repeat_id=w['repeat_id'],
                    availability=q['availability'],status=q['status'],raw_file=w['raw_file'],
                    recorded_decisions=q['recorded_decisions'],accepted_decisions=q['accepted_decisions'],
                    no_decisions=q['no_decisions'],_request=q.get('_request')))
            comparisons=[]
            for a,b in combinations(exposures,2):
                left,right=a['_request'],b['_request']
                base=dict(left_position=a['position'],right_position=b['position'])
                if left is None or right is None:
                    comparisons.append(base|dict(comparable=False,reason='one or both planned requests not recorded'))
                    continue
                ld,rd=objects(left.get('decisions')),objects(right.get('decisions'))
                la=[d for d in ld if d.get('status') in ACCEPTED];ra=[d for d in rd if d.get('status') in ACCEPTED]
                shared=min(len(la),len(ra));identity_diffs=[];interval_diffs=[]
                for index in range(shared):
                    for field in IDENTITY_FIELDS:
                        if la[index].get(field)!=ra[index].get(field):
                            identity_diffs.append(dict(accepted_position=index+1,field=field,left=la[index].get(field),right=ra[index].get(field)))
                    for field in INTERVAL_FIELDS:
                        if la[index].get(field)!=ra[index].get(field):
                            interval_diffs.append(dict(accepted_position=index+1,field=field,left=la[index].get(field),right=ra[index].get(field)))
                projection=lambda ds:[{k:d.get(k) for k in ('status',*IDENTITY_FIELDS,*INTERVAL_FIELDS)} for d in ds]
                comparisons.append(base|dict(comparable=True,shared_accepted_prefix_decisions=shared,
                    zero_shared_accepts=shared==0,identity_differences=identity_diffs,interval_endpoint_differences=interval_diffs,
                    shared_accepted_id_versions_equal=not identity_diffs,
                    shared_accepted_interval_endpoints_equal=not interval_diffs,
                    equal_accepted_prefix_lengths=len(la)==len(ra),equal_request_status=left.get('status')==right.get('status'),
                    equal_all_recorded_decision_projection=projection(ld)==projection(rd),
                    equal_root_and_opinion=all(left.get(k)==right.get(k) for k in ('root_version_id','opinion_hash')),
                    left_accepted=len(la),right_accepted=len(ra)))
            usable=[p for p in comparisons if p['comparable']]
            reports.append(dict(graph=cell[0],stream=cell[1],query_position=query,
                planned_exposures=9,recorded_exposures=sum(e['_request'] is not None for e in exposures),
                planned_pairwise_comparisons=36,comparable_pairs=len(usable),
                exposures=clean(exposures),pairwise_comparisons=comparisons,
                all_9_exposures_recorded=len(usable)==36,
                all_9_decision_projections_identical=len(usable)==36 and all(p['equal_all_recorded_decision_projection'] for p in usable),
                all_9_accepted_id_version_sequences_identical=len(usable)==36 and all(p['shared_accepted_id_versions_equal'] and p['equal_accepted_prefix_lengths'] for p in usable),
                all_nonempty_shared_accepted_id_versions_equal=bool(usable) and all(p['shared_accepted_id_versions_equal'] for p in usable),
                nonempty_shared_prefix_pairs=sum(not p['zero_shared_accepts'] for p in usable),
                pairwise_interval_difference_count=sum(len(p['interval_endpoint_differences']) for p in usable),
                note='Equality is saved-record determinism, not independent numerical correctness; missing requests and empty accepted prefixes are explicit.'))
    return reports


def aggregate(freeze,batch):
    workers=batch['workers'];cells=list(product(GRAPHS,STREAMS))
    lookup={(w['graph'],w['stream'],w['repeat_id'],w['method']):w for w in workers}
    cell_rows=[]
    for cell in cells:
        methods={}
        for m in METHODS:
            rows=[lookup[(*cell,r,m)] for r in range(3)]
            value=method_group(rows)
            value['seconds_by_repeat']=[w['complete_service_seconds'] for w in rows]
            value['raw_files']=[w['raw_file'] for w in rows]
            value['full_three_repeat_median_seconds']=value['completed_service_distribution']['median'] if all(w['complete_service'] for w in rows) else None
            value['full_three_repeat_range_seconds']=([min(value['seconds_by_repeat']),max(value['seconds_by_repeat'])]
                if all(w['complete_service'] for w in rows) else None)
            methods[m]=value
        cell_rows.append(dict(graph=cell[0],stream=cell[1],methods=methods,
                              comparisons={ref:paired([cell],lookup,ref) for ref in ('D','S','better')}))
    requests=[q for w in workers for q in w['requests']]
    recorded=[q for q in requests if q['availability']=='recorded']
    binding_issues=[dict(position=w['position'],issues=w['source_input_binding_issues']) for w in workers if w['source_input_binding_issues']]
    accounting_issues=[dict(position=w['position'],issues=w['accounting_issues'],request_issues=[clean(q) for q in w['requests'] if q['binding_issues'] or q['accounting_issues']])
        for w in workers if w['accounting_issues'] or any(q['binding_issues'] or q['accounting_issues'] for q in w['requests'])]
    deterministic=compare_requests(workers)
    comparable=[p for r in deterministic for p in r['pairwise_comparisons'] if p['comparable']]
    identity_conflicts=sum(bool(p['identity_differences']) for p in comparable)
    interval_comparison_decisions=sum(p['shared_accepted_prefix_decisions'] for p in comparable)
    interval_mismatch_decisions=sum(len({d['accepted_position'] for d in p['interval_endpoint_differences']}) for p in comparable)
    status=('accounting_or_binding_gap' if binding_issues or accounting_issues or batch['global_issues'] else
            'deterministic_identity_disagreement' if identity_conflicts else 'accounting_verified')
    return dict(status=status,
        report_date=DOCUMENT_DATE,study='prespecified unseen V2 A batch',new_speed_threshold_applied=False,
        original_confirmation_reclassified=False,
        denominators=dict(independent_streams=6,distinct_opinion_rows=24,methods=3,repeats=3,
            planned_workers=54,raw_workers_present=sum(w['raw_present'] for w in workers),
            complete_Q4_workers=sum(w['complete_service'] for w in workers),planned_request_executions=216,
            recorded_request_executions=len(recorded),completed_request_executions=sum(q['completed'] for q in requests),
            maximum_possible_accepted_decisions=3240,recorded_accepted_decisions=sum(q['accepted_decisions'] for q in requests),
            recorded_decisions_including_terminal=sum(q['recorded_decisions'] for q in requests)),
        worker_status_counts=dict(Counter(w['scheduled_status'] for w in workers)),
        per_request_status_counts_including_missing=dict(Counter(q['status'] for q in requests)),
        per_request_result_status_counts=dict(Counter(q.get('result_status','not_recorded') for q in requests)),
        no_decision_request_slots=sum(q['no_decisions'] for q in requests),
        missing_request_slots=sum(q['availability']=='missing' for q in requests),
        zero_accept_recorded_request_status_counts=dict(Counter(q['status'] for q in recorded if q['accepted_decisions']==0)),
        global_issues=batch['global_issues'],source_input_binding_issues=binding_issues,accounting_issues=accounting_issues,
        cells=cell_rows,overall_methods={m:method_group([w for w in workers if w['method']==m]) for m in METHODS},
        graph_methods={g:{m:method_group([w for w in workers if w['graph']==g and w['method']==m]) for m in METHODS} for g in GRAPHS},
        full_service_comparisons={ref:paired(cells,lookup,ref) for ref in ('D','S','better')},
        deterministic_request_comparisons=deterministic,
        deterministic_summary=dict(planned_distinct_requests=24,all_9_present=sum(r['all_9_exposures_recorded'] for r in deterministic),
            all_9_identical_saved_decisions=sum(r['all_9_decision_projections_identical'] for r in deterministic),
            all_9_identical_accepted_id_version_sequences=sum(r['all_9_accepted_id_version_sequences_identical'] for r in deterministic),
            planned_pairwise_comparisons=864,comparable_pairs=sum(r['comparable_pairs'] for r in deterministic),
            shared_accepted_identity_conflict_pairs=identity_conflicts,
            unequal_accepted_sequence_length_pairs=sum(not p['equal_accepted_prefix_lengths'] for p in comparable),
            unequal_request_terminal_status_pairs=sum(not p['equal_request_status'] for p in comparable),
            interval_endpoint_difference_count=sum(r['pairwise_interval_difference_count'] for r in deterministic),
            shared_accepted_decision_interval_comparisons=interval_comparison_decisions,
            exact_interval_endpoint_match_decisions=interval_comparison_decisions-interval_mismatch_decisions,
            distinct_interval_endpoint_decisions=interval_mismatch_decisions,
            interval_difference_is_not_alone_scientific_error=True),
        workers=clean(workers),definitions=dict(
            cost='Full graph load/setup plus four complete request walls. Incomplete worker recorded time is partial work and excluded from complete-service ratios.',
            ratios='Ratios of paired cost sums over whole three-repeat cells; not ratios of medians. All excluded cells/finite pair denominators are explicit.',
            medians='Primary cell median/min-max require three completed services; available-completed distributions retain their reduced sample count.',
            rss='Process-lifetime high-water bytes; external samples are separate. MiB=bytes/1048576; RSS is never summed.',
            request_independence='24 opinion rows belong to six independent seeded streams; methods and timing repeats are not additional independent inputs.',
            interval_scope='Positive integer interval morphology and summed bindings are checked here; mathematical numerical positivity/optimality are not independently re-proved.',
            phases='Structural and request phases are exclusive within their service boundaries; overlapping factor/solve metering is diagnostic.',
            failures='Missing, not-started, timeout, memory, runtime/certificate errors and unresolved prefixes remain in planned denominators.'),
        actual_schedule=batch['schedule'])


def setup_numerical(runtime,cpu,memory_bytes=None):
    for key in THREAD_ENV:
        os.environ[key]='1'
    os.environ['PYTHONDONTWRITEBYTECODE']='1'
    os.sched_setaffinity(0,{cpu})
    if memory_bytes is not None:
        resource.setrlimit(resource.RLIMIT_AS,(memory_bytes,memory_bytes))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    sys.path.insert(0,str(runtime))


def numerical_inputs(freeze, graphs=GRAPHS):
    import numpy as np
    from scipy import sparse
    from src.a2_checker import A2CatalogReplay
    replays,opinions={},{}
    for graph in graphs:
        spec=freeze['manifest']['graphs'][graph]
        replay=A2CatalogReplay(sparse.load_npz(freeze['runtime']/spec['weighted_path']))
        if (replay.n,replay.m)!=(spec['n'],spec['catalog_size']):
            raise ValueError('independent graph/catalog dimensions differ: '+graph)
        replays[graph]=replay
    for key,row in freeze['fixtures'].items():
        if key[0] not in graphs:
            continue
        with np.load(freeze['v2']/row['file'],allow_pickle=False) as archive:
            if archive.files!=['opinions']:
                raise ValueError('unexpected opinion NPZ members')
            matrix=archive['opinions']
        if (matrix.dtype!=np.dtype('<i8') or list(matrix.shape)!=row['shape'] or not matrix.flags.c_contiguous
                or np.any(matrix < -65536) or np.any(matrix > 65536)):
            raise ValueError('opinion matrix dtype/layout/range differs')
        if hashlib.sha256(matrix.tobytes()).hexdigest()!=row['matrix_sha256'] or [hashlib.sha256(s.tobytes()).hexdigest() for s in matrix]!=row['opinion_hashes']:
            raise ValueError('opinion matrix/row digest differs')
        opinions[key]=matrix
    return replays,opinions


def raw_declarations(workers):
    counts=Counter();declarations=Counter()
    for w in workers:
        for request in objects(w['_trace'].get('requests')):
            counts['raw_recorded_request_objects']+=1
            ds=request.get('decisions')
            if isinstance(ds,list):
                counts['raw_recorded_decisions']+=len(ds)
            for decision in objects(ds):
                if decision.get('status') in ACCEPTED:
                    counts['raw_recorded_accepts']+=1
                if 'comparison_resolution' in decision:
                    counts['comparison_resolution_records']+=1
                    evidence=decision['comparison_resolution']
                    ws=evidence.get('witnesses') if isinstance(evidence,dict) else None
                    if isinstance(ws,list):
                        counts['declared_witness_observations']+=len(ws)
                        for witness in ws:
                            declarations[digest_json(witness)]+=1
                    else:
                        counts['malformed_witness_list_records']+=1
    return counts,declarations


def chains(freeze,batch):
    setup_numerical(freeze['runtime'],freeze['protocol']['cpu'],freeze['protocol']['small']['memory_bytes'])
    from threadpoolctl import threadpool_limits
    from src.a2_tie_verify_retest import inspect_request
    # inspect_request calls the unchanged src.a2_checker._TieProofs for every
    # accepted edit's legality and every actual structural witness declaration.
    aggregates=dict(counts=Counter(),declarations=Counter(),relations={},bad_witnesses=[],unsupported_cases=[],proof_check_work=Counter())
    raw_counts,declarations=raw_declarations(batch['workers'])
    aggregates['counts'].update(raw_counts);aggregates['declarations'].update(declarations)
    workers=[]
    with threadpool_limits(limits=1):
        replays,opinions=numerical_inputs(freeze)
        for w in batch['workers']:
            output=dict(position=w['position'],graph=w['graph'],stream=w['stream'],method=w['method'],repeat_id=w['repeat_id'],
                raw_file=w['raw_file'],worker_status=w['scheduled_status'],input_binding_issues=w['source_input_binding_issues'],requests=[])
            seen=Counter()
            for ordinal,request in enumerate(objects(w['_trace'].get('requests')),1):
                query=request.get('query_position');seen[query]+=1
                if w['source_input_binding_issues'] or type(query) is not int or not 1<=query<=4:
                    output['requests'].append(dict(request_ordinal=ordinal,query_position=query,chain_verified=False,
                        status='unverifiable_input_binding',recorded_status=request.get('status'),unverified_request=request))
                    continue
                try:
                    proof=inspect_request(replays[w['graph']],opinions[(w['graph'],w['stream'])][query-1],request,
                        dict(graph=w['graph'],stream=w['stream'],seed_label='V2',method=w['method'],repeat_id=w['repeat_id'],schedule_position=w['position']),
                        query,freeze['manifest']['graphs'][w['graph']]['weighted_sha256'],aggregates)
                    proof['request_ordinal']=ordinal
                    proof['scope']='Exact structural parent/child legality and version chain; reported positive interval shape and totals, without independent numerical gain proof.'
                    output['requests'].append(proof)
                    aggregates['counts']['request_parent_chains_verified']+=int(proof['chain_verified'])
                except Exception as error:
                    output['requests'].append(dict(request_ordinal=ordinal,query_position=query,chain_verified=False,
                        status='verification_error',recorded_status=request.get('status'),error=error_text(error)))
            output['missing_planned_queries']=[q for q in range(1,5) if seen[q]==0]
            output['duplicate_queries']=[q for q,n in seen.items() if n>1]
            workers.append(output)
            print(canonical(dict(phase='structural_parent_and_actual_witness_audit',position=w['position'],
                  request_chains_verified=sum(q['chain_verified'] for q in output['requests']))),flush=True)
    c=aggregates['counts']
    c['declared_witness_observations_not_processed']=c['declared_witness_observations']-c['declared_witness_observations_processed']
    all_present=all(q['chain_verified'] for w in workers for q in w['requests']) and c['raw_recorded_request_objects']>0
    all_planned=all_present and c['request_parent_chains_verified']==216 and all(not w['missing_planned_queries'] and not w['duplicate_queries'] for w in workers)
    witnesses=(not aggregates['bad_witnesses'] and not c['malformed_witness_list_records']
        and c['witness_observations_verified']==c['declared_witness_observations']
        and c['comparison_resolution_metadata_verified']==c['comparison_resolution_records']
        and not c['comparison_resolution_metadata_invalid'] and not c['declared_witness_observations_not_processed'])
    parents=c['exact_parents_reconstructed']==c['raw_recorded_decisions']
    valid=all_present and witnesses and parents and not batch['global_issues'] and all(not w['input_binding_issues'] for w in workers if w['requests'])
    return dict(status=('verified_with_preserved_partial_or_unsupported_cases' if aggregates['unsupported_cases'] or not all_planned else 'verified') if valid else 'verification_gap',
        report_date=DOCUMENT_DATE,planned_workers=54,planned_request_executions=216,independent_streams=6,distinct_opinion_rows=24,
        all_present_request_parent_chains_verified=all_present,all_216_planned_request_parent_chains_verified=all_planned,
        all_recorded_parents_reconstructed=parents,all_actual_witness_declarations_verified=witnesses,
        no_witnesses_observed=c['declared_witness_observations']==0,
        counts=dict(c),proof_check_work=dict(aggregates['proof_check_work']),workers=workers,
        declaration_observation_counts=dict(aggregates['declarations']),
        distinct_verified_relations=[dict(exact_relation_sha256=k,**v,observation_count=len(v['observations'])) for k,v in sorted(aggregates['relations'].items())],
        bad_witnesses=aggregates['bad_witnesses'],unsupported_cases=aggregates['unsupported_cases'],
        source_functions=['src.a2_tie_verify_retest.inspect_request','src.a2_checker._TieProofs'],
        wrapper_metadata_adapter='seed_label="V2" is only a location label supplied to unchanged inspect_request; raw requests and witnesses are not modified.',
        independent_numeric_positive_gain_reproof=False,full_catalog_optimality_reproof=False,
        scope='Exact input/operator/opinion/current version/legality/parent-chain audit and every actual witness. Positive integer interval morphology is a reported-data check, not an independent numerical bound proof. Unresolved terminal rows and accepted prefixes are preserved.')


class CheckerTimeout(BaseException):
    pass


def full_catalog(freeze,batch,sample,max_seconds):
    selection=next(s for s in freeze['protocol']['independent_selection'] if s['graph']==sample)
    matches=[w for w in batch['workers'] if all(w[k]==selection[k] for k in ('graph','stream','method','repeat_id'))]
    if len(matches)!=1:
        raise ValueError('prespecified sample does not match exactly one frozen worker')
    w=matches[0];query=selection['query_position'];request=w['requests'][query-1]
    result=dict(report_date=DOCUMENT_DATE,selection=selection,position=w['position'],raw_file=w['raw_file'],
        selected_request_sha256=request.get('request_sha256'),recorded_worker_status=w['scheduled_status'],
        recorded_request_status=request['status'],recorded_decisions=request['recorded_decisions'],
        recorded_accepts=request['accepted_decisions'],replacement_used=False,request_trimmed=False,
        validation_timeout_seconds=max_seconds,validation_budget_is_not_algorithm_success_gate=True,
        source_function='src.a2_checker.replay_file',algorithm_timing=False)
    if w['source_input_binding_issues'] or request['availability']!='recorded' or request['binding_issues']:
        return result|dict(status='selected_sample_unavailable_or_unbound',binding_issues=w['source_input_binding_issues']+request['binding_issues'],
            full_request_certified=False,scope='Prespecified selection retained; no replacement and no checker call.')
    setup_numerical(freeze['runtime'],freeze['protocol']['cpu'],freeze['protocol']['small']['memory_bytes'])
    from threadpoolctl import threadpool_limits
    from src.a2_checker import replay_file
    spec=freeze['manifest']['graphs'][sample];fixture=freeze['fixtures'][(sample,selection['stream'])]
    def timeout_handler(signum,frame):
        raise CheckerTimeout('explicit validator timeout reached')
    previous=signal.signal(signal.SIGALRM,timeout_handler)
    started=perf_counter();cpu_started=process_time()
    signal.setitimer(signal.ITIMER_REAL,max_seconds)
    try:
        with threadpool_limits(limits=1):
            proof=replay_file(w['raw_file'],freeze['runtime']/spec['weighted_path'],freeze['v2']/fixture['file'],request=query)
        value=proof['proof'];checks=value['decision_checks']
        certified_accepts=sum(r.get('certified') is True and r.get('status')=='accepted' for r in checks)
        whole=value.get('termination_certified') is True and value.get('full_catalog_decisions_certified') is True
        result.update(status='full_selected_request_verified' if whole else 'accepted_prefix_verified_terminal_unresolved',
            full_request_certified=whole,accepted_decisions_independently_certified=certified_accepts,
            terminal_status_certified=value.get('termination_certified'),proof=proof,
            scope='Actual complete selected request including its original terminal row. A preserved unresolved terminal is not certified; only actually certified accepted-prefix decisions may be claimed.',
            published_interval_scope='For nonexact large graphs, independent interval intersection consistency, not full published-interval enclosure.')
    except CheckerTimeout as error:
        result.update(status='checker_timeout',full_request_certified=False,error=str(error),
            scope='The exact prespecified request was attempted without trimming/substitution; no partial unreturned checker result is claimed.')
    except BaseException as error:
        result.update(status='checker_error',full_request_certified=False,error=error_text(error),traceback=traceback.format_exc(),
            scope='The exact prespecified request was attempted without trimming/substitution. The checker returned no certified result.')
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        signal.signal(signal.SIGALRM,previous)
        result.update(checker_mode_wall_seconds=perf_counter()-started,checker_mode_cpu_seconds=process_time()-cpu_started,
            process_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
            rss_scope='Process-lifetime high-water RSS including validation input/hash work and checker allocations; not algorithm RSS or incremental sample RSS.')
    return result


def write_exclusive(path,value):
    path=path.resolve()
    if not path.is_relative_to(HERE) or path.suffix!='.json':
        raise ValueError('validation output must be a JSON file within '+str(HERE))
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as handle:
        json.dump(value,handle,ensure_ascii=False,indent=2,allow_nan=False)
        handle.write('\n')


def write_csv_exclusive(path,rows):
    with path.open('x',newline='',encoding='utf-8') as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)


def aggregate_csvs(output,report):
    rows=[]
    for cell in report['cells']:
        row=dict(graph=cell['graph'],stream=cell['stream'])
        for m,value in cell['methods'].items():
            row[m+'_completed']=value['completed_service_workers']
            row[m+'_planned']=value['planned_workers']
            row[m+'_median_seconds']=value['full_three_repeat_median_seconds']
            limits=value['full_three_repeat_range_seconds']
            row[m+'_minimum_seconds']=limits[0] if limits else None
            row[m+'_maximum_seconds']=limits[1] if limits else None
            row[m+'_RSS_median_bytes_all_attempted']=value['process_peak_rss_all_attempted']['median']
        for ref in ('D','S','better'):
            p=cell['comparisons'][ref]
            row[ref+'_over_H']=p['reference_over_H']
            row[ref+'_matched_repeat_pairs']=p['matched_repeat_pairs']
        rows.append(row)
    write_csv_exclusive(output.with_name(output.stem+'_cells.csv'),rows)
    reqs=[]
    for w in report['workers']:
        for q in w['requests']:
            reqs.append(dict(position=w['position'],graph=w['graph'],stream=w['stream'],method=w['method'],repeat_id=w['repeat_id'],
                query_position=q['query_position'],worker_status=w['scheduled_status'],request_status=q['status'],availability=q['availability'],
                accepted_decisions=q['accepted_decisions'],recorded_decisions=q['recorded_decisions'],no_decisions=q['no_decisions'],
                complete_Q4_worker=w['complete_service'],raw_file=w['raw_file'],request_sha256=q.get('request_sha256')))
    write_csv_exclusive(output.with_name(output.stem+'_requests.csv'),reqs)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=('aggregate','chains','full-catalog'))
    parser.add_argument('--runtime',type=Path,default=DEFAULT_RUNTIME)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--sample',choices=GRAPHS,help='Required for full-catalog; exact prespecified H/r0/independent/q1 only')
    parser.add_argument('--max-seconds',type=float,default=1800.,help='Operational checker timeout, recorded separately from algorithm timings')
    args=parser.parse_args()
    if args.mode=='full-catalog' and args.sample is None:
        parser.error('--sample Alpha or OTC is required; one selected checker call per invocation')
    if args.mode!='full-catalog' and args.sample is not None:
        parser.error('--sample is only valid for full-catalog')
    if not finite(args.max_seconds,positive=True):
        parser.error('--max-seconds must be finite and positive')
    default_name={'aggregate':'a_aggregate.json','chains':'a_parent_witness.json','full-catalog':f'a_full_catalog_{args.sample}.json'}[args.mode]
    output=(args.output or HERE/default_name).resolve()
    if output.exists():
        parser.error('output exists; refusing to replace prior validation evidence: '+str(output))
    if not output.is_relative_to(HERE):
        parser.error('output must remain within validation directory')
    if args.mode=='aggregate':
        for suffix in ('_cells.csv','_requests.csv'):
            if output.with_name(output.stem+suffix).exists():
                parser.error('companion CSV already exists')
    reader=Reader();runtime=args.runtime.resolve();started=perf_counter();cpu_started=process_time()
    report=None
    # This guard is acquired before freeze/data hashing and raw result reads.
    with idle_measurement_lock(runtime):
        try:
            freeze=load_freeze(runtime,reader)
            batch=load_batch(freeze,reader)
            if args.mode=='aggregate':
                report=aggregate(freeze,batch)
            elif args.mode=='chains':
                report=chains(freeze,batch)
            else:
                report=full_catalog(freeze,batch,args.sample,args.max_seconds)
        except BaseException as error:
            report=dict(status='validation_precondition_or_execution_error',report_date=DOCUMENT_DATE,
                        mode=args.mode,error=error_text(error),traceback=traceback.format_exc(),algorithm_timing=False)
        changed=reader.unchanged()
        report.update(mode=args.mode,generated_at_utc=utc(),frozen_commit=FROZEN_COMMIT,runtime_root=str(runtime),
            validator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            frozen_file_pins=PINS,input_files_sha256=reader.files,input_files_changed_during_validation=changed,
            validator_wall_seconds=perf_counter()-started,validator_cpu_seconds=process_time()-cpu_started,
            validation_cost_is_separate_from_algorithm_service=True)
        if changed:
            report['status']='input_changed_during_validation'
        write_exclusive(output,report)
        if args.mode=='aggregate' and 'cells' in report:
            aggregate_csvs(output,report)
    print(canonical(dict(status=report['status'],output=str(output),mode=args.mode,
                         denominators=report.get('denominators'),counts=report.get('counts'))),flush=True)
    acceptable={'accounting_verified','verified','verified_with_preserved_partial_or_unsupported_cases',
                'full_selected_request_verified','accepted_prefix_verified_terminal_unresolved'}
    return 0 if report['status'] in acceptable else 1


if __name__=='__main__':
    raise SystemExit(main())
