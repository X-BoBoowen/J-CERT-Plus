#!/usr/bin/env python3
"""Read-only bookkeeping of the completed V2 scale attempt; no numeric imports."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent/'runtime'
V2=ROOT/'v2'
files={}
issues=[]


def read(path):
    path=Path(path).resolve();raw=path.read_bytes()
    files[str(path)]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
    return json.loads(raw)


def check(condition,message):
    if not condition:
        issues.append(message)


protocol=read(V2/'PROTOCOL.json')
manifest=read(V2/'INPUTS.json')
code=read(V2/'CODE_FREEZE.json')
stages=read(V2/'raw_b/STAGE_RESULTS.json')
preflight=read(V2/'raw_b/D_PREFLIGHT.json')
trace_path=V2/'raw_b/000_Slashdot_independent_H_r0.json'
job_path=V2/'raw_b/000_Slashdot_independent_H_r0.job.json'
trace=read(trace_path);job=read(job_path)
aggregate=read(OUT/'a_aggregate.json')
spec=manifest['graphs']['Slashdot']
check(code['commit']=='4c2c7b7e84c7c03ee56d45453fea6950c94817bd','source commit differs')
check(manifest['code']==code,'embedded source freeze differs')
check(manifest['protocol_sha256']==files[str((V2/'PROTOCOL.json').resolve())]['sha256'],'protocol binding differs')
check(protocol['code_freeze_sha256']==files[str((V2/'CODE_FREEZE.json').resolve())]['sha256'],'code-freeze binding differs')
check(aggregate['status']=='accounting_verified' and not aggregate['input_files_changed_during_validation'],
      'reference source/current-input validation is not verified')
for path,record in files.copy().items():
    prior=aggregate['input_files_sha256'].get(path)
    if prior is not None:
        check(prior==record,'shared frozen file differs from completed A validation: '+path)
expected_job=dict(graph='Slashdot',stream='independent',repeat_id=0,budget=15,
    memory_bytes=protocol['scale']['memory_bytes'],method='H',stage='B1',requests=0,
    seconds=protocol['scale']['root_profile_seconds'],frozen_manifest_sha256=files[str((V2/'INPUTS.json').resolve())]['sha256'])
check(job==expected_job,'B1 job differs from frozen profile/limits')
for key,value in expected_job.items():
    if key!='requests':
        check(trace.get(key)==value,'B1 raw job binding differs: '+key)
check(trace.get('requests')==[],'root profile unexpectedly contains request executions')
check(trace.get('source_files_sha256')==code['source_files_sha256'],'B1 raw source hash map differs')
check(trace.get('protocol_sha256')==manifest['protocol_sha256'],'B1 protocol digest differs')
check(trace.get('input_manifest_sha256')==expected_job['frozen_manifest_sha256'],'B1 input manifest digest differs')
fixture=next(row for row in manifest['fixtures'] if (row['graph'],row['stream'])==('Slashdot','independent'))
check(trace.get('fixture')==fixture,'B1 fixture record differs')
check(trace.get('graph_hash')==spec['weighted_sha256'],'B1 graph digest differs')
check((trace.get('n'),trace.get('catalog_size'))==(spec['n'],spec['catalog_size']),'B1 graph/catalog dimensions differ')
check(trace.get('hard_limit')==protocol['scale']['memory_bytes'],'B1 RLIMIT_AS differs')
check(trace.get('affinity')==[protocol['cpu']],'B1 CPU affinity differs')
check(all(t.get('num_threads')==1 for t in trace.get('threadpools',[])),'B1 numerical threads differ')
check(stages['D']==preflight,'D preflight differs from stage summary')
m=spec['catalog_size'];limit=protocol['scale']['memory_bytes']
arrays={'i_int32':4*m,'j_int32':4*m,'flip_bool':m,'weight_int64':8*m}
check(preflight['mandatory_arrays']==arrays and preflight['minimum_pool_and_weights_bytes']==17*m,'D array-payload arithmetic differs')
check(preflight['memory_limit_bytes']==limit,'D preflight resource limit differs')
check(preflight['ordinal_capacity_admitted']==(m<2**31),'D ordinal-capacity check differs')
check(preflight['status']==('not_started_memory_preflight' if 17*m>limit else 'not_run_gate_failed' if m>=2**31 else 'admitted'),'D preflight classification differs')
first=stages['stages'][0]
check(first['file']==str(trace_path.relative_to(ROOT)),'first stage raw path differs')
check(all(first[k]==trace[k] for k in ('status','returncode','process_wall_seconds')),'stage/raw outcome or wall differs')
check(first['completed_requests']==0,'B1 recorded request count differs')
expected_gates=[dict(stage=stage,method=method,repeat_id=repeat,status='not_run_gate_failed',reason='B1 root preparation did not complete')
    for stage,repeats in (('B2_Q1',range(1)),('B3_Q4',range(3))) for repeat in repeats for method in ('H','S')]
check(stages['stages'][1:]==expected_gates,'later stage gates differ from B1 failure policy')
check(trace.get('status')=='timeout' and trace.get('returncode')==-9,'observed B1 outcome differs from timeout/SIGKILL record')
check(trace.get('complete_service_seconds') is None,'incomplete profile exposes a complete service time')
check(trace.get('prefixes')=={},'root profile has request-prefix times')
checkpoint_rss=trace.get('process_peak_rss_bytes')
external_rss=trace.get('external_sampled_peak_rss_bytes')
external_vms=trace.get('external_sampled_peak_vms_bytes')
result=dict(schema_version=1,report_date='2026-11-26',generated_at_utc=datetime.now(timezone.utc).isoformat(),
    audit_kind='existing_scale_record_bookkeeping_no_numeric_replay',status='bookkeeping_verified' if not issues else 'bookkeeping_gap',issues=issues,
    graph='Slashdot',n=spec['n'],catalog_size=m,root_positive_edges=spec['root_positive_edges'],root_negative_edges=spec['root_negative_edges'],
    source_boundary=code['commit'],all_raw_source_hash_declarations_match_freeze=trace.get('source_files_sha256')==code['source_files_sha256'],
    current_source_identity_cross_reference=str((OUT/'a_aggregate.json').resolve()),
    B1=dict(status=trace['status'],last_checkpoint_status=trace.get('last_worker_status'),active_phase_at_last_checkpoint=trace.get('active_phase'),
        returncode=trace['returncode'],planned_root_profile_seconds=job['seconds'],process_wall_seconds=trace['process_wall_seconds'],
        branch_wall_seconds=stages['branch_wall_seconds'],recorded_requests=len(trace['requests']),recorded_decisions=0,recorded_accepts=0,
        complete_service_seconds=trace.get('complete_service_seconds'),structural_seconds_recorded=trace.get('structural_seconds'),
        last_checkpoint_worker_wall_seconds=trace.get('worker_wall_seconds'),metering_at_last_checkpoint=trace.get('metering'),
        hard_RLIMIT_AS_bytes=trace['hard_limit'],hard_RLIMIT_AS_GiB=trace['hard_limit']/2**30,
        last_checkpoint_process_high_water_RSS_bytes=checkpoint_rss,last_checkpoint_process_high_water_RSS_MiB=checkpoint_rss/2**20,
        external_sampled_peak_RSS_bytes=external_rss,external_sampled_peak_RSS_GiB=external_rss/2**30,
        external_sampled_peak_VMS_bytes=external_vms,external_sampled_peak_VMS_GiB=external_vms/2**30,
        resource_interpretation='RLIMIT_AS limits virtual address space. RSS is resident memory. Self-reported RSS/worker wall are from the last pre-factor checkpoint and are not final process maxima/wall. External sampled peaks are separate observed sampler measurements.',
        completion_scope='No root/profile completion, state query, candidate frontier, request or complete-Q4 cost was recorded. The last checkpoint identifies factor_or_precond_init; no unrecorded cause is inferred.'),
    explicit_D_preflight=dict(**preflight,minimum_pool_and_weights_GiB=17*m/2**30,
        count_reason='17*M bytes = two int32 endpoint arrays + one bool flip array + one int64 weight array',
        empirical_status='not started; this is a representation-specific preflight result, not an observed execution OOM'),
    planned_followup_gates=stages['stages'][1:],followup_status_counts=dict(Counter(r['status'] for r in stages['stages'][1:])),
    full_catalog_scale_query_sample='not available because no scale query was executed',
    claims_not_supported=['completed scale service cost','scale speedup','scale query/candidate numerical certification'],
    raw_trace=str(trace_path.resolve()),raw_job=str(job_path.resolve()),stage_summary=str((V2/'raw_b/STAGE_RESULTS.json').resolve()),
    input_files_sha256=files)
changed=[p for p,r in files.items() if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=r['sha256']]
result['input_files_changed_during_bookkeeping']=changed
if changed:
    result['status']='input_changed_during_bookkeeping'
output=OUT/'b_bookkeeping.json'
with output.open('x',encoding='utf-8') as handle:json.dump(result,handle,ensure_ascii=False,indent=2);handle.write('\n')
text='\n'.join([
    'J-CERT+ V2 尺度尝试：现有记录核算（2026-11-26）','',
    f'状态：{result["status"]}。不执行数值 replay，也不重跑任何实验。',
    f'Slashdot n={spec["n"]:,}，逻辑目录 M={m:,}。',
    f'B1/H 根准备结果 timeout；进程墙时 {trace["process_wall_seconds"]:.9f} 秒，预定上限 {job["seconds"]} 秒，returncode={trace["returncode"]}。',
    '最后保存阶段为 factor_or_precond_init；没有请求、决策或接受动作，没有完整服务成本。未记录的失败原因不推断。',
    f'RLIMIT_AS={limit:,} bytes（{limit/2**30:.3f} GiB）限制虚拟地址空间。',
    f'外部采样峰值 RSS={external_rss:,} bytes（{external_rss/2**30:.6f} GiB）；峰值 VMS={external_vms:,} bytes（{external_vms/2**30:.6f} GiB）。',
    f'raw.process_peak_rss_bytes={checkpoint_rss:,}，来自 worker_wall_seconds={trace["worker_wall_seconds"]:.9f} 的最后检查点；不是最终 RSS 峰值或600秒完整进程时长。',
    f'D 显式表示预检最少17M={17*m:,} bytes（{17*m/2**30:.6f} GiB），高于4GiB限制；另有 M<2^31 的序号容量条件不满足。',
    'D 状态为 not_started_memory_preflight，未启动；不能写成运行时 OOM。',
    'B2 的 H/S 两项及 B3 的 H/S×3 六项均为 not_run_gate_failed，理由是 B1 未完成；共8项保留。',
    '本记录支持尺度根准备在既定预算内未完成，不能支持完整尺度服务成本、加速比或尺度查询数值认证。',
    'raw、job、stage、协议、输入与源码冻结声明均核对；SHA-256 与字段来源完整保存在 b_bookkeeping.json。',
    f'输入在核算中变化：{changed}；核算问题：{issues}。',''])
with (OUT/'b_bookkeeping_zh.txt').open('x',encoding='utf-8') as handle:handle.write(text)
print(json.dumps({'status':result['status'],'issues':issues,'B1_status':trace['status'],'wall_seconds':trace['process_wall_seconds'],
    'external_peak_RSS_GiB':external_rss/2**30,'external_peak_VMS_GiB':external_vms/2**30,'D_minimum_GiB':17*m/2**30,
    'followup_not_run':len(expected_gates),'changed':changed},ensure_ascii=False,indent=2))
raise SystemExit(0 if result['status']=='bookkeeping_verified' else 1)
