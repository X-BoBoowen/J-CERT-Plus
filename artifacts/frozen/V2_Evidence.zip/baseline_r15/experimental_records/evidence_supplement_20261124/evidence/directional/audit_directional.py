#!/usr/bin/env python3
"""Read-only audit of retained directional certificate event logs.

No source modules are imported. No solves, benchmarks, stress experiments, or
figures are run. Python standard library only. All writes go to --out, which
must be outside --source. Recompute ratios from logged radii and check their
construction/selection/pairing against retained code and baseline records.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
import sys
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path

sys.dont_write_bytecode = True

COHORTS = ("alpha", "bio")
WEIGHTS = (1, 4, 16, 64)
TOLS = {"alpha": ("1e-7",), "bio": ("1e-13", "1e-10", "1e-7", "1e-5")}
INITIAL_CANDIDATES = {"alpha": 60, "bio": 72}
METRICS = (
    ("same_input_raw_completed", "same_state_old", "completed"),
    ("same_input_selected", "same_state_old", "radius"),
    ("own_history_policy", "baseline_radius", "radius"),
)
QUALITY_FIELDS = (
    "same_state_old", "completed", "radius", "baseline_radius",
    "posterior", "baseline_gram", "margin", "ratio", "prior",
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def numeric(value):
    if value is None or str(value).strip() == "":
        return None, "missing"
    try:
        x = float(value)
    except (TypeError, ValueError, OverflowError):
        return None, "malformed"
    if not math.isfinite(x):
        return x, "nonfinite"
    return x, "finite"


def exact_integer(value, minimum):
    try:
        x = Decimal(str(value))
        if not x.is_finite() or x != x.to_integral_value() or x < minimum:
            return None
        return int(x)
    except (InvalidOperation, ValueError, TypeError):
        return None


def tolerance(value):
    try:
        x = Decimal(str(value))
        if not x.is_finite() or x <= 0:
            return None
        return format(x.normalize(), "E").lower()
    except (InvalidOperation, ValueError, TypeError):
        return None


def key_for(row, cohort, *, event=True, expected_weight=None):
    w = exact_integer(row.get("w"), 1)
    t = tolerance(row.get("rtol"))
    epoch = exact_integer(row.get("epoch"), 1)
    edge = exact_integer(row.get("edge"), 0) if event else None
    if w is None or t is None or epoch is None or (event and edge is None):
        return None
    if expected_weight is not None and w != expected_weight:
        return None
    return (cohort, w, t, epoch, edge) if event else (cohort, w, t, epoch)


def numeric_equal(left, right):
    a, sa = numeric(left)
    b, sb = numeric(right)
    return sa == sb == "finite" and a == b


def quantile(values, p):
    """NumPy default linear quantile: index (n - 1) * p."""
    if not values:
        return ""
    a = sorted(values)
    pos = (len(a) - 1) * p
    lo = math.floor(pos)
    hi = math.ceil(pos)
    return a[lo] + (a[hi] - a[lo]) * (pos - lo)


def write_csv(path, rows, fieldnames=None):
    rows = list(rows)
    if fieldnames is None:
        fieldnames = list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


class Inputs:
    def __init__(self, root):
        self.root = root
        self.manifest = {}

    def observe(self, rel):
        path = self.root / rel
        if rel not in self.manifest:
            present = path.is_file()
            self.manifest[rel] = {
                "source_file": rel,
                "present": int(present),
                "bytes": path.stat().st_size if present else "",
                "sha256_before": digest(path) if present else "",
                "csv_data_rows": "",
            }
        return path

    def read(self, rel):
        path = self.observe(rel)
        if not path.is_file():
            return []
        with path.open(encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            rows = []
            for row in reader:
                row["__source"] = rel
                row["__line"] = reader.line_num
                rows.append(row)
        self.manifest[rel]["csv_data_rows"] = len(rows)
        return rows

    def finish(self):
        for rel, item in self.manifest.items():
            path = self.root / rel
            item["sha256_after"] = digest(path) if path.is_file() else ""
            item["unchanged"] = int(
                item["present"] == 1
                and item["sha256_before"] == item["sha256_after"]
            )
        return [self.manifest[k] for k in sorted(self.manifest)]


def make_index(rows, cohort, *, event=True, expected_weight=None):
    idx = defaultdict(list)
    invalid = []
    for r in rows:
        key = key_for(r, cohort, event=event, expected_weight=expected_weight)
        r["__key"] = key
        if key is None:
            invalid.append(r)
        else:
            idx[key].append(r)
    return idx, invalid


def audit_event(row, cohort, w, own_index, baseline_index):
    key = row["__key"]
    matches = baseline_index.get(key, []) if key else []
    baseline = matches[0] if len(matches) == 1 else None
    pair_status = ("invalid_key" if key is None else
                   "duplicate_directional_key" if len(own_index[key]) != 1 else
                   "missing_baseline" if not matches else
                   "duplicate_baseline_key" if len(matches) != 1 else "matched")
    baseline_radius_ok = bool(baseline and numeric_equal(
        row.get("baseline_radius"), baseline.get("radius")))
    baseline_gram_ok = bool(baseline and numeric_equal(
        row.get("baseline_gram"), baseline.get("posterior")))
    old, so = numeric(row.get("same_state_old"))
    completed, sc = numeric(row.get("completed"))
    selected, sr = numeric(row.get("radius"))
    margin, sm = numeric(row.get("margin"))
    logged_ratio, sl = numeric(row.get("ratio"))
    selection_valid = (so == sc == sr == "finite"
                       and old >= 0 and completed >= 0 and selected >= 0)
    min_ok = selection_valid and selected == min(old, completed)
    normalized_valid = (sr == sm == sl == "finite" and margin > 0)
    normalized_ok = normalized_valid and logged_ratio == selected / margin
    out = {
        "cohort": cohort, "weight": w,
        "rtol_key": key[2] if key else tolerance(row.get("rtol")) or "INVALID",
        "epoch": row.get("epoch", ""), "edge": row.get("edge", ""),
        "source_file": row["__source"], "source_csv_line": row["__line"],
        "key_valid": int(key is not None),
        "directional_key_unique": int(key is not None and len(own_index[key]) == 1),
        "pair_status": pair_status,
        "baseline_source_file": baseline["__source"] if baseline else "",
        "baseline_csv_line": baseline["__line"] if baseline else "",
    }
    out.update({f: row.get(f, "") for f in QUALITY_FIELDS})
    out.update({
        "baseline_source_radius": baseline.get("radius", "") if baseline else "",
        "baseline_source_posterior": baseline.get("posterior", "") if baseline else "",
        "embedded_baseline_radius_exact": int(baseline_radius_ok),
        "embedded_baseline_gram_exact": int(baseline_gram_ok),
        "selection_inputs_valid": int(selection_valid),
        "radius_is_min_exact": int(min_ok),
        "completed_vs_old": ("lt" if completed < old else "gt" if completed > old else "eq")
            if selection_valid else "invalid",
        "normalized_ratio_inputs_valid": int(normalized_valid),
        "logged_ratio_is_radius_over_margin_exact": int(normalized_ok),
        "old_equals_own_history_baseline": int(numeric_equal(row.get("same_state_old"), row.get("baseline_radius"))),
        "posterior_equals_own_history_baseline": int(numeric_equal(row.get("posterior"), row.get("baseline_gram"))),
        "directional_age": row.get("age", ""),
        "baseline_age": baseline.get("age", "") if baseline else "",
        "ages_equal": int(bool(baseline) and row.get("age") == baseline.get("age")),
        "baseline_margin_exact": int(bool(baseline) and numeric_equal(row.get("margin"), baseline.get("margin"))),
        "baseline_true_gain_exact": int(bool(baseline) and numeric_equal(row.get("true_gain"), baseline.get("true_gain"))),
        "baseline_winner_exact": int(bool(baseline) and row.get("winner") == baseline.get("winner")),
    })
    for name, numerator, denominator in METRICS:
        a, sa = numeric(row.get(numerator))
        b, sb = numeric(row.get(denominator))
        reasons = []
        if key is None:
            reasons.append("invalid_key")
        elif len(own_index[key]) != 1:
            reasons.append("duplicate_directional_key")
        if sa != "finite":
            reasons.append("numerator_" + sa)
        elif a < 0:
            reasons.append("numerator_negative")
        if sb != "finite":
            reasons.append("denominator_" + sb)
        elif b <= 0:
            reasons.append("denominator_zero" if b == 0 else "denominator_negative")
        if name == "own_history_policy":
            if pair_status != "matched":
                reasons.append("baseline_pair_" + pair_status)
            elif not baseline_radius_ok:
                reasons.append("embedded_baseline_radius_mismatch")
        value = ""
        if not reasons:
            value = a / b
            if not math.isfinite(value):
                reasons.append("ratio_nonfinite")
                value = ""
        out[name + "_status"] = ";".join(reasons) if reasons else "valid"
        out[name + "_ratio"] = value
    return out


def summary_rows(events, cohort, w, group, tol):
    result = []
    for name, numerator, denominator in METRICS:
        values = [r[name + "_ratio"] for r in events if r[name + "_status"] == "valid"]
        reasons = Counter(reason for r in events if r[name + "_status"] != "valid"
                          for reason in r[name + "_status"].split(";"))
        row = {
            "cohort": cohort, "weight": w, "aggregation": group, "rtol": tol,
            "metric": name, "numerator": numerator, "denominator": denominator,
            "n_events": len(events), "n_valid": len(values),
            "n_invalid": len(events) - len(values),
        }
        for side, field in (("num", numerator), ("den", denominator)):
            ns = [numeric(r.get(field)) for r in events]
            for status in ("missing", "malformed", "nonfinite"):
                row[side + "_" + status + "_n"] = sum(s == status for _, s in ns)
            row[side + "_negative_n"] = sum(s == "finite" and x < 0 for x, s in ns)
            row[side + "_zero_n"] = sum(s == "finite" and x == 0 for x, s in ns)
        row.update({
            "invalid_key_n": sum(r["key_valid"] == 0 for r in events),
            "duplicate_directional_key_rows": sum(r["key_valid"] == 1 and r["directional_key_unique"] == 0 for r in events),
            "unmatched_or_ambiguous_baseline_rows": sum(r["pair_status"] != "matched" for r in events),
            "ratio_lt_1_n": sum(v < 1 for v in values),
            "ratio_eq_1_n": sum(v == 1 for v in values),
            "ratio_gt_1_n": sum(v > 1 for v in values),
            "ratio_p05": quantile(values, .05),
            "ratio_p25": quantile(values, .25),
            "ratio_median": statistics.median(values) if values else "",
            "ratio_p75": quantile(values, .75),
            "ratio_p95": quantile(values, .95),
            "invalid_reason_counts_json": json.dumps(dict(sorted(reasons.items())), sort_keys=True),
        })
        result.append(row)
    return result


def quality_rows(events, cohort, w, group, tol):
    result = []
    for field in QUALITY_FIELDS:
        vals = [numeric(r.get(field)) for r in events]
        result.append({
            "cohort": cohort, "weight": w, "aggregation": group, "rtol": tol,
            "field": field, "n_events": len(events),
            "missing_n": sum(s == "missing" for _, s in vals),
            "malformed_n": sum(s == "malformed" for _, s in vals),
            "nonfinite_n": sum(s == "nonfinite" for _, s in vals),
            "negative_n": sum(s == "finite" and x < 0 for x, s in vals),
            "zero_n": sum(s == "finite" and x == 0 for x, s in vals),
            "positive_n": sum(s == "finite" and x > 0 for x, s in vals),
            "role": "optional a-priori field; never a ratio exclusion" if field == "prior" else "audit field",
        })
    return result


def run_alignment(cohort, w, tol, events, dir_steps, base_steps, grids):
    # Verify complete candidate populations and winner identity without solving.
    selected = [r for r in events if r["__key"] and r["__key"][2] == tol]
    epochs = defaultdict(list)
    for r in selected:
        epochs[r["__key"][3]].append(r)
    own, own_bad = make_index(dir_steps, cohort, event=False, expected_weight=w)
    base, _ = make_index(base_steps, cohort, event=False)
    own_run = {k: v for k, v in own.items() if k[1:3] == (w, tol)}
    base_run = {k: v for k, v in base.items() if k[1:3] == (w, tol)}
    last_epoch = max(epochs, default=0)
    active = set(range(INITIAL_CANDIDATES[cohort]))
    population_errors = winner_errors = step_pair_errors = 0
    for epoch in range(1, last_epoch + 1):
        rows = epochs.get(epoch, [])
        edges = [r["__key"][4] for r in rows]
        if len(edges) != len(active) or set(edges) != active:
            population_errors += 1
        winners = [r["__key"][4] for r in rows if r.get("winner") == "1"]
        skey = (cohort, w, tol, epoch)
        ds, bs = own.get(skey, []), base.get(skey, [])
        if len(ds) != 1 or len(bs) != 1:
            step_pair_errors += 1
            winner_errors += 1
        else:
            dwin = exact_integer(ds[0].get("winner"), 0)
            bwin = exact_integer(bs[0].get("winner"), 0)
            if dwin != bwin:
                step_pair_errors += 1
            if winners != [dwin] or dwin not in active:
                winner_errors += 1
        if len(winners) == 1:
            active.discard(winners[0])
    grid_rows = [r for r in grids if tolerance(r.get("rtol")) == tol]
    accepted = [exact_integer(r.get("accepted"), 0) for r in grid_rows]
    max_accepted = max((x for x in accepted if x is not None), default=None)
    expected_rows = sum(INITIAL_CANDIDATES[cohort] - (e - 1)
                        for e in range(1, last_epoch + 1))
    return {
        "cohort": cohort, "weight": w, "rtol": tol,
        "initial_candidates": INITIAL_CANDIDATES[cohort],
        "event_epochs": len(epochs), "max_event_epoch": last_epoch,
        "n_events": len(selected), "expected_events_through_last_epoch": expected_rows,
        "event_count_matches": int(len(selected) == expected_rows and last_epoch > 0),
        "epoch_sequence_contiguous": int(set(epochs) == set(range(1, last_epoch + 1)) and last_epoch > 0),
        "candidate_population_errors": population_errors,
        "event_winner_errors": winner_errors,
        "baseline_directional_step_errors": step_pair_errors,
        "directional_step_rows": sum(map(len, own_run.values())),
        "baseline_step_rows": sum(map(len, base_run.values())),
        "directional_step_invalid_key_rows_in_file": len(own_bad),
        "step_key_sets_match": int(set(own_run) == set(base_run) == {(cohort, w, tol, e) for e in epochs}),
        "grid_rows": len(grid_rows), "grid_max_accepted": max_accepted if max_accepted is not None else "",
        "grid_accepted_matches_event_epochs": int(max_accepted == last_epoch and bool(grid_rows)),
    }


def source_locations(inputs):
    specifications = [
        ("tools/flip_stress.py", "completed_square_formula", "    def completed(", "        return center, rad, rho"),
        ("tools/flip_stress.py", "same_input_normwise_and_completed_and_min", "    def scores(", "        return score, radius"),
        ("tools/flip_stress.py", "stop_branch_has_no_candidate_events", "        if max(truth+rc) <= 0:", "            break"),
        ("tools/flip_stress.py", "initial_score_and_event_record", "        z, rho = cg_blocks(s[:, None], tol, 1)", "                                  completed=details['directional'][p],rho_p=details['local'][p])"),
        ("tools/flip_stress.py", "refinement_after_event_record", "        pick, mask = unresolved()", "        assert pick == winner"),
        ("tools/flip_stress.py", "gram_transport_and_min_history", "        carried = E[keep]", "            E = np.minimum(E,newE)"),
        ("tools/directional_stress.py", "independent_policy_runs_and_pairing", "def experiment(", "        events.extend(e)"),
        ("tools/directional_stress.py", "original_figure_ratio_definition", "        for w in WEIGHTS:", "        axes[0].semilogy("),
    ]
    result = []
    for rel, name, start, end in specifications:
        path = inputs.observe(rel)
        lines = path.read_text(encoding="utf-8").splitlines() if path.is_file() else []
        starts = [i for i, s in enumerate(lines) if s.startswith(start)]
        # This marker occurs in the stop branch and positive-gain branch; use
        # the final occurrence for the actual candidate-event recording phase.
        i = starts[-1] if name == "initial_score_and_event_record" and starts else (starts[0] if starts else None)
        j = next((j for j in range(i if i is not None else 0, len(lines))
                  if lines[j].startswith(end)), None)
        result.append({"source_file": rel, "location": name,
                       "line_start": i + 1 if i is not None else "",
                       "line_end": j + 1 if j is not None else "",
                       "markers_found": int(i is not None and j is not None)})
    return result


def build_report(source, out, summary, pairing, alignment, quality, checks, locations):
    lookup = {(r["cohort"], r["weight"], r["aggregation"], r["rtol"], r["metric"]): r for r in summary}
    all_quality = [r for r in quality if r["aggregation"] == "weight_all_retained_tolerances"]
    lines = [
        "R14 独立证据补强：保留方向性事件的同输入诊断", "",
        "范围：仅从 legacy_v6 保留代码与 CSV 复算诊断。没有调用源实验程序、重新求解、压力运行或性能计时。正文与图件未编辑。",
        f"源根目录：{source}", f"本报告目录：{out}", "",
        "1. 事件阶段与总体", "",
        "一个事件是一条候选边在一个已接受动作轮次的首次打分记录。字段在本轮 cg_blocks(..., tol, 1) 和 scores() 后记录，在 unresolved()、状态精化至 2e-14、候选 Gram 重锚以及提交动作之前。",
        "age、posterior、same_state_old、completed 均为这一预精化时点的方向性策略状态。各轮内精化后的半径不再追加到这些事件行。",
        "max(truth+rc)<=0 的停止分支在写 events 前退出，因此停止轮候选不在总体内。预算 b 不是事件键，也不得按多个 grid 预算重复计数。",
        "预先要求保留的组为Alpha/Bio的w=1,4,16,64；Alpha的rtol=1e-7，Bio的rtol=1e-13,1e-10,1e-7,1e-5。各组实际轮数、候选行数和grid接受步数见run_alignment.csv，缺少组也不从输出删除。",
        "候选计数公式为 sum(C-(epoch-1))，C_Alpha=60、C_Bio=72。实际检查还逐轮核对剩余边集合和唯一赢家，见 run_alignment.csv。", "",
        "2. 配对键、有效行与统计分母", "",
        "完整事件键为 (cohort, w, Decimal规范化rtol, epoch, edge)。same-input比较直接在同一CSV行内配对；跨策略比较再按完整键连接 flip_stress_alpha_events.csv 或 flip_stress_events.csv。禁止只按行号或edge连接。",
        "每个倍率的有效行：键可解析且在该方向性事件文件内唯一，分子为有限非负数，分母为有限严格正数，商为有限数。零分子可保留；零分母单列且排除。own_history_policy还要求唯一基线配对及嵌入baseline_radius与源基线radius精确相同。",
        "各倍率的n_valid是中位数/分位数及ratio_lt_1_n等计数的统计总体；n_events为未筛选总体，n_invalid=n_events-n_valid。缺失、非数值、非有限、负数、零分母及键错误逐类列示；多种无效原因可重叠。没有winsorize、挑选最大倍率或按收益/竞争性/年龄/先验资格筛行。",
        "weight_all_retained_tolerances行对该权重全部保留候选事件等权汇总；rtol行另给所有保留容差。重复的汇总层级不能再相加。计算的是逐事件比值的中位数，不是两个半径中位数的比值，也不是run中位数的平均。分位数采用索引(n-1)*p的线性插值。",
        "prior为空仅表示该先验Gram界的条件未满足；不属于本次倍率的缺失分母，也不构成排除条件。", "",
        "3. 三个指标的区别", "",
        "same_input_raw_completed = same_state_old / completed：在方向性策略当前同一个G、E、近似状态z及其残差界rho、h、T上，比较normwise和completed-square两种有限精度半径公式。两种证书使用其各自公式的中心，completed-square中心q由同一近似P=T@H完成平方得到。",
        "same_input_selected = same_state_old / radius：同一状态下比较normwise与实际被选中的半径。源码执行radius=min(same_state_old, completed)，并在completed更小时同步选其中心q。故这个比值>=1是选择规则的结果，不能据此证明原始completed公式对所有输入总是更紧。",
        "own_history_policy = baseline_radius / radius：原图的指标。baseline_radius来自单独运行的normwise策略；radius来自directional=True策略。两策略有相同数据/容差/赢家轨迹，但Gram传输公式、历史误差界及重锚历史可不同。它是两个完整策略在配对候选时点的半径倍率，不能称为固定近似响应/固定误差历史的公式倍率。",
        "completed严格更小的保留行数、相等/更大行数及radius=min(...)核验见 pairing_summary.csv。Gram传输也执行min(normwise,newE)，并同步选择对应Gram中心，因此同输入结果是沿已保留方向性策略历史的诊断；没有把normwise历史上的全部内部响应重新回放。", "",
        "4. 全部权重组，保留全部容差", "",
        "cohort  w  n_events  raw同输入中位数  selected同输入中位数  各自历史策略中位数  raw无效  raw零分母",
    ]
    for co in COHORTS:
        for w in WEIGHTS:
            records = [lookup[(co, w, "weight_all_retained_tolerances", "ALL", m[0])] for m in METRICS]
            lines.append(f"{co}  {w}  {records[0]['n_events']}  " + "  ".join(
                f"{r['ratio_median']:.12g}" if r["ratio_median"] != "" else "NA" for r in records)
                + f"  {records[0]['n_invalid']}  {records[0]['den_zero_n']}")
    lines.extend(["", "5. 全部保留rtol分组", "",
                  "cohort  w  rtol  n_valid(raw)  raw同输入中位数  各自历史策略中位数"])
    for co in COHORTS:
        for w in WEIGHTS:
            for tol in TOLS[co]:
                a = lookup[(co, w, "rtol", tol, "same_input_raw_completed")]
                b = lookup[(co, w, "rtol", tol, "own_history_policy")]
                av = f"{a['ratio_median']:.12g}" if a["ratio_median"] != "" else "NA"
                bv = f"{b['ratio_median']:.12g}" if b["ratio_median"] != "" else "NA"
                lines.append(f"{co}  {w}  {tol}  {a['n_valid']}  {av}  {bv}")
    lines.extend(["", "6. 数据质量、选择规则和历史差异", "",
                  json.dumps(checks, ensure_ascii=False, sort_keys=True, indent=2), "",
                  "cohort  w  completed<old  completed=old  completed>old  min不一致  old与baseline不同  posterior与baseline_gram不同  age不同"])
    for p in pairing:
        lines.append("  ".join(str(p[k]) for k in (
            "cohort", "weight", "completed_lt_old_n", "completed_eq_old_n", "completed_gt_old_n",
            "radius_min_mismatch_n", "old_baseline_radius_different_n",
            "posterior_baseline_gram_different_n", "baseline_directional_age_different_n")))
    lines.extend(["", "可选prior空值（不排除）：" + str(sum(r["missing_n"] for r in all_quality if r["field"] == "prior")),
                  f"本次{checks['n_candidate_events']}行中，completed严格小于old为{checks['completed_strictly_smaller_rows']}行、相等为{checks['completed_equal_rows']}行、更大为{checks['completed_larger_rows']}行；radius=min(old,completed)失败为{checks['selection_min_failures']}行。仅当全部行completed<=old且min核验通过时，raw与selected两个同输入量才逐行相同。",
                  f"首轮候选共{sum(p['epoch1_n'] for p in pairing)}行，其中same_state_old与baseline_radius精确相同为{sum(p['epoch1_old_baseline_exact_n'] for p in pairing)}行。全体old与baseline不同为{sum(p['old_baseline_radius_different_n'] for p in pairing)}行，posterior与baseline_gram不同为{sum(p['posterior_baseline_gram_different_n'] for p in pairing)}行。同赢家轨迹不要求同误差历史。",
                  "上述历史差异可解释同输入与总策略倍率为何不能混用；这是保留字段的关联诊断，未给变化分解赋予因果效应。也不把两种中位数的比值解释成单独历史贡献。", "",
                  "7. 证据定位", ""])
    for loc in locations:
        lines.append(f"{loc['source_file']}:{loc['line_start']}-{loc['line_end']}  {loc['location']}")
    lines.extend(["", "event_audit.csv逐行提供源CSV行号、完整键、配对基线CSV行号、输入字段、三种复算倍率及检查状态。",
                  f"summary.csv包含{len(pairing)}个权重总体与{len(alignment)}个rtol分组，每组3个指标，共{len(summary)}行；field_quality.csv把可选先验空值和关键半径数据质量分开。",
                  "source_manifest.csv记录实际读取的代码/数据SHA-256、大小、CSV行数及运行前后哈希；source_locations.csv列出代码定位。",
                  f"run_alignment.csv验证{len(alignment)}个保留运行的候选总体、步骤赢家与预算接受步数；pairing_summary.csv保留{len(pairing)}组配对与选择规则计数。", "",
                  "8. 可复跑与解释边界", "",
                  "命令（Python标准库；不导入源目录中的模块）：",
                  f'PYTHONDONTWRITEBYTECODE=1 python3 "{out / "audit_directional.py"}" --source "{source}" --out "{out}"', "",
                  "重算对象是已保存半径的比值、有效分母和配对关系；源事件没有保存每条事件的完整G、h、T、P与残差向量，因此本次没有从矩阵和响应重新构造每个半径，也没有独立重验每条有限精度上界的数学有效性。",
                  "本补强不提供新增耗时、扩展性、加速比或因果性能证据，不替换原图，也不把最大的同输入倍率当作新的主张。两策略的原图比值按原字段重现并另列其语义。",
                  "本报告、CSV及脚本均为新增诊断产物。脚本完成时验证所读源文件的哈希保持一致。", ""])
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True, help="read-only legacy_v6 root")
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    source, out = args.source.resolve(), args.out.resolve()
    if not source.is_dir():
        parser.error("--source must be an existing directory")
    if out == source or source in out.parents:
        parser.error("--out must be outside the source tree")
    out.mkdir(parents=True, exist_ok=True)
    inputs = Inputs(source)
    locations = source_locations(inputs)
    baseline_rows, baseline_indices, baseline_steps = {}, {}, {}
    for co in COHORTS:
        prefix = "flip_stress_alpha" if co == "alpha" else "flip_stress"
        baseline_rows[co] = inputs.read(f"data/{prefix}_events.csv")
        baseline_indices[co], _ = make_index(baseline_rows[co], co)
        baseline_steps[co] = inputs.read(f"data/{prefix}_steps.csv")
    event_audit, summaries, quality, pairing, alignment = [], [], [], [], []
    expected_names = {f"directional_stress_{co}_{w}_events.csv" for co in COHORTS for w in WEIGHTS}
    actual_names = {p.name for p in (source / "data").glob("directional_stress_*_events.csv")}
    unexpected_files = sorted(actual_names - expected_names)
    for co in COHORTS:
        for w in WEIGHTS:
            rel = f"data/directional_stress_{co}_{w}_events.csv"
            rows = inputs.read(rel)
            own_index, own_invalid = make_index(rows, co, expected_weight=w)
            audited = [audit_event(r, co, w, own_index, baseline_indices[co]) for r in rows]
            event_audit.extend(audited)
            dir_steps = inputs.read(f"data/directional_stress_{co}_{w}_steps.csv")
            grids = inputs.read(f"data/directional_stress_{co}_{w}_grid.csv")
            groups = [("weight_all_retained_tolerances", "ALL", audited)]
            observed_tols = {r["rtol_key"] for r in audited if r["rtol_key"] != "INVALID"}
            for tol in sorted(set(TOLS[co]) | observed_tols, key=Decimal):
                groups.append(("rtol", tol, [r for r in audited if r["rtol_key"] == tol]))
                alignment.append(run_alignment(co, w, tol, rows, dir_steps, baseline_steps[co], grids))
            for group, tol, selected in groups:
                summaries.extend(summary_rows(selected, co, w, group, tol))
                quality.extend(quality_rows(selected, co, w, group, tol))
            base_group = [r for r in baseline_rows[co] if exact_integer(r.get("w"), 1) == w]
            base_keys = {k: v for k, v in baseline_indices[co].items() if k[1] == w}
            p = {
                "cohort": co, "weight": w, "directional_source_file": rel,
                "directional_source_present": int((source / rel).is_file()),
                "directional_rows": len(rows), "baseline_rows": len(base_group),
                "directional_invalid_key_rows": len(own_invalid),
                "baseline_invalid_key_rows": sum(r["__key"] is None for r in base_group),
                "directional_duplicate_keys": sum(len(v) > 1 for v in own_index.values()),
                "baseline_duplicate_keys": sum(len(v) > 1 for v in base_keys.values()),
                "unique_matched_rows": sum(r["pair_status"] == "matched" for r in audited),
                "missing_baseline_rows": sum(r["pair_status"] == "missing_baseline" for r in audited),
                "ambiguous_baseline_rows": sum(r["pair_status"] == "duplicate_baseline_key" for r in audited),
                "baseline_rows_without_directional_key": sum(len(v) for k, v in base_keys.items() if k not in own_index),
            }
            for field, label in (
                ("embedded_baseline_radius_exact", "embedded_baseline_radius_mismatch_n"),
                ("embedded_baseline_gram_exact", "embedded_baseline_gram_mismatch_n"),
                ("radius_is_min_exact", "radius_min_mismatch_n"),
                ("logged_ratio_is_radius_over_margin_exact", "stored_margin_ratio_mismatch_n"),
                ("baseline_margin_exact", "baseline_margin_mismatch_n"),
                ("baseline_true_gain_exact", "baseline_true_gain_mismatch_n"),
                ("baseline_winner_exact", "baseline_winner_mismatch_n"),
                ("old_equals_own_history_baseline", "old_baseline_radius_different_n"),
                ("posterior_equals_own_history_baseline", "posterior_baseline_gram_different_n"),
                ("ages_equal", "baseline_directional_age_different_n"),
            ):
                p[label] = sum(r[field] == 0 for r in audited)
            for relation in ("lt", "eq", "gt", "invalid"):
                p[f"completed_{relation}_old_n"] = sum(r["completed_vs_old"] == relation for r in audited)
            p["epoch1_n"] = sum(r["epoch"] == "1" for r in audited)
            p["epoch1_old_baseline_exact_n"] = sum(r["epoch"] == "1" and r["old_equals_own_history_baseline"] == 1 for r in audited)
            pairing.append(p)
    manifest = inputs.finish()
    full_summary = [r for r in summaries if r["aggregation"] == "weight_all_retained_tolerances"]
    checks = {
        "audit_kind": "retained_csv_recalculation_no_experiment_no_timing",
        "n_weight_groups": len(pairing), "n_rtol_runs": len(alignment),
        "n_candidate_events": len(event_audit),
        "n_unique_baseline_matches": sum(r["unique_matched_rows"] for r in pairing),
        "missing_source_files": [r["source_file"] for r in manifest if r["present"] == 0],
        "unexpected_directional_event_files": unexpected_files,
        "source_files_changed_or_missing": [r["source_file"] for r in manifest if r["unchanged"] == 0],
        "source_location_failures": [r["location"] for r in locations if r["markers_found"] == 0],
        "invalid_metric_rows": {m[0]: sum(r["n_invalid"] for r in full_summary if r["metric"] == m[0]) for m in METRICS},
        "zero_denominator_rows": {m[0]: sum(r["den_zero_n"] for r in full_summary if r["metric"] == m[0]) for m in METRICS},
        "completed_strictly_smaller_rows": sum(r["completed_lt_old_n"] for r in pairing),
        "completed_equal_rows": sum(r["completed_eq_old_n"] for r in pairing),
        "completed_larger_rows": sum(r["completed_gt_old_n"] for r in pairing),
        "selection_min_failures": sum(r["radius_min_mismatch_n"] for r in pairing),
        "stored_normalized_ratio_failures": sum(r["stored_margin_ratio_mismatch_n"] for r in pairing),
        "embedded_baseline_radius_failures": sum(r["embedded_baseline_radius_mismatch_n"] for r in pairing),
        "embedded_baseline_gram_failures": sum(r["embedded_baseline_gram_mismatch_n"] for r in pairing),
        "baseline_truth_margin_winner_failures": sum(r[k] for r in pairing for k in ("baseline_margin_mismatch_n", "baseline_true_gain_mismatch_n", "baseline_winner_mismatch_n")),
        "duplicate_event_keys": sum(r["directional_duplicate_keys"] + r["baseline_duplicate_keys"] for r in pairing),
        "unpaired_baseline_rows": sum(r["baseline_rows_without_directional_key"] for r in pairing),
        "run_alignment_failures": sum(
            r["candidate_population_errors"] + r["event_winner_errors"] + r["baseline_directional_step_errors"]
            + (1-r["event_count_matches"]) + (1-r["epoch_sequence_contiguous"])
            + (1-r["step_key_sets_match"]) + (1-r["grid_accepted_matches_event_epochs"])
            for r in alignment),
    }
    fatal_names = ("selection_min_failures", "stored_normalized_ratio_failures", "embedded_baseline_radius_failures",
                   "embedded_baseline_gram_failures", "baseline_truth_margin_winner_failures", "duplicate_event_keys",
                   "unpaired_baseline_rows", "run_alignment_failures")
    checks["passed"] = (not any(checks[k] for k in fatal_names)
                        and not any(checks["invalid_metric_rows"].values())
                        and not any(checks[k] for k in ("missing_source_files", "unexpected_directional_event_files",
                                                       "source_files_changed_or_missing", "source_location_failures")))
    write_csv(out / "summary.csv", summaries)
    write_csv(out / "event_audit.csv", event_audit)
    write_csv(out / "field_quality.csv", quality)
    write_csv(out / "pairing_summary.csv", pairing)
    write_csv(out / "run_alignment.csv", alignment)
    write_csv(out / "source_manifest.csv", manifest)
    write_csv(out / "source_locations.csv", locations)
    (out / "verification.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (out / "REPORT.txt").write_text(build_report(source, out, summaries, pairing, alignment, quality, checks, locations), encoding="utf-8")
    print(json.dumps(checks, ensure_ascii=False, sort_keys=True, indent=2))
    return 0 if checks["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
