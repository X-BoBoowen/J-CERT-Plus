# J-CERT+ V3：代码、依赖与复现入口

## 版本身份

本包是 V2 的诊断／最小对照扩展，不是原样 V2。

- 基线：`4c2c7b7e84c7c03ee56d45453fea6950c94817bd`。
- 实际 H/G 运行：`c6b752630bd8dbe1f9fd296a7ed02f249f834575`。
- 必须同时应用 V2 Code 中的历史 overlay 与原生 `index.so`、`screen.so`；仅 checkout 提交不是完整环境。
- `runtime_delta/V3_Runtime_Delta.bundle` 以该 V2 提交为准确基线；`runtime_delta/V3_Runtime.patch` 是同一差异的审阅副本；`runtime_files/` 给出六个实际修改／新增文件。
- `v3/code/` 是独立物理有理 oracle 和构造检查，不导入生产收益内核。
- 实际环境：Python 3.12.14、NumPy 2.3.5、SciPy 1.17.0、psutil 7.2.2、threadpoolctl 3.6.0、SymPy 1.14.0。完整平台、依赖与源文件映射在 `v3/resumed/protocols/HG_FROZEN.json`。

## 必需原件

下载后缀可以不同，按摘要识别。不得用虚构 fixture 替代缺件。

| 原件 | SHA256 |
| --- | --- |
| J_CERT_Plus_V2_Code_20261126.zip | `4d9d96167fdcaee440aced8b280a36118e0d142bc5d8550707316311d8433dfb` |
| J_CERT_Plus_V2_Evidence_20261126.zip | `1e98f70bef0c22fd2f6d8b528490ab42ceedf75c7427f292d9b58965c86b9fcf` |
| J_CERT_Plus_V2_Inputs_20261126.zip | `b643dde2a09cc5c6866a1295d9923480f53b5a6b426beb2b0c557949e4346308` |
| J_CERT_Plus_PVLDB_Source_20261126.zip（稿件核查） | `1fed7ed8013f77174d782f02d648d61ecc262eb06593091b7ec560e098e4deed` |

本包不重复嵌套历史 ZIP 或大型 NPZ。原件的 CRC、路径、成员字节数与摘要核对保存在 Evidence 的 `v3/resumed/inspection/archive_verification.json`。

## 组合运行树

将本 V3 Code 解压到独立目录，先安全验证并解压 V2 Code 到 `v2_code_package/`。V2 的 overlay 程序验证所有归档成员并拒绝覆盖不同内容。以下原件文件名可换成相同摘要的下载名称。

```sh
git clone v2_code_package/reproduction/RESEARCH_HISTORY_V2.bundle v3_runtime
git -C v3_runtime checkout 4c2c7b7e84c7c03ee56d45453fea6950c94817bd
python v2_code_package/reproduction/overlay_packages.py v3_runtime J_CERT_Plus_V2_Code_20261126.zip J_CERT_Plus_V2_Inputs_20261126.zip J_CERT_Plus_V2_Evidence_20261126.zip
git -C v3_runtime fetch ../runtime_delta/V3_Runtime_Delta.bundle research/v3-value-diagnostics-20261126
git -C v3_runtime checkout --detach c6b752630bd8dbe1f9fd296a7ed02f249f834575
```

overlay 必须先于 V3 checkout。`git bundle verify` 需要准确基线对象已存在。不删除缺失旧 A1 fixture 的检查，也不自行制造它；本轮只验证改动相关路径。

## 实际命令、预算与状态

Evidence 的 `v3/budget_ledger.jsonl` 和 `v3/runs/*/record.json` 保留每个实际子进程的完整命令、工作目录、源码／输入／协议、单线程与 CPU 亲和性、RLIMIT_AS、进程墙钟和退出状态。根调度者串行运行全部数值任务，外层等待不重复计费。

本轮研究计算已停止。下列入口用于准确复现说明，不自动授权新批次、换种子或覆盖原始观察。复现应使用独立输出目录与明确预算；环境不匹配时应保留冻结检查的拒绝，而非删除检查。

### 正式 worker 原命令结构

```sh
python v3/control/resumed_budget_run.py --root v3 --runtime v3_runtime --task hg_00_Alpha_slow_H_r0 --category small_timing --decision 'Reproduce the frozen paired worker' --timeout 180 --memory-gib 2 --binding v3/resumed/protocols/HG_FROZEN.json --cwd /absolute/workspace/v3_runtime -- python -m src.v3_worker --freeze /absolute/workspace/v3/resumed/protocols/HG_FROZEN.json --job 0 --output /absolute/workspace/v3/resumed/raw_hg/00_Alpha_slow_H_r0.json
```

`--root` 必须指向含协议和预算账本的 V3 目录。原任务名或输出存在时拒绝覆盖。job 0–11 的顺序、六条既有流、Q4 和每请求 15 次提交上限都已冻结。主时间保留图读取／准备加实际请求的原口径；进程墙钟和输入绑定另记。含报告开销的原始数字没有被替换。

### 诊断／复核入口

以下脚本位于 `v3/resumed/analysis/`，同样经有上限调度器执行：

- `production_certificate_checks.py --runtime v3_runtime --oracle v3/code/exact_oracle.py --output <new.json>`：174 项微型生产边界检查。weight64 在通用局部入口验证，A2 拒绝该权重的事实单列。
- `alpha_relation_diagnostic.py --workspace <workspace> --protocol <ALPHA_DIAGNOSTIC.json> --output-dir <new-dir> --stage structure`：独立重建真实父状态并执行有限精确置换。既有结果已 exact_equal，本轮未启动第二个数值诊断进程。
- `hg_analyze.py --freeze <HG_FROZEN.json> --raw-dir <raw-dir> --out-dir <new-dir>`：汇总已有记录，不运行服务。
- `check_hg_structure.py --workspace <workspace> --output <new.json>`：独立检查实际版本、合法性及声明见证，不是全目录数值重放。
- `profile_memory_accounting.py --workspace <workspace> --protocol <MEMORY_PROFILE.json> --output <new.json>`：唯一固定流报告成本诊断。报告没有关闭，扣减余量不是无观测计时。

来源分析需要将原 Code／Evidence／Inputs 分别安全解压为 `v2_received/code`、`v2_received/evidence`、`v2_received/inputs`；稿件为 `v2_received/paper`。任务书与冻结选择表已保留。

### 真正归档解压副本验收

```sh
python v3/control/fresh_import_checks.py --runtime /absolute/fresh/v3_runtime --code-root /absolute/fresh/code --freeze /absolute/fresh/code/v3/resumed/protocols/HG_FROZEN.json --output /absolute/new-check-report.json
```

使用同一调度器施加单线程、120 秒／2 GiB 限制。此入口验证全部冻结源码映射，导入生产和独立 checker，运行 17 个独立数学测试方法和 11 个 G 相关方法，不重跑性能批次。实际交付用此流程验证真正 Code ZIP 的解压内容，日志在 Evidence 中。

## 有意未扩展的内容

未改共同收益、残差、传递或平局 resolver；未实现在线组合置换完成器、通用图同构、任意精度平台、共享响应区域系统、GPU 或分布式后端；未补跑 Slashdot。G 内部块对象不是公开认证 API。独立 checker 的非点区间相交检查没有升级成全部端点证明。
