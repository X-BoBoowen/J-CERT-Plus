"""Build and verify compact V3 deliverables; static file operations only."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile


WORKSPACE = Path(__file__).resolve().parents[2]
OUT = WORKSPACE/'delivery_v3_complete'


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()


def record(path, name):
    return dict(path=name, bytes=path.stat().st_size, sha256=sha(path))


def write_archive(path, files, manifest_name, metadata):
    if path.exists():
        raise FileExistsError(path)
    if len(files) != len(set(files)):
        raise ValueError('duplicate destination')
    manifest = dict(metadata, self_excluded=True,
                    members=[record(source,name) for name,source in sorted(files.items())])
    raw_manifest=(json.dumps(manifest,indent=2)+'\n').encode()
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name, source in sorted(files.items()):
            z.write(source,name)
        z.writestr(manifest_name,raw_manifest)
    return record(path,path.name)


def verify_extract(path, manifest_name, destination):
    destination.mkdir(parents=True,exist_ok=False)
    checked=[]
    with zipfile.ZipFile(path) as z:
        if z.testzip() is not None:
            raise ValueError('CRC failure')
        names=z.namelist()
        if len(names)!=len(set(names)):
            raise ValueError('duplicate archive member')
        manifest=json.loads(z.read(manifest_name))
        expected={r['path']:r for r in manifest['members']}
        if set(names)!=set(expected)|{manifest_name}:
            raise ValueError('archive manifest/member mismatch')
        for info in z.infolist():
            name=info.filename
            p=PurePosixPath(name)
            if p.is_absolute() or '..' in p.parts or '\\' in name or ':' in p.parts[0] or info.is_dir() or ((info.external_attr>>16)&0o170000)==0o120000:
                raise ValueError('unsafe member '+name)
            raw=z.read(name)
            if name in expected and (len(raw)!=expected[name]['bytes'] or hashlib.sha256(raw).hexdigest()!=expected[name]['sha256']):
                raise ValueError('member mismatch '+name)
            target=destination.joinpath(*p.parts)
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(raw)
            checked.append(record(target,name))
            if name in expected and checked[-1]!=expected[name]:
                raise ValueError('actual extracted file mismatch '+name)
    return dict(archive=record(path,path.name), CRC='passed', safe_unique_paths=True,
                payload_members=len(expected), all_members=len(checked),
                extracted_member_hashes_verified=True, members=checked,
                extracted_to=str(destination))


def code():
    files={}
    for pattern in ('v3/code/*.py','v3/control/*.py','v3/resumed/analysis/*.py',
                    'v3/resumed/protocols/*.json','v3/spec/*.md'):
        for path in WORKSPACE.glob(pattern):
            files[str(path.relative_to(WORKSPACE))]=path
    for name in ('README_V3_REPRODUCE.md','PROTOCOL.json','PROTOCOL_AMENDMENT_01.json'):
        files['v3/'+name]=WORKSPACE/'v3'/name
    for name in ('state_selection_proposal.json','G_COVERAGE_NOTE.md'):
        relative='v3/resumed/reports/'+name
        files[relative]=WORKSPACE/relative
    for name in ('src/a2_checker.py','src/a2_session.py','src/g_access.py','src/v3_worker.py',
                 'tests/test_v3_g.py','tests/test_v3_g_rejections.py'):
        files['runtime_files/'+name]=WORKSPACE/'v3_runtime'/name
    for path in (OUT/'runtime_delta').iterdir():
        files['runtime_delta/'+path.name]=path
    freeze=json.loads((WORKSPACE/'v3/resumed/protocols/HG_FROZEN.json').read_text())
    meta=dict(schema='jcert-v3-code-delta-1',runtime_commit=freeze['runtime_commit'],
              v2_baseline_commit=freeze['v2_baseline_commit'],environment=freeze['environment'],
              code_scope='V3 runtime delta plus independent diagnostics; exact V2 packages required as documented')
    write_archive(OUT/'V3_Code.zip',files,'MANIFEST_V3_CODE.json',meta)
    checked=verify_extract(OUT/'V3_Code.zip','MANIFEST_V3_CODE.json',OUT/'fresh/code')
    (WORKSPACE/'v3/resumed/reports/delivery_code_archive_verification.json').write_text(json.dumps(checked,indent=2)+'\n')
    print(json.dumps(checked['archive']|dict(members=checked['all_members'])))


def evidence():
    files={}
    # Avoid a second identical copy of the first A1 analysis tables; the
    # retained attempt1 directory and verified directory both remain complete.
    duplicate_names={'a1_binding.json','a1_decision_ledger.csv','a1_decision_ledger.jsonl',
        'a1_output_manifest.json','a1_report.md','a1_request_ledger.jsonl','a1_stage_costs.csv',
        'a1_state_selection_check.json','a1_summary.json','a1_worker_ledger.jsonl'}
    for folder in ('v3/resumed/protocols','v3/resumed/inspection','v3/resumed/diagnostics',
                   'v3/resumed/raw_hg','v3/resumed/control_attempts','v3/resumed/reports','v3/runs'):
        for path in (WORKSPACE/folder).rglob('*'):
            if not path.is_file() or '__pycache__' in path.parts or path.suffix=='.pyc':
                continue
            if path.parent==WORKSPACE/'v3/resumed/reports' and path.name in duplicate_names:
                continue
            files[str(path.relative_to(WORKSPACE))]=path
    for name in ('budget_ledger.jsonl','PROTOCOL.json','PROTOCOL_AMENDMENT_01.json','CODE_FREEZE.json'):
        files['v3/'+name]=WORKSPACE/'v3'/name
    for name in ('micro_checks.json','block_probe.json','literature_sources.json','bounds_analysis.md','oracle_design.md'):
        files['v3/reports/'+name]=WORKSPACE/'v3/reports'/name
    for path in (WORKSPACE/'v3/spec').glob('*.md'):
        files[str(path.relative_to(WORKSPACE))]=path
    files['V3_Decision_ZH.md']=OUT/'V3_Decision_ZH.md'
    files['README_EVIDENCE.md']=WORKSPACE/'v3/README_EVIDENCE.md'
    meta=dict(schema='jcert-v3-evidence-1',runtime_commit='c6b752630bd8dbe1f9fd296a7ed02f249f834575',
              raw_history_policy='Original V2 packages referenced by hash, not nested or rewritten',
              authoritative_analysis_dirs=['v3/resumed/reports/a1_verified','v3/resumed/reports/hg_verified'],
              superseded_attempts_retained=True)
    write_archive(OUT/'V3_Evidence.zip',files,'MANIFEST_V3_EVIDENCE.json',meta)
    checked=verify_extract(OUT/'V3_Evidence.zip','MANIFEST_V3_EVIDENCE.json',OUT/'fresh/evidence')
    # Keep delivery verification outside the archive it verifies.
    (OUT/'evidence_archive_verification.json').write_text(json.dumps(checked,indent=2)+'\n')
    print(json.dumps(checked['archive']|dict(members=checked['all_members'])))


def manifest():
    codecheck=json.loads((WORKSPACE/'v3/resumed/reports/delivery_code_archive_verification.json').read_text())
    evcheck=json.loads((OUT/'evidence_archive_verification.json').read_text())
    frozen=json.loads((WORKSPACE/'v3/resumed/protocols/HG_FROZEN.json').read_text())
    budget=[json.loads(x) for x in (WORKSPACE/'v3/budget_ledger.jsonl').read_text().splitlines()]
    report=dict(schema='jcert-v3-delivery-manifest-2',self_excluded=True,
        v2_baseline_commit=frozen['v2_baseline_commit'],actual_runtime_commit=frozen['runtime_commit'],
        actual_runtime_source_digest=frozen['source_digest'],environment=frozen['environment'],
        packages=[record(OUT/name,name) for name in ('V3_Decision_ZH.md','V3_Evidence.zip','V3_Code.zip')],
        archive_members={'V3_Code.zip':codecheck['members'],'V3_Evidence.zip':evcheck['members']},
        archive_validation=dict(code_CRC=codecheck['CRC'],evidence_CRC=evcheck['CRC'],
            both_safe_unique_paths=True,both_actual_extracted_payloads_verified=True),
        runtime_delivery_checks=json.loads((WORKSPACE/'v3/resumed/reports/delivery_runtime_checks.json').read_text()),
        original_package_bindings=json.loads((WORKSPACE/'v3/resumed/inspection/archive_verification.json').read_text()),
        frozen_protocols={str(p.relative_to(WORKSPACE)):sha(p) for p in (WORKSPACE/'v3/resumed/protocols').glob('*.json')},
        scientific_decision=json.loads((WORKSPACE/'v3/resumed/reports/FINAL_RESEARCH_DECISION.json').read_text()),
        numeric_budget=dict(cap_seconds=10800,charged_process_wall_seconds=sum(r['wall_seconds'] for r in budget),
                            ledger_sha256=sha(WORKSPACE/'v3/budget_ledger.jsonl')),
        bundle_and_patch=[record(p,str(p.relative_to(OUT))) for p in (OUT/'runtime_delta').iterdir()])
    target=OUT/'V3_Delivery_Manifest.json'
    target.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(record(target,target.name)))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('part',choices=('code','evidence','manifest'))
    {'code':code,'evidence':evidence,'manifest':manifest}[p.parse_args().part]()
