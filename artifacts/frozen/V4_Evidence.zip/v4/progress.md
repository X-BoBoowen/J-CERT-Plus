# SDD ledger — plan: /workspace/scratch/faa1a8a62f06/v4/spec/V4_USER_PLAN.md

## Scope and pre-flight

- Executor: root performs implementation and is the sole numerical scheduler. Two agents perform independent static baseline and analysis-design work only; a fresh whole-branch reviewer will inspect the completed implementation before formal freeze.
- Baseline: exact V2 4c2c7b7 plus V3 c6b7526; isolated sibling Git worktree v4_runtime. Five source packages and 176 frozen source members match; graph/opinion inputs and environment match V3.
- Pre-flight Task 1→2: full overlay/native inputs are required, not merely a Git checkout. Verified and copied exact missing overlay/input members into the isolated tree.
- Pre-flight Task 2→3: both policies must retain the same nonmeasurement semantics; comparator will use a fixed, explicit exclusion schema and preserve integer values without binary64 conversion.
- Pre-flight Task 3→4: four diagnostic workers must pass before formal freeze. Formal execution cannot accept a changed runtime commit.
- Pre-flight Task 4→5: implementation selection needs all five complete cells with three paired repeats; partial Alpha stays outside full-Q4 ratios.
- Ruling: interpret “波动跨越门槛” conservatively using each complete five-cell repeat's ratio-of-sums R_r. Select G only if the user's base G rule holds and all three R_r>=1.10; call H engineering-superior only if its base rule holds and all three R_r<=10/11. Otherwise retain H default. This resolves an undefined stability criterion before observing V4 times; if overly conservative it can miss a small genuine advantage, not manufacture one.
- Ruling: the user's explicit targeted-test and numerical-budget restrictions override generic skill full-history-suite suggestions. Run the named policy tests and relevant existing tiny G checks only, charging all numerical processes. Risk: untouched historical paths are not revalidated; no such claim is made.
- Ruling: complete the whole-branch code review before formal source freeze, because a later runtime repair must terminate the formal batch under the user's rule. Later reporting and packaging may change independently of the frozen runtime.
- Ruling: preserve protocol, failure and review evidence in V4 delivery; do not delete audit records under generic workspace cleanup guidance.

## Tasks

- Task 1: complete; source/input/environment bindings and independent static deep-call audit passed; eight existing G micro tests passed.
- Task 2: complete at runtime 9d09794b6a6de8a4c97f615abf3f3cae1f458b75; seven targeted policy tests passed after recorded RED checks. Fresh whole-branch review found no runtime repair. Positive diagnostic evidence gate was added outside the runtime and tested RED→GREEN.
- Task 3: complete; exactly four frozen Alpha/slow workers, each full Q4 with 60 accepts. Same-method old/new logged semantics and actual final-cache/factor digests match. All named light deep-call counts are explicitly zero; historical same-method logged projections also match. Report: reports/semantic_invariance.json.
- Task 4: complete; all 36 predeclared light_v1 workers retained, all three exact same-method repeat gates passed. Thirty complete Q4 workers, six known unresolved workers; 138/144 requests complete and 2,088 accepted-record observations. No replacements or adaptive repeats.
- Task 5: scientific choice closed: retain H default under the preregistered stability guard. G passes the aggregate/cell base rule (R=1.143582592916817) but repeat 0 aggregate is 1.0647354480169817, below 1.10. This is not an H performance-superiority claim. Local manuscript revisions and actual archive acceptance remain; no further method experiments.

## Delivery acceptance and final closure

- Actual V4_Code.zip freshly extracted; V2 and V3 original code archives freshly CRC/member-hash checked and Git bundle chain reconstructed to 9d09794. All 178 runtime and nine analysis frozen source members match. Six related imports and 18 targeted test methods passed. No formal rerun.
- Total recorded numerical child wall: 88.07151720400361 seconds of 1,200; all 56 attempts including four intentional RED checks retained. Method experiment remains closed.
- Final local English revisions completed in reports/paper_revisions.md. Chinese decision and final manifest retain separate observation, stability-choice and real-data verification scopes.
