# J-CERT+ V4 — 共同轻量计量与最后一轮 H/G 方法选择

本包是计量政策补丁，不是原样 V3。V2/V3 原始记录保持原身份。V4 只改变报告政策和观测字段；H/G 访问逻辑、数值核、resolver、权重、意见、容差及缓存策略不变。

## 准确版本与依赖

- V2：`4c2c7b7e84c7c03ee56d45453fea6950c94817bd`。
- V3：`c6b752630bd8dbe1f9fd296a7ed02f249f834575`。
- V4 实际运行：`9d09794b6a6de8a4c97f615abf3f3cae1f458b75`。
- Python 3.12.14；NumPy 2.3.5；SciPy 1.17.0；psutil 7.2.2；threadpoolctl 3.6.0；SymPy 1.14.0。完整平台及源文件摘要在冻结协议。
- 保留 V2 Code 的 `baseline_r15/` overlay 及原生库；Git checkout 本身不是完整环境。正式 worker 会拒绝源码、输入、依赖、CPU 或硬资源限额与冻结协议不一致。

准确原件及包摘要见 `v4/protocols/BASELINE_BINDING.json`。最小源码恢复使用 V2 Code、V3 Code 与本 V4 Code；实际六流执行还需要 V2 Inputs。对历史语义复核需要原 V3 Evidence 中的十二条原始 worker，V4 Evidence 保留本轮实际使用的对应记录副本。V2 Evidence 的来源绑定保留，不重跑其历史性能。

## 从准确包恢复隔离运行树

先安全解包原件并验证各自内部清单。下例中的路径只是明确的布局，下载后缀可不同，摘要不可不同。所有目标目录必须是新目录。

```sh
git clone v2_code/reproduction/RESEARCH_HISTORY_V2.bundle v4_runtime
git -C v4_runtime checkout --detach 4c2c7b7e84c7c03ee56d45453fea6950c94817bd
python v2_code/reproduction/overlay_packages.py v4_runtime J_CERT_Plus_V2_Code_20261126.zip J_CERT_Plus_V2_Inputs_20261126.zip
git -C v4_runtime fetch ../v3_code/runtime_delta/V3_Runtime_Delta.bundle research/v3-value-diagnostics-20261126
git -C v4_runtime checkout --detach c6b752630bd8dbe1f9fd296a7ed02f249f834575
git -C v4_runtime fetch ../v4_code/runtime_delta/V4_Runtime_Delta.bundle research/v4-measurement-20261126
git -C v4_runtime checkout --detach 9d09794b6a6de8a4c97f615abf3f3cae1f458b75
```

V4 的 `runtime_delta/V4_Runtime.patch` 是供审阅的同一差异；`runtime_files/` 包含六个实际修改／新增文件。Git bundle 与补丁是两种恢复方式，不要把已应用的补丁再应用一次。`v4/analysis/` 是精确日志投影、证据门槛与汇总代码；诊断摘要遍历只在四个诊断 worker 中启用。

## 计量合同

`A2Session(..., measurement_policy="legacy_deep")` 保留原行为。正式比较显式使用 `light_v1`，仅在共同 request begin/version open/version finish/request end 读取固定数量的长度、数组载荷和既有计数。未知政策拒绝。未测深层字节值／旧水位记为 `null`，不是 0。

主成本是图读取／结构准备加四个实际请求的完整墙钟。意见／来源验证、整个进程墙钟另列；求解计时是阶段内重叠观测，不能再加到总成本。未完成 worker 的返回请求／准备成本是部分工作，不是完整 Q4。

RSS/VMS 是监督器每 100 ms 的采样最大值；worker `ru_maxrss` 覆盖其最后一次读取之前，不能保证包括最后 JSON 序列化的峰值。数组载荷、容器条目数、共享载荷与进程内存不能互相替代或相加称独占峰值。

## 实际命令与一次性执行规则

以下是实际命令结构，原始命令及结果在预算账本和 `runs/` 中。本轮研究执行结束后不得把这些命令视为自动授权的新批次。全部命令须使用新目的地，并保留正式输入、顺序、约束及源码检查。

```sh
python v4/control/budget_run.py --root v4 --runtime v4_runtime --task hg_light_00_Alpha_slow_H_r0 --category formal --decision 'Prespecified paired H/G cost' --timeout 180 --memory-gib 2 --binding v4/protocols/HG_LIGHT_FROZEN.json --cwd /absolute/workspace/v4_runtime -- python -m src.v3_worker --freeze /absolute/workspace/v4/protocols/HG_LIGHT_FROZEN.json --job 0 --output /absolute/workspace/v4/raw_hg_light/00_Alpha_slow_H_r0.json
```

`control/run_frozen_batch.py --workspace /absolute/workspace` 依冻结顺序串行调度，不覆盖已启动的尝试；第一重复行为门槛失败则不进入后续重复。已经完整通过的第一重复不依据速度决定是否继续。原始冻结协议不能重新生成后冒称原协议。

仅从记录复算：`analysis/verify_formal_repeat.py --workspace ... --repeat 0`（及 1、2）要求新门槛输出路径；`analysis/summarize_hg_light.py --workspace ...` 输出完整／部分成本、门槛和固定工程选择。所有数值检查和记录分析均通过预算调度器收费。

## 改动相关检查与实际归档验收

政策测试必须显式指向外部比较器：

```sh
V4_ANALYSIS_ROOT=/absolute/workspace/v4/analysis python -m unittest discover -s tests -p test_measurement_policy.py -v
V3_ORACLE=/absolute/v3_code/v3/code/exact_oracle.py python -m unittest discover -s tests -p test_v3_g.py -v
```

这些命令也必须置于单线程、120 秒／2 GiB 的预算调度器内。不能从环境变量缺失的测试失败推断生产数值错误。V4 独立归档验收另运行诊断证据门槛和固定选择规则的微型测试；精确方法数、结果和累计预算见实际验收报告，不用断言数充作独立样本。

验收不重跑正式批次，不重跑历史完整测试，不伪造旧缺失 fixture。真实 Alpha 的整数置换关系沿用 V3 归档；本轮没有新的真实全目录数值重放。四个诊断的最终缓存摘要不观察所有中间缓存及局部集合内容。
