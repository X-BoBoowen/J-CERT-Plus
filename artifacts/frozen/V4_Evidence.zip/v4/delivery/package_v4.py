"""Build small V4 packages and verify actual ZIPs in fresh directories."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import zipfile


def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def build_zip(target,files,manifest_name,metadata):
    if target.exists():raise FileExistsError(target)
    members=[dict(path=rel,bytes=path.stat().st_size,sha256=sha(path)) for rel,path in sorted(files.items())]
    manifest=dict(**metadata,members=members,manifest_self_excluded=True)
    target.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for rel,path in sorted(files.items()):z.write(path,rel)
        z.writestr(manifest_name,json.dumps(manifest,indent=2)+'\n')
    return dict(path=str(target),bytes=target.stat().st_size,sha256=sha(target),payload_members=len(members))


def verify_extract(archive,destination):
    destination.mkdir(parents=True,exist_ok=False)
    with zipfile.ZipFile(archive) as z:
        infos=z.infolist();names=[i.filename for i in infos]
        if len(names)!=len(set(names)):raise ValueError('duplicate archive members')
        manifests=[name for name in names if name.startswith('MANIFEST_V4_') and name.endswith('.json')]
        if len(manifests)!=1:raise ValueError('one V4 member manifest required')
        bad=z.testzip()
        if bad is not None:raise ValueError('CRC failure '+bad)
        manifest=json.loads(z.read(manifests[0]));expected={e['path']:e for e in manifest['members']}
        if set(names)!=set(expected)|set(manifests):raise ValueError('manifest coverage mismatch')
        verified=[]
        for info in infos:
            name=info.filename;p=PurePosixPath(name)
            if p.is_absolute() or '..' in p.parts or '\\' in name or ':' in p.parts[0] or info.is_dir() or ((info.external_attr>>16)&0o170000)==0o120000:
                raise ValueError('unsafe member '+name)
            payload=z.read(info);digest=hashlib.sha256(payload).hexdigest()
            if name in expected and (len(payload)!=expected[name]['bytes'] or digest!=expected[name]['sha256']):raise ValueError('member digest '+name)
            target=destination.joinpath(*p.parts);target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as f:f.write(payload)
            if sha(target)!=digest:raise ValueError('actual extracted member mismatch '+name)
            verified.append(dict(path=name,bytes=len(payload),sha256=digest))
    return dict(archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),
        fresh_destination=str(destination),CRC='passed',paths='passed',member_hashes='passed',
        members_verified=len(verified),members=verified)


def main():
    p=argparse.ArgumentParser();p.add_argument('--workspace',type=Path,required=True)
    p.add_argument('action',choices=('code','evidence','extract'))
    p.add_argument('--archive',type=Path);p.add_argument('--destination',type=Path);p.add_argument('--report',type=Path)
    a=p.parse_args();w=a.workspace.resolve();root=w/'v4';delivery=w/'delivery_v4'
    if a.action=='extract':
        result=verify_extract(a.archive.resolve(),a.destination.resolve())
        if a.report:
            a.report.parent.mkdir(parents=True,exist_ok=True)
            with a.report.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
        print(json.dumps({k:v for k,v in result.items() if k!='members'}));return
    frozen=json.loads((root/'protocols/HG_LIGHT_FROZEN.json').read_text())
    metadata=dict(runtime_commit=frozen['runtime_commit'],v3_baseline_commit=frozen['v3_baseline_commit'],
                  v2_baseline_commit=frozen['v2_baseline_commit'],formal_freeze_sha256=sha(root/'protocols/HG_LIGHT_FROZEN.json'))
    files={}
    if a.action=='code':
        runtime=w/'v4_runtime';delta=delivery/'build/runtime_delta';delta.mkdir(parents=True,exist_ok=True)
        patch=delta/'V4_Runtime.patch';bundle=delta/'V4_Runtime_Delta.bundle'
        if not patch.exists():
            with patch.open('wb') as f:subprocess.run(['git','diff','--binary',frozen['v3_baseline_commit'],frozen['runtime_commit']],cwd=runtime,stdout=f,check=True)
        if not bundle.exists():
            subprocess.run(['git','bundle','create',str(bundle),frozen['v3_baseline_commit']+'..research/v4-measurement-20261126'],cwd=runtime,check=True)
        changed=subprocess.check_output(['git','diff','--name-only',frozen['v3_baseline_commit'],frozen['runtime_commit']],cwd=runtime,text=True).splitlines()
        for rel in changed:files['runtime_files/'+rel]=runtime/rel
        files['runtime_delta/V4_Runtime.patch']=patch;files['runtime_delta/V4_Runtime_Delta.bundle']=bundle
        for folder in ('analysis','control','delivery','protocols','spec'):
            for file in (root/folder).glob('*'):
                if file.is_file() and file.suffix in ('.py','.json','.md'):files[str(file.relative_to(w))]=file
        files['v4/README_V4_REPRODUCE.md']=root/'README_V4_REPRODUCE.md'
        config=root/'RECOMMENDED_CONFIGURATION.json'
        if config.is_file():files[str(config.relative_to(w))]=config
        result=build_zip(delivery/'V4_Code.zip',files,'MANIFEST_V4_CODE.json',metadata)
    else:
        for folder in ('analysis','control','delivery','protocols','spec','raw_invariance','raw_hg_light','reports','runs'):
            for file in (root/folder).rglob('*'):
                if (file.is_file() and '__pycache__' not in file.parts and
                    not file.name.endswith('_draft.md') and file.suffix in ('.py','.json','.jsonl','.md','.csv','.txt')):
                    files[str(file.relative_to(w))]=file
        for rel in ('budget_ledger.jsonl','progress.md','README_V4_REPRODUCE.md','RECOMMENDED_CONFIGURATION.json'):
            file=root/rel
            if file.is_file():files[str(file.relative_to(w))]=file
        # Only actual analysis inputs, never historical archives or NPZ trees.
        for file in (w/'v3/resumed/raw_hg').glob('*.json'):files[str(file.relative_to(w))]=file
        for rel in ('v3/resumed/protocols/HG_FROZEN.json','v3/resumed/reports/hg_verified/hg_summary.json',
                    'v3/resumed/reports/alpha_classification_report.json','v3/resumed/reports/numeric_memory_instrumentation_attribution.md',
                    'v3/resumed/reports/memory_accounting_profile.json'):
            file=w/rel;files[rel]=file
        files['V4_Decision_ZH.md']=delivery/'V4_Decision_ZH.md'
        result=build_zip(delivery/'V4_Evidence.zip',files,'MANIFEST_V4_EVIDENCE.json',metadata)
    print(json.dumps(result))


if __name__=='__main__':main()
