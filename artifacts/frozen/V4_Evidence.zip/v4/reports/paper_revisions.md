# V4: Final Local Manuscript Revisions

**Implementation decision:** retain H as the default and retain G as an independent strong comparison. G has the lower observed aggregate service time, but the fixed repeat-stability condition for changing the default was not met. This completes the bounded method-selection experiment; the next activity is manuscript refinement within the established evidence limits. [E1]

This file supplies four replacement paragraphs, a title and abstract checklist, and a claim-to-evidence map. It does not replace the full manuscript. The numerical results below come from the sealed V4 summary; the historical Alpha explanation retains its V3 provenance.

## 1. Four replacement paragraphs

### P1 — Contribution positioning

J-CERT+ organizes certified decisions by distinguishing the local responses needed to score contenders from the evidence needed to cover the current catalog. Responses can be selectively maintained across accepted edits, while coverage evidence must remain valid for the current version. For uniform-weight nonedge insertions and explicit negative-edge flips, H uses a joint row frontier and G uses flip-first processing with an independent diagonal block cover. Both access paths share the numerical and version contract, including strict positive gain, canonical ordering, and an explicit unresolved outcome. The system contribution is the connection between local response reuse, current catalog coverage, and certified execution, evaluated with complete service costs and stated completion limits. The particular row frontier is one implementation of this contract. [E3]

### P2 — Measurement policy

We compare H and G under the common `light_v1` observation policy. A fixed collection of container lengths, array payload sizes, and existing counters is read within service time. Recursive memory reporting is retained in separately accounted diagnostic workers and disabled in both formal access paths and their shared request reporting. Service time includes graph loading, structural preparation, and all executed request work; process wall time is recorded separately. Four diagnostic Q4 workers on Alpha/slow established exact agreement between the legacy and light policies for each method's retained decision, version, energy, numerical, access, and cache records, including the diagnostic final-cache and factor digests. All three formal repeat gates subsequently passed. These checks compare recorded execution semantics and bindings; this round adds no independent full-catalog numerical replay of the retained real-data requests. Array payloads, container counts, sampled RSS/VMS maxima, and checkpoint-scoped `ru_maxrss` remain separate observations, and unmeasured deep byte counts remain unknown. [E1, E2]

### P3 — Alpha completion boundary

The retained Alpha unresolved event has a specific structural explanation. The archived V3 diagnostic provides the exact permutation \(P=(1869\;3270)(3227\;3481)\), together with exact checks of parent-operator and opinion invariance and conjugacy of the two edited operators. These relations establish equality of the specified candidates' gains. The diagnostic retains `full_decision_verified=false`: it does not independently establish strict positive gain, coverage of all remaining competitors, or the global canonical winner. V4 leaves the resolver unchanged and preserves the unresolved fourth comparison after three accepted edits in Alpha/signed-neighbor/q1. Its repeated observations concern the same retained input state. Thus the candidate equality has a structural explanation, while the corresponding online full decision remains incomplete. [E1, E3]

### P4 — H/G comparison and implementation choice

The fixed comparison uses six previously observed Alpha/OTC opinion streams and three paired repetitions per access path. The five streams completed by both methods yield 15 complete Q4 pairs, with cumulative service times of 21.537746 seconds for H and 18.833572 seconds for G, giving \(R=\sum T_H/\sum T_G=1.143583\). All five per-stream median ratios favor G. G satisfies the aggregate and per-stream conditions of the engineering selection rule, but the three repeat aggregates are 1.064735, 1.187614, and 1.185705; the preregistered requirement that every repeat aggregate reach 1.10 is therefore not met. We retain H as the default under that rule, while reporting G's lower observed aggregate time. The threshold is an engineering decision criterion, with no statistical significance interpretation. The three incomplete Alpha pairs retain their partial costs and progress and do not enter the complete-service ratio. Repetitions on these retained inputs do not provide new-input confirmation. The earlier ratio of 2.407 remains a legacy-policy implementation observation and is not an estimate of an isolated coverage-algorithm gain. [E1, E3]

## 2. Numerical and interpretation ledger

The manuscript paragraphs use rounded display values. The following entries preserve the summary's numerical precision and denominators. [E1]

| Item | Observed value | Interpretation |
| --- | --- | --- |
| Formal workers | 36 recorded; 30 complete Q4; 6 unresolved | No worker is dropped or replaced |
| Request executions | 144 recorded; 138 complete; 6 unresolved | Repetitions do not create additional independent inputs |
| Accepted-record observations | 2,088 | Includes repetition and method duplication |
| Input streams | 6 previously observed; 0 new | Development/regression evidence, with no new-input confirmation |
| Complete Q4 pairs | 15, from 5 streams × 3 repetitions | The denominator of the complete-service comparison |
| Partial pairs | 3, all Alpha/signed-neighbor | Their costs and progress remain separate |
| H complete-service sum | 21.537745645999166 s | Sum over the 15 complete pairs |
| G complete-service sum | 18.833572476007248 s | Same pairs and policy |
| Overall H/G ratio of sums | 1.143582592916817 | Observed full-service ratio under `light_v1` |
| Repeat 0 ratio of sums | 1.0647354480169817 | Below the fixed 1.10 stability threshold |
| Repeat 1 ratio of sums | 1.1876140766013767 | Above that threshold |
| Repeat 2 ratio of sums | 1.1857053819802608 | Above that threshold |
| Positive per-stream median ratios | 5/5 | All complete-stream medians exceed 1; none is below 0.90 |
| Data and semantic gates | Passed | The implementation-selection stability condition is a separate test |
| Final decision | `retain_H_insufficient_or_mixed` | Retain the existing default; no finding that H is faster |

The default decision must be reported together with the observation favoring G. The failed stability condition does not invalidate the measured times or the passed behavior checks. Conversely, the aggregate advantage does not override the frozen stability condition. Per-stream ranges describe the three observed repetitions and are not confidence intervals. [E1]

## 3. Title and abstract checklist

### Title

Recommended title: **J-CERT+: Certified Decisions for Signed Graph Editing**.

- Center the title on the decision contract and signed graph editing. Treat H and G as access implementations within that system.
- Remove claims that the row frontier is the unique effective coverage mechanism.
- Exclude claims of universal completion, negligible observation overhead, or demonstrated billion-candidate full service. V4 does not supply those results.

### Abstract

- State the actual task: choose a legal edit for the current version from the declared full catalog, subject to strict positive gain and canonical ordering.
- Explain the different responsibilities of reusable local responses and current coverage evidence. Both remain subject to certification.
- State the implemented implicit domain: uniform-weight nonedge insertions and explicit negative-edge flips. Preserve the general explicit path without implying that the implicit paths cover arbitrary insertion weights.
- Describe H and G as two independently organized coverage paths under the common numerical and version contract.
- Keep the V4 ratio and the engineering default-selection details in the experiment section. The abstract should not headline either the historical 2.407 ratio or an unqualified G speedup.
- Preserve any earlier valid performance claim only with its original comparison, measurement policy, environment, and scope. V4 supplies no new D/G or Stream/G comparison and cannot be multiplied into historical ratios.
- State the completion boundary accurately: the Alpha candidate equality is structurally explained, and the original online comparison remains unresolved.
- Distinguish the executed behavior checks from independent numerical verification. V4 adds no full-catalog numerical replay of the retained real-data requests and no new input stream.
- Keep static logical catalog size separate from completed large-graph service. This round adds no scale result.
- End with the demonstrated system capability and declared limits. Method selection is closed for this stage; the manuscript should not imply an ongoing search for a favorable frontier, resolver, input, or backend.

## 4. Claim-to-component and evidence map

The rows distinguish retained system claims, a measurement finding, and required qualifications. The observation-policy check is supporting experimental evidence and does not become an additional algorithmic contribution.

| Role | Manuscript statement | Component or obligation | Evidence | Required limit |
| --- | --- | --- | --- | --- |
| Central claim 1 | Local response reuse and current catalog coverage have distinct responsibilities and validity conditions | Shared numerical core, version transmission, current coverage construction | Existing system arguments and implementation; V3 G coverage evidence [E3] | Responses also require certification; this is not a theorem that all coverage must always be recomputed |
| Central claim 2 | Independent access organizations can satisfy the same declared coverage contract, with observable full-service cost differences | H row frontier; G flip-first processing and independent diagonal block cover | V3 coverage checks; V4 complete paired costs and retained partial results [E1, E3] | H is not the only effective path; G is a strong comparison, and the final default remains H by the fixed stability rule |
| Measurement finding | A common bounded observation policy preserves the recorded behavior on the evaluated executions | `legacy_deep`/`light_v1`, exact same-method projections, source/input/resource gates | Four diagnostic workers and all three formal repeat gates [E1, E2] | Scoped empirical agreement, not a proof of identical arbitrary internal states or numerical correctness on every input |
| Completion qualification | The real Alpha candidate relation is explained while the online full decision remains incomplete | Exact parent/opinion invariance and edited-operator conjugacy; unchanged online resolver | Archived V3 equality witness and V4 unresolved observations [E1, E3] | Preserve `full_decision_verified=false`; do not call the unresolved event fixed |
| Attribution qualification | V4 reports new common-policy implementation measurements while preserving the old results' identity | Complete service accounting; separate diagnostic, solver, and resource observations | V4 summary and V3 legacy-policy comparison [E1, E3] | No subtraction-based corrected ratio, isolated algorithmic attribution, cross-environment policy speedup, or unmeasured D/G result |

## 5. Evidence references and closure

- **[E1]** `v4/reports/hg_light_summary.json`: final costs, counts, per-stream and per-repeat results, all three repeat-gate statuses, implementation selection, and interpretation limits. Runtime commit: `9d09794b6a6de8a4c97f615abf3f3cae1f458b75`. Formal protocol digest: `2f1fca19129e2ed0f8032954e0d1175f7c776607399ed85dc2e6904085b57887`.
- **[E2]** `v4/reports/semantic_invariance.json`: the four diagnostic workers, exact same-method policy comparisons, historical same-method comparisons, final-cache/factor digest scope, and absence of new independent numerical replay of the retained real-data requests.
- **[E3]** Retained V3 evidence cited in the earlier manuscript draft: `v3/resumed/reports/alpha_classification_report.json`, `v3/resumed/reports/hg_verified/hg_summary.json`, and the archived `G_COVERAGE_NOTE.md` and corresponding implementation/mechanism checks. V4 does not reclassify or independently rerun that historical evidence.

This revision closes the planned method-selection question without further experiments. H remains the default, G remains a strong independent comparison with a favorable measured aggregate, and the paper proceeds to concentrated refinement under the stated correctness, completion, measurement, and scale limits.
