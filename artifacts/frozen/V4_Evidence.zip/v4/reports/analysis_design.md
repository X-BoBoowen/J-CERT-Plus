# V4 语义比较与预注册分析设计

身份：只读设计审查。未执行数值测试、服务、checker、计时或性能重算；只读取任务书、V3 生产源码与 JSON 结构。本文是正式冻结前的建议，不是 V4 实测结果。根执行者应将采用的规则明确写入冻结文件。

## 1. 必须分开的三种比较

| 比较 | 需要成立的关系 | 不应声称的内容 |
| --- | --- | --- |
| 同一 V4 构建、同一方法、两政策 | H/legacy = H/light；G/legacy = G/light；完整非计时语义，包括已观察缓存内容／引用摘要 | 不能只检查赢家；不能强求 H=G 的所有端点或访问计数 |
| V4 第一正式重复与 V3 同臂记录 | 相同输入、合同、逐请求决定／整数端点／版本／竞争者界／见证／计数，另核对来源和环境 | 历史环境差异不能直接宣布数学错误；差异应停止本批并分类，而非删字段 |
| H 与 G 正式性能配对 | 同输入、同政策、同环境、同完成范围；比较成本与各自工作量 | H/G 既有端点和访问组织不同，不能使用同臂逐位相等门槛 |

V3 worker JSON 的整数收益端点远超 2^53。比较器应使用 Python 的任意精度 JSON 整数；不要通过 JS Number、浮点数组或先格式化舍入再比较。列表顺序、null、字段缺失、真假值与整数类型均应保留语义差异。

## 2. 投影原则：精确排除路径，其余全部保留

先复制完整语义对象，再删除事前登记的**精确路径**。不能按字段后缀、类型、递归名称或实际出现差异后临时删除。未知新增字段默认保留比较，或作为未登记 schema 阻塞；不能默默丢弃。

`requests[*]` 和 `access.epochs[*]` 表示固定 schema 的列表元素，除此之外不使用不受限通配规则。

### Worker 计时字段

可排除以下已存在的计时字段：

```
binding_and_import_seconds
opinion_and_graph_binding_seconds
process_wall_seconds
structural_seconds
structural_phases
service_accounted_seconds
service_plus_input_binding_seconds
complete_service_seconds
partial_work_seconds
prefixes
timing_scope
metering.solve_seconds
metering.factor_attempt_seconds
```

`prefixes` 的值是累计服务秒数，属于计时。`complete_Q4`、`status`、`active_phase` 不属于时间，应保留。失败消息也应保留分类信息，不能因为它含有路径就整体丢弃。

### Worker 资源、来源及任务标签

`process_peak_rss_bytes` 是资源观测，可排除。`environment`、`threadpools`、`enforced_threadpools` 应从数值语义投影中分离，但必须由独立元数据门槛核对各自冻结值、线程数和库身份。不能把“从语义投影排除”写成“无需核对环境”。

`freeze_sha256`、`source_digest`、`actual_runtime_commit`、`declared_runtime_commit` 是两个构建之间必然变化的代码身份，单列与准确冻结提交匹配。

`job.position`、`job.output_file`、`job.repeat_id`、顶层 `repeat_id` 是预定执行身份。不要把任务顺序不同当成语义变化；需分别对冻结调度表核对，然后排除比较。`job.graph/stream/method/requests/budget_per_request` 和 `job.cell_index` 则保留。若 V4 新增 job 的政策／诊断标志，按明确字段名单剥离，仍在元数据门槛中验证。

V3 `fixture` 应整体保留：种子、派生标签、npz/matrix/opinion 摘要和行范围都绑定同一输入。仅当 V4 必须改动纯存储路径时才预先登记 `fixture.file`；不需要改动时不要无故排除。

### 请求级计时字段

```
requests[*].request_seconds
requests[*].wrapper_seconds
requests[*].online_seconds
requests[*].reset_opinion_seconds
requests[*].phases
requests[*].online_phases
requests[*].index_build_phases
requests[*].access.epochs[*].seed_build_phases
requests[*].access.epochs[*].frontier_build_phases
```

这些是已观察 V3 schema 中的计时字典或数值；访问事件的其他字段全部保留，尤其是 `source_complete`、`remaining_upper_coarse`、`cold_start_lower_fine`、`cold_end_lower_fine`、seed 行数、访问计数和 G 整体排除信息。

### 内存树不能直接吞掉缓存工作证据

`requests[*].memory` 中同时混有资源载荷和可用缓存计数。深字节数／高水位／快照可从语义投影排除，但应先独立提取并比较至少：

- `gram_count`：请求结束时剩余 Gram 条目数；
- `peak_gram_count`：已有业务代码维护的最大条目计数；
- `root_factor_reported_nnz`：现有报告读取的根因子 nnz，可作为结构一致性辅助值。

若 light_v1 将这些值放到新 schema，应做**已登记的字段映射**，而不是把缺失解释成 0。每个无法保留的旧资源字段都标为未观测；不为维持旧命名引入新的线性扫描。尤其 `low_rank_steps` 的旧值是遍历 steps 数组载荷的和，资源报告值不应被当成必要数值计数。`len(fac.steps)` 如新政策支持，可另报常数成本条目数，但不能声称它等于旧字节数。

正式投影保留 `requests[*].counters` 的完整字典以及 worker `metering.solve_calls`、`metering.scalar_rhs`。不能仅因名称含 metering 就把整个字典剔除。

### 明确保留的请求和决定字段

请求保留：`root_version_id/current_version_id/opinion_hash/method/budget/delta/status/failure_reason`、`initial_seed_ids/initial_seed_order/seed_rule/initial_gram_count`、`decisions`、`commits`、`gain_low/gain_high/gain_denominator`、`root_energy/final_energy`、全部 `counters`、全部非计时 `access.epochs`、`cache_policy`、`query_position/result_status`。

每条决定完整保留，不做字段剥离，包括：整数 `low/high`、rival/cold/competitor 上界、合法编辑和权重、父子版本、正收益停止／未决、`comparison_resolution` 中的完整等值见证、canonical 源／目标、意见及算子绑定、单位、残差、seed 顺序和实际工作计数。

Alpha 未决项包含 `winner_id=null`、failure_reason、暂定赢家、overlap_ids、两个已保存见证和 unresolved_ids。它必须作为完整终止对象比较；不能只提取前三条 accepted 记录而忽略第四步。

## 3. 诊断缓存内容与引用摘要

V3 原始 worker 只保存计数／内存，不保存完整 `views.entries`、hot/seen/chosen 内容或对象共享关系。因此：

- V4 四个诊断可以附加只在诊断中执行的摘要，用于同一方法两政策比较；
- 第一正式重复对 V3 只能核对原先存在的字段；不能声称原始缓存内容已经独立比对；
- 诊断摘要必须在服务对象清理前取得，诊断费用全部计入；正式 worker 禁止这些遍历。

可支持的最小对象范围：排序的 `views.entries` ID、每项版本与 Gram 内容、hot/seen/chosen 集合、retained/scored_response 的有无和候选 ID、其数组 dtype/shape/精确 bytes、低秩 steps 的序列与数组内容。数组和引用都采用确定性顺序，记录稳定别名组（canonical encounter number），不能比较跨进程的 Python `id()` 地址。所有摘要的范围要明列：不覆盖原生求解器私有内存，也不等同于独立数值证明。

建议区分 `semantic_cache_summary`（两政策都存在并相等）与 `measurement_diagnostics`（深调用数和政策观测计数，预期不同，单列验证）。新增字段必须在四诊断前冻结。

## 4. 冻结选择规则与波动歧义

用户的主判定是：五个原完整单元各有三次有效配对，所有语义／资源／来源门槛通过后，计算

\[
R=\frac{\sum_{i,r} H_{ir}}{\sum_{i,r}G_{ir}},\qquad
r_i=\operatorname{median}_{r=0,1,2}(H_{ir}/G_{ir}).
\]

G 的基本规则：R≥1.10，至少四个 r_i>1，且没有 r_i<0.90。H 的基本规则：R≤10/11，至少四个 r_i<1，且没有 r_i>10/9。严格／非严格端点必须保持任务书定义，不对显示舍入后的数字判定。

任务书另写“波动跨越上述选择门槛”，但没有定义统计量。**建议在任何 V4 时间出现之前作以下保守操作化，并作为明确裁定写入协议：**

1. 每个预定重复，在同一五单元上计算 `R_repeat[r]=sum(H_ir)/sum(G_ir)`。
2. 选择 G 还需 `min(R_repeat)>=1.10`。
3. 将 H 描述为达到工程优势还需 `max(R_repeat)<=10/11`。
4. 基本规则成立而稳定性规则不成立时，保留 H 当前默认，标为 `insufficient_stable_selection_evidence`；不增加重复。

这只是对含糊波动条款的保守判定，不是置信区间或统计显著性。不要额外要求每个单元倍率均≥1.10；那不是用户给定的规则。各单元 min/median/max 仍全部报告，个别跨过 1 的单元由原来的多数／反向退化规则处理。

如果根执行者采用别的规则，应在测量前写明，不能看结果后选择更有利的解释。

## 5. 计数与成本分母

- `candidate_rhs` 是请求角色计数；worker `metering.scalar_rhs` 是所有实际 solve 调用的 RHS 列总量。分别列示，不相互替代。
- `cold_tail_ids` 是送公共端点分类器的冷批次行数，不是所有生成点对，也不是唯一候选数。
- 请求 `counters` 的 `gram_materializations/gram_hits/transfers/score_calls` 按原含义保留。H/G 自身访问字段分别报告，不把行堆 pop 和块展开当同义工作。
- 至少两个计数表：15 个双方完整配对的计数；所有已记录工作（含共同未决）的计数。分母清楚，诊断四 worker 不进入正式合计。
- 主服务 = structural_seconds + 所有实际 request_seconds；V3 的 structural_seconds 已包含图读取。不得再加一次 graph_load。
- metering.solve_seconds、factor_attempt_seconds 与外层阶段重叠，只作为辅助剖析，不能加到主总时间。
- 建议先报告原始独占阶段名及合计。如再分组，明列映射；例如候选准备/访问、数值筛查/评分、传递/缓存都不是理论上的纯成本，只是已命名阶段。
- 只有双方完整 Q4 才有完整服务比值。共同未决不能因前缀一致而变成完成；部分成本不得补算。

## 6. 具体来源

- 任务书：`upload/粘贴的 Markdown (1)(3).md`，任务 2–5。
- `v3_runtime/src/v3_worker.py`：worker schema、计时边界、metering、检查点与状态归并。
- `v3_runtime/src/a2_session.py`：请求／决定／计数／内存字段及清理边界。
- `v3_runtime/src/a2_access.py`、`src/g_access.py`：访问事件及阶段子字典。
- `v3_runtime/src/weighted_adapter.py`：实际 Gram entries／retained／scored_response 结构。
- 原 JSON 结构：`v3/resumed/raw_hg/00_Alpha_slow_H_r0.json`、`01_Alpha_slow_G_r0.json`、`04_Alpha_signed-neighbor_H_r0.json`、`05_Alpha_signed-neighbor_G_r0.json`。
- `v3/resumed/reports/hg_verified/hg_summary.json` 是最终历史汇总；`reports/hg/` 不用作权威结果。
