# V4：V3 基线的观测调用链静态审查

日期：2026-11-26（Asia/Tokyo）  
审查对象：`v3_runtime`，提交 `c6b752630bd8dbe1f9fd296a7ed02f249f834575`。  
权限与范围：只读源码；没有导入生产数值模块、求解、测试、性能进程或源码修改。本文件与同名 JSON 是本审查者唯一写入的文件。源码摘要见同名 JSON。

## 结论

在所查实际 H/G 服务调用链中，深层报告返回值只更新报告快照／报告最大值，并进入返回结果；未发现它们参与候选选择、缓存准入或驱逐、误差包围、精化、tie、终止合同或运行时资源决策。因而可以通过显式共同政策跳过这些报告工作，同时保留原 `legacy_deep` 路径。静态无依赖结论不能替代随后要求的同臂整数结果和非计时工作一致性检查。

除了任务书点名的四类深报告，还存在一个应纳入 `light_v1` 的线性报告扫描：`a2_session.py` 对 `fac.steps` 的逐项字节求和。该求和也仅服务内存报告，轻量分支应不执行；不能因为最多十五步就称其为固定数量的容器字段读取。

## 1. 实际深报告调用与数据去向

以下行号仅定位当前冻结 V3 文件；V4 修改后行号会移动。

| 源码位置 | 调用和工作 | 返回值去向 | 检查出的业务依赖 |
| --- | --- | --- | --- |
| `src/a2_access.py:85,94` | `begin` 在根前沿建立后、付费种子访问后各调用 `observe_frontier` | `frontier_memory`、`max_frontier_bytes` | 未发现 |
| `src/a2_access.py:130` | H `open_version` 后调用 `observe_frontier` | 同上 | 未发现 |
| `src/a2_access.py:190` | H `finish_version` 调用 `observe_frontier` | 同上 | 未发现 |
| `src/a2_access.py:103–107` | `frontier.memory()`，读取 `total_owned_bytes` 更新报告最大值 | 仅报告状态 | 未发现 |
| `src/a2_catalog.py:421–444` | `MixedFrontier.memory` 遍历堆、翻转列表、chosen 和元数据，使用 `_python_size` 与局部 seen 集合 | Access 报告快照 | 未发现 |
| `src/g_access.py:282,305` | G 在 `finish_version` 和请求末 `memory()` 调用 `_observe_memory` | `frontier_memory`、`max_frontier_bytes` | 未发现 |
| `src/g_access.py:285–302` | 遍历 flip_order、已实现块堆和 nodes；临时 seen 集合；数组载荷求和 | G 报告快照 | 未发现 |
| `src/a2_session.py:255` | `self.access.memory()` | 请求结果 `memory` | 未发现 |
| `src/a2_session.py:259` | `self.catalog.memory()` | 请求结果 `memory.sparse_catalog` | 未发现 |
| `src/a2_catalog.py:235–250` | `AllCatalog.memory` 递归遍历 self/W 的字典和 Python 容器 | sparse_catalog 报告 | 未发现 |
| `src/a2_session.py:261` | `lp.store_bytes(views.entries)` | `gram_python_bytes` | 未发现 |
| `src/a2_session.py:262` | `lp.store_bytes` 遍历临时 grams/hot/seen/chosen 字典 | `actual_candidate_cache_python_bytes` | 未发现 |
| `src/a2_session.py:263` | `lp.store_bytes((decisions,access_rows))` | `decision_and_access_log_python_bytes` | 未发现 |
| `src/a2_session.py:227,265–266` | 对所有 `fac.steps` 的 Y／inverse 数组 nbytes 求和；更新 peak_steps；末尾再次求和 | `low_rank_steps`、`peak_low_rank_steps` | 未发现 |

`lp.store_bytes` 位于 `baseline_r15/experimental_records/evidence_supplement_20261124/source/legacy_v6/tools/long_promotion.py:130–145`。它建立局部 seen 集合，递归读取 dict/list/tuple/set 及有理数分子分母，不写入被观察对象。`_python_size` 位于 `src/a2_catalog.py:253–267`，也只递归读取。既有对象都是本地的普通容器／NumPy 数组／有理数，所查路径没有用户自定义回调型容器。

相反，`fac.steps` 本身确实参与求解，`views.entries` 本身确实参与 Gram 缓存和传递；可跳过的是对这些对象的**报告遍历**，不能跳过创建、更新、清理或求解使用。

对 `frontier_memory`、`max_frontier_bytes`、`peak_frontier_owned_bytes`、三项 Python 字节字段和 low_rank 报告字段的检索覆盖 `src/*.py` 及上述 legacy tools。发现的其他读取位于 `a2_figures.py`、`a2_tie_summarize.py`、`a2_final_facts.py` 等离线报告代码；未发现 H/G 服务控制流使用。`src/session.py` 是另一服务路径，不是本次 `A2Session` 的请求入口，不应顺带重构。

## 2. 固定成本轻量观测建议

在共同 `A2Session` 层明确时点更容易避免 H/G 自有旧调用频率不同：

1. `request_begin`：本请求 `access.begin`／付费种子准备已完成之后；定义该阶段名称的精确含义。
2. `version_open`：相应 `open_version` 成功返回之后、正式评分之前。
3. `version_finish`：每次实际完成访问版本的 `finish_version` 返回之后；异常路径保留是否已发生的事实，避免二次重复观测。
4. `request_end`：能量和计数已整理、access.close 及本请求缓存释放之前。

每次只读固定数量的标量、`len`、既有数组 `.nbytes`，或更新固定字段的计数；不要额外计算中心 min/max、排序、求和动态步骤列表或递归对象大小。零预算请求只应有实际发生的 request_begin/end；零停止和未决需据实际 version open/finish 记录。

| 对象 | 允许的常数成本字段示例 | 应避免的做法 |
| --- | --- | --- |
| H 当前／根前沿 | 前沿是否已创建；`len(heap)`、`len(flips)`、flip_position、xc.nbytes、order.nbytes | 遍历 heap/flips/chosen 或 `_python_size`；同时把 root_frontier 和 frontier 相同引用重复相加 |
| G | root_flips、flip_order 的长度；flip_position；blocks 是否已创建；len(blocks.heap)、len(blocks.nodes)；固定几份数组 nbytes | 在 begin 时仅读尚未接管的 flip_order 而漏记 root_flips；遍历 nodes 或块堆；把 shared current_xc 算成独占总内存 |
| 共同目录 | 固定七份已存在数组的载荷；root_edge_ids／positive_ids／flip_ids 的长度；逻辑 m | 调用 AllCatalog.memory；遍历 __dict__／root_edge_keys；将 graph CSR 与共享目录 CSR 再求和称总内存 |
| 缓存与状态 | len(views.entries)、既有 fresh/hits/winner_blocks/transfers；len(hot/seen/chosen)；len(fac.steps) | 遍历所有 Gram、所有低秩步骤或日志来测字节数 |
| 固定响应与 CSR | 已有 response 元组前三份数组 nbytes；图和根算子的各三份 CSR 数组 nbytes | 以载荷之和称精确进程峰值或混算共享对象 |

`max_batch_bytes` 是每个 batch 五份固定数组的载荷最大观测，原更新为固定数量读取；可以保留其原义，但名称与对象范围必须说明。`peak_views` 是 len(views.entries) 的固定成本最大值，也可保留。旧 `peak_frontier_owned_bytes`、三项 Python 深字节和低秩步骤深字节水位，在 light_v1 应为 null 或缺省并说明未测，不能用 0 表示未测。

不存在／尚未构造的容器若逻辑上已知为空，可以报告项数 0，并给出 created=false；这与“没有测量深字节数”是不同情况。所有 payload、容器项数、RSS/VMS 采样和 checkpoint ru_maxrss 分字段；不合成伪精确 total_owned_bytes。

## 3. 业务语义与缓存检查范围

当前原始返回值足以比较：全部决定和未决条目、整数 low/high 与竞争者界、父子版本、等值见证、累计收益、root/final_energy、种子次序／集合、全部 numeric counters、全部 access 事件（仅排除明确计时子字段）。这些字段应逐臂 old/new 比较，不要求 H=G。

`WeightedViews` 的真实业务缓存位于 `src/weighted_adapter.py:47–111`，继承 `promotion.VerifiedGramViews` 的初始化。结构如下：

- `entries`: canonical candidate ID -> `(version, Gram)`；Gram 是 1×1 或 2×2 有理闭区间矩阵；版本由传递维护。
- `fresh/hits/winner_blocks/transfers`: 整数工作计数；不是计量政策字段，应严格比较。
- `scored_response/retained`: 可选 `(candidate ID, (U,Y,X,radius))`；复用响应会影响求解次数，应区分 None 与存在。
- `fac.steps`: `(Y,inverse)` 序列；共同根 `factor.steps` 必须保持空，child copy 的 base 通常引用共同根分解。

若要额外检查诊断期缓存内容，可在独立四 worker 中通过包装 `kernel.views` 捕获真实生成的 view，记录最终 entries 的有序候选、版本及**精确有理分子／分母**摘要；再比较可选 retained/scored_response 的候选 ID、数组 dtype/shape/字节摘要和半径。若包装 `views.advance` 捕获该请求的 fac，可记录 steps 的有序数组摘要及 `fac.base is service.factor.base` 这样的引用关系布尔值。不要比较跨进程 object ID 或地址；也不要通过重算响应生成替代缓存。

这些摘要遍历只能发生在明确标记的独立诊断中，并计入诊断成本。正式 worker 不开启摘要，不为正式结果改变缓存保留政策。捕获对象延长生命周期会改变诊断内存观测，必须说明，不把诊断 RSS 当作正式空间比较。

`hot/seen/chosen` 是 request 局部对象；返回的种子／访问／接受轨迹不能完整证明全部内部集合内容。若没有专门捕获，应报告这些集合只比较现有可见计数／轨迹，未独立逐项比较其内容。也不能仅有最终缓存摘要就声称每个中间状态都已完整逐字节比较。

## 4. 资源与统计边界

现有 `src/v3_worker.py` 每次 checkpoint 读取 `ru_maxrss`，随后写 JSON。这个值覆盖读数之前的进程生命期，不保证覆盖最后一次输出序列化引起的额外峰值。监督器的 100 ms RSS/VMS 是采样最大观测；独立进程与硬 RLIMIT_AS 仍由调度器保证。轻量政策无需每事件重新扫描系统内存。

前沿结构构建、排序、current diagonal 重建、候选筛查及 Gram／低秩数值传递均属于业务工作；不能因包含遍历就归为可删除计量。特别是 G 的当前对角及 PairBlocks 的 `_node_maxdiag` 与算法证明有关，本轮不得改动。

## 5. 审查限制

这是特定冻结源码的静态数据流检查，不是动态调用证明。没有重新执行 V3 测量，没有检查 Alpha 原始矩阵等式，没有新数值结论。最终 V4 必须用深入口抛错／计数测试、四个真实流同臂诊断及正式第一重复回归来补齐动态证据。本审查没有提出新增研究输入或额外正式 worker。
