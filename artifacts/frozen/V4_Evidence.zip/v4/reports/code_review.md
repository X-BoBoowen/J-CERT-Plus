# V4 runtime review and disposition

Reviewer: independent fresh-context agent `/root/v4_code_review`. Static review only; no numerical process.

Reviewed baseline `c6b752630bd8dbe1f9fd296a7ed02f249f834575` → runtime `9d09794b6a6de8a4c97f615abf3f3cae1f458b75`, all six changed/new runtime files, and the external exact semantic comparator.

Verdict: runtime approved for the four authorized diagnostics, with formal measurement conditional on their positive evidence. No critical finding and no requested runtime repair. Reporting guards leave the decision, factor update, access counters and pruning proof paths intact. Lightweight observations use a fixed set of lengths, named payloads and counters. The comparator preserves unknown fields and arbitrary-precision integer endpoints.

## Important finding and resolution

Equality by itself can pass for two truncated workers or for two workers both missing cache audits. The projection deliberately excludes report call counts, so those counts also need a separate positive gate.

Resolution: `analysis/diagnostic_support.py` supplies positive obligations; `analysis/verify_invariance.py` requires four returned requests, expected terminal progress, actual cache/factor snapshots, every named deep-call counter and correct source/input/resource bindings. Two targeted tests first failed without this support and then passed. All four real diagnostic workers subsequently passed, including exact same-method semantic/cache equality and explicit zero deep calls under `light_v1`. The production runtime was not changed to address this review item.

## Minor documentation finding

`tests/test_measurement_policy.py` requires `V4_ANALYSIS_ROOT` for the sibling comparator. Exact reproduction commands must set it and preserve the comparator digest. This is an external test dependency, not a production import requirement.

## Review limits

Static review did not establish real-input invariance, unresolved/reset behavior, RSS/VMS peaks, timing stability or implementation choice. These are separately evidenced by diagnostics and the predeclared formal batch. Final cache hashes do not observe every intermediate cache or the full local hot/seen/chosen content.

## Narrow formal-driver review

The baseline audit agent independently read `verify_formal_repeat.py`, `run_frozen_batch.py`, `freeze_protocol.py` and their direct validation/scheduling dependencies. It found no path that admits repeats 1/2 without the preceding behavior gate, treats the retained Alpha unresolved state alone as a runtime failure, or replaces an existing completed/failed attempt. The schedule is predeclared; no speed-dependent repetition branch was found. This was static review only, with no numerical execution or edits.
